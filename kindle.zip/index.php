<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Kindle</title>
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/icon" href="assets/images/favicon.ico"/>
    <!-- Font Awesome -->
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Slick slider -->
    <link href="assets/css/slick.css" rel="stylesheet">
    <!-- Theme color -->
    <link id="switcher" href="assets/css/theme-color/default-theme.css" rel="stylesheet">

    <!-- Main Style -->
    <link href="style.css" rel="stylesheet">

    <!-- Fonts -->

    <!-- Open Sans for body font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,400i,600,700,800" rel="stylesheet">
    <!-- Lato for Title -->
  	<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet"> 
 
 
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

   	
  	<!-- Start Header -->
	<header id="mu-header" class="" role="banner">
		<div class="container">
			<nav class="navbar navbar-default mu-navbar">
			  	<div class="container-fluid">
				    <!-- Brand and toggle get grouped for better mobile display -->
				    <div class="navbar-header">
				      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
				        <span class="sr-only">Toggle navigation</span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				      </button>

				      <!-- Text Logo -->
				      <a class="navbar-brand" href="index.html"><i class="fa fa-book" aria-hidden="true"></i> Kindle</a>

				      <!-- Image Logo -->
				      <!-- <a class="navbar-brand" href="index.html"><img src="assets/images/logo.png"></a> -->


				    </div>

				    <!-- Collect the nav links, forms, and other content for toggling -->
				    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
				      	<ul class="nav navbar-nav mu-menu navbar-right">
					        <li><a href="#">HOME</a></li>
					        <li><a href="#mu-book-overview">OVERVIEW</a></li>
					        <li><a href="#mu-author">AUTHOR</a></li>
				            <li><a href="#mu-pricing">PRICE</a></li>
				            <li><a href="#mu-testimonials">TESTIMONIALS</a></li>
				            <li><a href="#mu-contact">CONTACT</a></li>
				      	</ul>
				    </div><!-- /.navbar-collapse -->
			  	</div><!-- /.container-fluid -->
			</nav>
		</div>
	</header>
	<!-- End Header -->

	<!-- Start Featured Slider -->

	<section id="mu-hero">
		<div class="container">
			<div class="row">

				<div class="col-md-6 col-sm-6 col-sm-push-6">
					<div class="mu-hero-right">
						<img src="assets/images/ebook.png" alt="Ebook img">
					</div>
				</div>

<div class="col-md-6 col-sm-6 col-sm-pull-6">
	<div class="mu-hero-left">
		<h1>A Bold, Focused Landing Page for Your eBook Launch</h1>
		<p>Make your first impression count. This layout is crafted to highlight your book, capture interest, and convert visitors — all without the fluff.</p>
		<a href="#" class="mu-primary-btn">Get Your Copy</a>
		<span>*Available in PDF, ePUB, Mobi & Kindle formats.</span>
	</div>
</div>


			</div>
		</div>
	</section>
	
	<!-- Start Featured Slider -->
	
	<!-- Start main content -->
		
	<main role="main">

		<!-- Start Counter -->
		<section id="mu-counter">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-counter-area">

							<div class="mu-counter-block">
								<div class="row">

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<i class="fa fa-files-o" aria-hidden="true"></i>
											<div class="counter-value" data-count="650">0</div>
											<h5 class="mu-counter-name">Total Pages</h5>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<i class="fa fa-file-text-o" aria-hidden="true"></i>
											<div class="counter-value" data-count="422">0</div>
											<h5 class="mu-counter-name">Chapters</h5>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<i class="fa fa-users" aria-hidden="true"></i>
											<div class="counter-value" data-count="1055">0</div>
											<h5 class="mu-counter-name">Active Readers</h5>
										</div>
									</div>
									<!-- / Single Counter -->

									<!-- Start Single Counter -->
									<div class="col-md-3 col-sm-6">
										<div class="mu-single-counter">
											<i class="fa fa-trophy" aria-hidden="true"></i>
											<div class="counter-value" data-count="03">0</div>
											<h5 class="mu-counter-name">Got Awards</h5>
										</div>
									</div>
									<!-- / Single Counter -->

								</div>
							</div>


						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Counter -->
<!-- Start Book Overview -->
<section id="mu-book-overview">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="mu-book-overview-area">

					<div class="mu-heading-area">
						<h2 class="mu-heading-title">What's Inside</h2>
						<span class="mu-header-dot"></span>
						<p>This book breaks down complex ideas into clear, actionable insights. Here’s a glimpse of the chapters waiting for you inside.</p>
					</div>

					<!-- Start Book Overview Content -->
					<div class="mu-book-overview-content">
						<div class="row">

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-area-chart" aria-hidden="true"></i>
									</span>
									<h4>Chapter One</h4>
									<p>Understanding the core idea behind your goals — and why clarity always beats speed.</p>
								</div>
							</div>

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-cubes" aria-hidden="true"></i>
									</span>
									<h4>Chapter Two</h4>
									<p>Breaking down your process into pieces you can measure, improve, and actually finish.</p>
								</div>
							</div>

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-modx" aria-hidden="true"></i>
									</span>
									<h4>Chapter Three</h4>
									<p>How to create systems that do the work — even when you're not motivated.</p>
								</div>
							</div>

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-files-o" aria-hidden="true"></i>
									</span>
									<h4>Chapter Four</h4>
									<p>Real-world examples of routines that work, and how to build your own version.</p>
								</div>
							</div>

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-file-pdf-o" aria-hidden="true"></i>
									</span>
									<h4>Chapter Five</h4>
									<p>The psychology of starting small — and why it’s the smartest move you can make.</p>
								</div>
							</div>

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-language" aria-hidden="true"></i>
									</span>
									<h4>Chapter Six</h4>
									<p>Language matters. Here's how to reframe problems so you actually enjoy solving them.</p>
								</div>
							</div>

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-gg" aria-hidden="true"></i>
									</span>
									<h4>Chapter Seven</h4>
									<p>Momentum over motivation: how to build a streak that keeps going (even when life doesn’t cooperate).</p>
								</div>
							</div>

							<div class="col-md-3 col-sm-6">
								<div class="mu-book-overview-single">
									<span class="mu-book-overview-icon-box">
										<i class="fa fa-wpforms" aria-hidden="true"></i>
									</span>
									<h4>Chapter Eight</h4>
									<p>Pulling it all together — your blueprint for sustainable growth, without the burnout.</p>
								</div>
							</div>

						</div>
					</div>
					<!-- End Book Overview Content -->

				</div>
			</div>
		</div>
	</div>
</section>

		<!-- End Book Overview -->

		
<!-- Start Video Review -->
<section id="mu-video-review">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="mu-video-review-area">

					<div class="mu-heading-area">
						<h2 class="mu-heading-title">Watch the Preview</h2>
						<span class="mu-header-dot"></span>
						<p>This short video gives you a real look at what the book delivers — no filters, just content and value.</p>
					</div>

					<!-- Start Video Review Content -->
					<div class="mu-video-review-content">
						<iframe class="mu-video-iframe" width="100%" height="480" src="https://www.youtube.com/embed/T4ySAlBt2Ug" frameborder="0" allowfullscreen></iframe>
					</div>
					<!-- End Video Review Content -->

				</div>
			</div>
		</div>
	</div>
</section>

		<!-- End Video Review -->

		<!-- Start Author -->
		<section id="mu-author">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="mu-author-area">

							<div class="mu-heading-area">
								<h2 class="mu-heading-title">About The Author</h2>
								<span class="mu-header-dot"></span>
							</div>
<!-- Start Author Content -->
<div class="mu-author-content">
	<div class="row">
		<div class="col-md-6">
			<div class="mu-author-image">
				<img src="assets/images/author.jpg" alt="Author Image">
			</div>
		</div>
		<div class="col-md-6">
			<div class="mu-author-info">
				<h3>Sildix</h3>
				<p>Started out with a notebook and an idea. Years later, that idea turned into a handful of books, podcasts, and way too many sleepless nights. This one? It’s the most personal yet.</p>

				<p>He doesn’t believe in fluff or filler—just stories that hit close to home and insights that might just change how you see things. No hype. No marketing jargon.</p>

				<img class="mu-author-sign" src="assets/images/author-signature.png" alt="Author Signature">

				<div class="mu-author-social">
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-linkedin"></i></a>
					<a href="#"><i class="fa fa-google-plus"></i></a>
				</div>
			</div>
		</div>
	</div>
</div>

							<!-- End Author Content -->

						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- End Author -->
<!-- Start Pricing -->
<section id="mu-pricing">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="mu-pricing-area">

					<div class="mu-heading-area">
						<h2 class="mu-heading-title">Choose a Plan That Works</h2>
						<span class="mu-header-dot"></span>
						<p>No fancy talk. Just pick a plan that suits your pace and budget. Simple as that.</p>
					</div>

					<!-- Start Pricing Content -->
					<div class="mu-pricing-content">
						<div class="row">

							<!-- Basic Plan -->
							<div class="col-sm-6 col-md-4">
								<div class="mu-pricing-single">

									<div class="mu-pricing-single-head">
										<h4>Kickstart</h4>
										<p class="mu-price-tag">
											<span>$</span> 15
										</p>
									</div>

									<ul class="mu-price-feature">
										<li>Access to core features</li>
										<li>Email support</li>
										<li>No ads</li>
										<li>1 project included</li>
									</ul>

									<div class="mu-pricing-single-footer">
										<a href="#" class="mu-order-btn">Get Started</a>
									</div>

								</div>
							</div>

							<!-- Pro Plan -->
							<div class="col-sm-6 col-md-4">
								<div class="mu-pricing-single mu-popular-price-tag">

									<div class="mu-pricing-single-head">
										<h4>Pro Move</h4>
										<p class="mu-price-tag">
											<span>$</span> 25
										</p>
									</div>

									<ul class="mu-price-feature">
										<li>All Kickstart features</li>
										<li>Priority support</li>
										<li>Unlimited projects</li>
										<li>Early access to updates</li>
									</ul>

									<div class="mu-pricing-single-footer">
										<a href="#" class="mu-order-btn">Go Pro</a>
									</div>

								</div>
							</div>

							<!-- Premium Plan -->
							<div class="col-sm-6 col-md-4">
								<div class="mu-pricing-single">

									<div class="mu-pricing-single-head">
										<h4>The Works</h4>
										<p class="mu-price-tag">
											<span>$</span> 45
										</p>
									</div>

									<ul class="mu-price-feature">
										<li>Everything from Pro</li>
										<li>1-on-1 onboarding</li>
										<li>Custom integrations</li>
										<li>Slack support channel</li>
									</ul>

									<div class="mu-pricing-single-footer">
										<a href="#" class="mu-order-btn">Let’s Go All In</a>
									</div>

								</div>
							</div>

						</div>
					</div>
					<!-- End Pricing Content -->

				</div>
			</div>
		</div>
	</div>
</section>

		<!-- End Pricing -->
<!-- Start Testimonials -->
<section id="mu-testimonials">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="mu-testimonials-area">
					<div class="mu-heading-area">
						<h2 class="mu-heading-title">Voices That Matter</h2>
						<span class="mu-header-dot"></span>
					</div>

					<div class="mu-testimonials-block">
						<ul class="mu-testimonial-slide">

							<li>
								<p>"The insights here changed how I approach my workflow. Not flashy, just genuinely useful. 10/10 would recommend."</p>
								<img class="mu-rt-img" src="assets/images/reader-1.jpg" alt="img">
								<h5 class="mu-rt-name"> - Alice Morgan</h5>
								<span class="mu-rt-title">Product Strategist</span>
							</li>

							<li>
								<p>"Wasn't expecting much when I started reading. Ended up bingeing the whole thing in one go. That good."</p>
								<img class="mu-rt-img" src="assets/images/reader-2.jpg" alt="img">
								<h5 class="mu-rt-name"> - Leon Hale</h5>
								<span class="mu-rt-title">Freelance Developer</span>
							</li>

							<li>
								<p>"You know that rare moment when content feels like it's written just for you? Yeah, that happened here."</p>
								<img class="mu-rt-img" src="assets/images/reader-3.jpg" alt="img">
								<h5 class="mu-rt-name"> - Casey Niel</h5>
								<span class="mu-rt-title">UX Designer</span>
							</li>

						</ul>
					</div>

				</div>
			</div>
		</div>
	</div>
</section>

		<!-- End Testimonials -->

	
<!-- Start Contact -->
<section id="mu-contact">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="mu-contact-area">

					<div class="mu-heading-area">
						<h2 class="mu-heading-title">Get in Touch</h2>
						<span class="mu-header-dot"></span>
						<p>Have questions, feedback, or just want to say hi? We’d love to hear from you. Fill out the form and we’ll get back to you as soon as possible.</p>
					</div>

					<!-- Start Contact Content -->
					<div class="mu-contact-content">

						<div id="form-messages"></div>
						<form id="ajax-contact" method="post" action="mailer.php" class="mu-contact-form">
							<div class="form-group">                
								<input type="text" class="form-control" placeholder="Your Name" id="name" name="name" required>
							</div>
							<div class="form-group">                
								<input type="email" class="form-control" placeholder="Your Email Address" id="email" name="email" required>
							</div>              
							<div class="form-group">
								<textarea class="form-control" placeholder="Write your message here..." id="message" name="message" required></textarea>
							</div>
							<button type="submit" class="mu-send-msg-btn"><span>Send Message</span></button>
						</form>

					</div>
					<!-- End Contact Content -->

				</div>
			</div>
		</div>
	</div>
</section>

		<!-- End Contact -->

		<!-- Start Google Map -->
		<section id="mu-google-map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d589888.4396405783!2d-82.41588603632052!3d32.866951223053896!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x88f9f727a4ed30eb%3A0xf2139b0c5c7ae1ec!2sDooley+Branch+Rd%2C+Millen%2C+GA+30442%2C+USA!5e0!3m2!1sen!2sbd!4v1497376364225" width="100%" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>
		</section>
		<!-- End Google Map -->

	</main>
	
	<!-- End main content -->	
		<!-- Start footer -->
<footer id="mu-footer" role="contentinfo">
	<div class="container">
		<div class="mu-footer-area">
			<div class="mu-social-media">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-instagram"></i></a>
				<a href="#"><i class="fa fa-linkedin"></i></a>
			</div>
			<p class="mu-copyright">
				&copy; <script>document.write(new Date().getFullYear());</script> Crafted with care. No templates were harmed.
			</p>
		</div>
	</div>
</footer>

	<!-- End footer -->

	
	
    <!-- jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
	<!-- Slick slider -->
    <script type="text/javascript" src="assets/js/slick.min.js"></script>
    <!-- Counter js -->
    <script type="text/javascript" src="assets/js/counter.js"></script>
    <!-- Ajax contact form  -->
    <script type="text/javascript" src="assets/js/app.js"></script>
   
 
	
    <!-- Custom js -->
	<script type="text/javascript" src="assets/js/custom.js"></script>
	
    
  </body>
</html>