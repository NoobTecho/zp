<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
<title>AirCon - Reliable HVAC & Air Conditioning Services</title>

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <div class="container-fluid d-none d-lg-block">
        <div class="row align-items-center bg-dark px-lg-5">
            <div class="col-lg-9">
                <nav class="navbar navbar-expand-sm bg-dark p-0">
                    <ul class="navbar-nav ml-n2">
                        <li class="nav-item border-right border-secondary">
                            <a class="nav-link text-body small" href="#">Monday, June 1, 2025</a>
                        </li>
                        <li class="nav-item border-right border-secondary">
                            <a class="nav-link text-body small" href="#">Advertise</a>
                        </li>
                        <li class="nav-item border-right border-secondary">
                            <a class="nav-link text-body small" href="#">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-body small" href="#">Login</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="col-lg-3 text-right d-none d-md-block">
                <nav class="navbar navbar-expand-sm bg-dark p-0">
                    <ul class="navbar-nav ml-auto mr-n2">
                        <li class="nav-item">
                            <a class="nav-link text-body" href="#"><small class="fab fa-twitter"></small></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-body" href="#"><small class="fab fa-facebook-f"></small></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-body" href="#"><small class="fab fa-linkedin-in"></small></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-body" href="#"><small class="fab fa-instagram"></small></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-body" href="#"><small class="fab fa-google-plus-g"></small></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-body" href="#"><small class="fab fa-youtube"></small></a>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>
        <div class="row align-items-center bg-white py-3 px-lg-5">
            <div class="col-lg-4">
                <a href="index.html" class="navbar-brand p-0 d-none d-lg-block">
                    <h1 class="m-0 display-4 text-uppercase text-primary">Biz<span class="text-secondary font-weight-normal">News</span></h1>
                </a>
            </div>
            <div class="col-lg-8 text-center text-lg-right">
                <a href="https://htmlcodex.com"><img class="img-fluid" src="img/ads-728x90.png" alt=""></a>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <div class="container-fluid p-0">
        <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-2 py-lg-0 px-lg-5">
            <a href="index.html" class="navbar-brand d-block d-lg-none">
                <h1 class="m-0 display-4 text-uppercase text-primary">Biz<span class="text-white font-weight-normal">News</span></h1>
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-between px-0 px-lg-3" id="navbarCollapse">
                <div class="navbar-nav mr-auto py-0">
                    <a href="index.html" class="nav-item nav-link active">Home</a>
                    <a href="category.html" class="nav-item nav-link">Category</a>
                    <a href="single.html" class="nav-item nav-link">Single News</a>
                    <div class="nav-item dropdown">
                        <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Dropdown</a>
                        <div class="dropdown-menu rounded-0 m-0">
                            <a href="#" class="dropdown-item">Menu item 1</a>
                            <a href="#" class="dropdown-item">Menu item 2</a>
                            <a href="#" class="dropdown-item">Menu item 3</a>
                        </div>
                    </div>
                    <a href="contact.html" class="nav-item nav-link">Contact</a>
                </div>
                <div class="input-group ml-auto d-none d-lg-flex" style="width: 100%; max-width: 300px;">
                    <input type="text" class="form-control border-0" placeholder="Keyword">
                    <div class="input-group-append">
                        <button class="input-group-text bg-primary text-dark border-0 px-3"><i
                                class="fa fa-search"></i></button>
                    </div>
                </div>
            </div>
        </nav>
    </div>
    <!-- Navbar End -->

<!-- Main News Slider Start -->
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-7 px-0">
            <div class="owl-carousel main-carousel position-relative">
                <div class="position-relative overflow-hidden" style="height: 500px;">
                    <img class="img-fluid h-100" src="img/news-800x500-1.jpg" style="object-fit: cover;">
                    <div class="overlay">
                        <div class="mb-2">
                            <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                href="">Industry</a>
                            <a class="text-white" href="">Jun 13, 2025</a>
                        </div>
                        <a class="h2 m-0 text-white text-uppercase font-weight-bold" href="">How Smart HVAC Systems Are Changing Home Climate Control</a>
                    </div>
                </div>
                <div class="position-relative overflow-hidden" style="height: 500px;">
                    <img class="img-fluid h-100" src="img/news-800x500-2.jpg" style="object-fit: cover;">
                    <div class="overlay">
                        <div class="mb-2">
                            <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                href="">Industry</a>
                            <a class="text-white" href="">Jun 12, 2025</a>
                        </div>
                        <a class="h2 m-0 text-white text-uppercase font-weight-bold" href="">Top Maintenance Tips to Maximize Your AC Lifespan</a>
                    </div>
                </div>
                <div class="position-relative overflow-hidden" style="height: 500px;">
                    <img class="img-fluid h-100" src="img/news-800x500-3.jpg" style="object-fit: cover;">
                    <div class="overlay">
                        <div class="mb-2">
                            <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                href="">Industry</a>
                            <a class="text-white" href="">Jun 11, 2025</a>
                        </div>
                        <a class="h2 m-0 text-white text-uppercase font-weight-bold" href="">Why Energy-Efficient HVAC Units Are the Future of Cooling</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-5 px-0">
            <div class="row mx-0">
                <div class="col-md-6 px-0">
                    <div class="position-relative overflow-hidden" style="height: 250px;">
                        <img class="img-fluid w-100 h-100" src="img/news-700x435-1.jpg" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Tips</a>
                                <a class="text-white" href=""><small>Jun 10, 2025</small></a>
                            </div>
                            <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">5 Signs It’s Time to Replace Your Old Air Conditioner</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 px-0">
                    <div class="position-relative overflow-hidden" style="height: 250px;">
                        <img class="img-fluid w-100 h-100" src="img/news-700x435-2.jpg" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Tech</a>
                                <a class="text-white" href=""><small>Jun 09, 2025</small></a>
                            </div>
                            <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Exploring the Latest Innovations in Cooling Technology</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 px-0">
                    <div class="position-relative overflow-hidden" style="height: 250px;">
                        <img class="img-fluid w-100 h-100" src="img/news-700x435-3.jpg" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Home</a>
                                <a class="text-white" href=""><small>Jun 08, 2025</small></a>
                            </div>
                            <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Choosing the Right AC System for Your Home Size</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 px-0">
                    <div class="position-relative overflow-hidden" style="height: 250px;">
                        <img class="img-fluid w-100 h-100" src="img/news-700x435-4.jpg" style="object-fit: cover;">
                        <div class="overlay">
                            <div class="mb-2">
                                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2"
                                    href="">Guides</a>
                                <a class="text-white" href=""><small>Jun 07, 2025</small></a>
                            </div>
                            <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">How to Prepare Your HVAC for Seasonal Changes</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Main News Slider End -->

<!-- Breaking News Start -->
<div class="container-fluid bg-dark py-3 mb-3">
    <div class="container">
        <div class="row align-items-center bg-dark">
            <div class="col-12">
                <div class="d-flex justify-content-between">
                    <div class="bg-primary text-dark text-center font-weight-medium py-2" style="width: 170px;">Breaking News</div>
                    <div class="owl-carousel tranding-carousel position-relative d-inline-flex align-items-center ml-3"
                        style="width: calc(100% - 170px); padding-right: 90px;">
                        <div class="text-truncate"><a class="text-white text-uppercase font-weight-semi-bold" href="">Global Heatwave Drives Surge in HVAC Demand Across Cities</a></div>
                        <div class="text-truncate"><a class="text-white text-uppercase font-weight-semi-bold" href="">New AirCon Report Reveals 25% Drop in Energy Usage with Smart Units</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Breaking News End -->

<!-- Featured News Slider Start -->
<div class="container-fluid pt-5 mb-3">
    <div class="container">
        <div class="section-title">
            <h4 class="m-0 text-uppercase font-weight-bold">Featured News</h4>
        </div>
        <div class="owl-carousel news-carousel carousel-item-4 position-relative">
            <div class="position-relative overflow-hidden" style="height: 300px;">
                <img class="img-fluid h-100" src="img/news-700x435-1.jpg" style="object-fit: cover;">
                <div class="overlay">
                    <div class="mb-2">
                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                        <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                    </div>
                    <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">HVAC Industry Sees Growth as Summer Temperatures Break Records</a>
                </div>
            </div>
            <div class="position-relative overflow-hidden" style="height: 300px;">
                <img class="img-fluid h-100" src="img/news-700x435-2.jpg" style="object-fit: cover;">
                <div class="overlay">
                    <div class="mb-2">
                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                        <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                    </div>
                    <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">AirCon Launches New Eco-Friendly Cooling Units for Urban Homes</a>
                </div>
            </div>
            <div class="position-relative overflow-hidden" style="height: 300px;">
                <img class="img-fluid h-100" src="img/news-700x435-3.jpg" style="object-fit: cover;">
                <div class="overlay">
                    <div class="mb-2">
                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                        <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                    </div>
                    <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Experts Predict Spike in Air Conditioner Sales by Mid-2045</a>
                </div>
            </div>
            <div class="position-relative overflow-hidden" style="height: 300px;">
                <img class="img-fluid h-100" src="img/news-700x435-4.jpg" style="object-fit: cover;">
                <div class="overlay">
                    <div class="mb-2">
                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                        <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                    </div>
                    <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">Smart Thermostat Integration Transforms Home Climate Control</a>
                </div>
            </div>
            <div class="position-relative overflow-hidden" style="height: 300px;">
                <img class="img-fluid h-100" src="img/news-700x435-5.jpg" style="object-fit: cover;">
                <div class="overlay">
                    <div class="mb-2">
                        <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                        <a class="text-white" href=""><small>Jan 01, 2045</small></a>
                    </div>
                    <a class="h6 m-0 text-white text-uppercase font-weight-semi-bold" href="">New Policies Aim to Cut Emissions in Commercial Cooling Sector</a>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Featured News Slider End -->


    <!-- News With Sidebar Start -->
    <div class="container-fluid">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-12">
                            <div class="section-title">
                                <h4 class="m-0 text-uppercase font-weight-bold">Latest News</h4>
                                <a class="text-secondary font-weight-medium text-decoration-none" href="">View All</a>
                            </div>
                        </div>
<div class="col-lg-6">
    <div class="position-relative mb-3">
        <img class="img-fluid w-100" src="img/news-700x435-1.jpg" style="object-fit: cover;">
        <div class="bg-white border border-top-0 p-4">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Feb 18, 2025</small></a>
            </div>
            <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href="">Startup Valuations Surge Amid Tech Boom</a>
            <p class="m-0">Driven by innovation in AI and green tech, startup valuations hit record highs across major markets.</p>
        </div>
        <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
            <div class="d-flex align-items-center">
                <img class="rounded-circle mr-2" src="img/user.jpg" width="25" height="25" alt="">
                <small>John Doe</small>
            </div>
            <div class="d-flex align-items-center">
                <small class="ml-3"><i class="far fa-eye mr-2"></i>12345</small>
                <small class="ml-3"><i class="far fa-comment mr-2"></i>123</small>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-6">
    <div class="position-relative mb-3">
        <img class="img-fluid w-100" src="img/news-700x435-2.jpg" style="object-fit: cover;">
        <div class="bg-white border border-top-0 p-4">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Mar 10, 2025</small></a>
            </div>
            <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href="">Mergers Drive Global Expansion Strategies</a>
            <p class="m-0">Explore how business alliances are shaping new market territories and investor confidence.</p>
        </div>
        <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
            <div class="d-flex align-items-center">
                <img class="rounded-circle mr-2" src="img/user.jpg" width="25" height="25" alt="">
                <small>John Doe</small>
            </div>
            <div class="d-flex align-items-center">
                <small class="ml-3"><i class="far fa-eye mr-2"></i>44</small>
                <small class="ml-3"><i class="far fa-comment mr-2"></i>83</small>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-12 mb-3">
    <a href=""><img class="img-fluid w-100" src="img/ads-728x90.png" alt=""></a>
</div>
<div class="col-lg-6">
    <div class="position-relative mb-3">
        <img class="img-fluid w-100" src="img/news-700x435-3.jpg" style="object-fit: cover;">
        <div class="bg-white border border-top-0 p-4">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>May 26, 2025</small></a>
            </div>
            <a class="h4 d-block mb-0 text-secondary text-uppercase font-weight-bold" href="">AI Tools Revolutionize Workplace Efficiency</a>
        </div>
        <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
            <div class="d-flex align-items-center">
                <img class="rounded-circle mr-2" src="img/user.jpg" width="25" height="25" alt="">
                <small>John Doe</small>
            </div>
            <div class="d-flex align-items-center">
                <small class="ml-3"><i class="far fa-eye mr-2"></i>875</small>
                <small class="ml-3"><i class="far fa-comment mr-2"></i>28</small>
            </div>
        </div>
    </div>
</div>
<div class="col-lg-6">
    <div class="position-relative mb-3">
        <img class="img-fluid w-100" src="img/news-700x435-4.jpg" style="object-fit: cover;">
        <div class="bg-white border border-top-0 p-4">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Jul 04, 2025</small></a>
            </div>
            <a class="h4 d-block mb-0 text-secondary text-uppercase font-weight-bold" href="">Remote Teams Reshape Corporate Culture</a>
        </div>
        <div class="d-flex justify-content-between bg-white border border-top-0 p-4">
            <div class="d-flex align-items-center">
                <img class="rounded-circle mr-2" src="img/user.jpg" width="25" height="25" alt="">
                <small>John Doe</small>
            </div>
            <div class="d-flex align-items-center">
                <small class="ml-3"><i class="far fa-eye mr-2"></i>15</small>
                <small class="ml-3"><i class="far fa-comment mr-2"></i>13</small>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-6">
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-1.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Feb 14, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">How Automation Transforms Corporate Strategy</a>
        </div>
    </div>
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-2.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Apr 08, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">New Tech Disruptors Drive Market Innovation</a>
        </div>
    </div>
</div>
<div class="col-lg-6">
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-3.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Jun 01, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Sustainability Trends Reshape Enterprise Goals</a>
        </div>
    </div>
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-4.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>May 21, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Startups Lead the Shift to Digital-First Models</a>
        </div>
    </div>
</div>

                        <div class="col-lg-12 mb-3">
                            <a href=""><img class="img-fluid w-100" src="img/ads-728x90.png" alt=""></a>
                        </div>
<div class="col-lg-12">
    <div class="row news-lg mx-0 mb-3">
        <div class="col-md-6 h-100 px-0">
            <img class="img-fluid h-100" src="img/news-700x435-5.jpg" style="object-fit: cover;">
        </div>
        <div class="col-md-6 d-flex flex-column border bg-white h-100 px-0">
            <div class="mt-auto p-4">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-2 mr-2" href="">Business</a>
                    <a class="text-body" href=""><small>Mar 17, 2025</small></a>
                </div>
                <a class="h4 d-block mb-3 text-secondary text-uppercase font-weight-bold" href="">AI-Driven Markets Reshape Global Strategy</a>
                <p class="m-0">Intelligent automation and data-led insights are redefining competitive advantage across industries.</p>
            </div>
            <div class="d-flex justify-content-between bg-white border-top mt-auto p-4">
                <div class="d-flex align-items-center">
                    <img class="rounded-circle mr-2" src="img/user.jpg" width="25" height="25" alt="">
                    <small>John Doe</small>
                </div>
                <div class="d-flex align-items-center">
                    <small class="ml-3"><i class="far fa-eye mr-2"></i>245</small>
                    <small class="ml-3"><i class="far fa-comment mr-2"></i>93</small>
                </div>
            </div>
        </div>
    </div>
</div>

                      <div class="col-lg-6">
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-1.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Feb 14, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Startups Disrupt Traditional Finance Ecosystems</a>
        </div>
    </div>
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-2.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Apr 08, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Green Investments Drive Sustainable Growth</a>
        </div>
    </div>
</div>

                     <div class="col-lg-6">
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-3.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>Mar 22, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Top Tech Trends Reshaping Business Models</a>
        </div>
    </div>
    <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
        <img class="img-fluid" src="img/news-110x110-4.jpg" alt="">
        <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
            <div class="mb-2">
                <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                <a class="text-body" href=""><small>May 10, 2025</small></a>
            </div>
            <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">AI Integration Boosts Enterprise Efficiency</a>
        </div>
    </div>
</div>

                    </div>
                </div>
                
                <div class="col-lg-4">
                    <!-- Social Follow Start -->
<div class="mb-3">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Follow Us</h4>
    </div>
    <div class="bg-white border border-top-0 p-3">
        <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #39569E;">
            <i class="fab fa-facebook-f text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
            <span class="font-weight-medium">23,876 Fans</span>
        </a>
        <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #52AAF4;">
            <i class="fab fa-twitter text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
            <span class="font-weight-medium">18,942 Followers</span>
        </a>
        <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #0185AE;">
            <i class="fab fa-linkedin-in text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
            <span class="font-weight-medium">9,504 Connects</span>
        </a>
        <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #C8359D;">
            <i class="fab fa-instagram text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
            <span class="font-weight-medium">34,118 Followers</span>
        </a>
        <a href="" class="d-block w-100 text-white text-decoration-none mb-3" style="background: #DC472E;">
            <i class="fab fa-youtube text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
            <span class="font-weight-medium">27,763 Subscribers</span>
        </a>
        <a href="" class="d-block w-100 text-white text-decoration-none" style="background: #055570;">
            <i class="fab fa-vimeo-v text-center py-4 mr-3" style="width: 65px; background: rgba(0, 0, 0, .2);"></i>
            <span class="font-weight-medium">5,297 Followers</span>
        </a>
    </div>
</div>

                    <!-- Social Follow End -->

                    <!-- Ads Start -->
                    <div class="mb-3">
                        <div class="section-title mb-0">
                            <h4 class="m-0 text-uppercase font-weight-bold">Advertisement</h4>
                        </div>
                        <div class="bg-white text-center border border-top-0 p-3">
                            <a href=""><img class="img-fluid" src="img/news-800x500-2.jpg" alt=""></a>
                        </div>
                    </div>
                    <!-- Ads End -->
<div class="mb-3">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Trending News</h4>
    </div>
    <div class="bg-white border border-top-0 p-3">
        <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
            <img class="img-fluid" src="img/news-110x110-1.jpg" alt="">
            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                    <a class="text-body" href=""><small>Apr 14, 2025</small></a>
                </div>
                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Global markets rebound after week of losses</a>
            </div>
        </div>
        <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
            <img class="img-fluid" src="img/news-110x110-2.jpg" alt="">
            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                    <a class="text-body" href=""><small>Apr 12, 2025</small></a>
                </div>
                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Tech giants unveil new AI-driven services</a>
            </div>
        </div>
        <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
            <img class="img-fluid" src="img/news-110x110-3.jpg" alt="">
            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                    <a class="text-body" href=""><small>Apr 10, 2025</small></a>
                </div>
                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Startup funding slows amid investor caution</a>
            </div>
        </div>
        <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
            <img class="img-fluid" src="img/news-110x110-4.jpg" alt="">
            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                    <a class="text-body" href=""><small>Apr 09, 2025</small></a>
                </div>
                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">E-commerce trends shift toward local brands</a>
            </div>
        </div>
        <div class="d-flex align-items-center bg-white mb-3" style="height: 110px;">
            <img class="img-fluid" src="img/news-110x110-5.jpg" alt="">
            <div class="w-100 h-100 px-3 d-flex flex-column justify-content-center border border-left-0">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Business</a>
                    <a class="text-body" href=""><small>Apr 08, 2025</small></a>
                </div>
                <a class="h6 m-0 text-secondary text-uppercase font-weight-bold" href="">Cryptocurrency market shows signs of recovery</a>
            </div>
        </div>
    </div>
</div>

                    <!-- Popular News End -->
<div class="mb-3">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Newsletter</h4>
    </div>
    <div class="bg-white text-center border border-top-0 p-3">
        <p>Get the latest business headlines and market insights delivered weekly.</p>
        <div class="input-group mb-2" style="width: 100%;">
            <input type="text" class="form-control form-control-lg" placeholder="Your Email">
            <div class="input-group-append">
                <button class="btn btn-primary font-weight-bold px-3">Sign Up</button>
            </div>
        </div>
        <small>Stay informed. Unsubscribe anytime.</small>
    </div>
</div>

                    <!-- Newsletter End -->
<div class="mb-3">
    <div class="section-title mb-0">
        <h4 class="m-0 text-uppercase font-weight-bold">Tags</h4>
    </div>
    <div class="bg-white border border-top-0 p-3">
        <div class="d-flex flex-wrap m-n1">
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Finance</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Startups</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Innovation</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Economy</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Marketing</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Leadership</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Analytics</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">E-commerce</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Strategy</a>
            <a href="" class="btn btn-sm btn-outline-secondary m-1">Tech Trends</a>
        </div>
    </div>
</div>

                    <!-- Tags End -->
                </div>
            </div>
        </div>
    </div>
    <!-- News With Sidebar End -->

<div class="container-fluid bg-dark pt-5 px-sm-3 px-md-5 mt-5">
    <div class="row py-4">
        <div class="col-lg-3 col-md-6 mb-5">
            <h5 class="mb-4 text-white text-uppercase font-weight-bold">Get In Touch</h5>
            <p class="font-weight-medium"><i class="fa fa-map-marker-alt mr-2"></i>42 Silicon Lane, London, UK</p>
            <p class="font-weight-medium"><i class="fa fa-phone-alt mr-2"></i>+44 207 123 4567</p>
            <p class="font-weight-medium"><i class="fa fa-envelope mr-2"></i>contact@neogridlabs.com</p>
            <h6 class="mt-4 mb-3 text-white text-uppercase font-weight-bold">Follow Us</h6>
            <div class="d-flex justify-content-start">
                <a class="btn btn-lg btn-secondary btn-lg-square mr-2" href="#"><i class="fab fa-twitter"></i></a>
                <a class="btn btn-lg btn-secondary btn-lg-square mr-2" href="#"><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-lg btn-secondary btn-lg-square mr-2" href="#"><i class="fab fa-linkedin-in"></i></a>
                <a class="btn btn-lg btn-secondary btn-lg-square mr-2" href="#"><i class="fab fa-instagram"></i></a>
                <a class="btn btn-lg btn-secondary btn-lg-square" href="#"><i class="fab fa-youtube"></i></a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-5">
            <h5 class="mb-4 text-white text-uppercase font-weight-bold">Popular News</h5>
            <div class="mb-3">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Finance</a>
                    <a class="text-body" href=""><small>May 12, 2025</small></a>
                </div>
                <a class="small text-body text-uppercase font-weight-medium" href="">Top startups revolutionizing the fintech landscape...</a>
            </div>
            <div class="mb-3">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Marketing</a>
                    <a class="text-body" href=""><small>Apr 22, 2025</small></a>
                </div>
                <a class="small text-body text-uppercase font-weight-medium" href="">How AI is changing digital advertising forever...</a>
            </div>
            <div class="">
                <div class="mb-2">
                    <a class="badge badge-primary text-uppercase font-weight-semi-bold p-1 mr-2" href="">Innovation</a>
                    <a class="text-body" href=""><small>Mar 08, 2025</small></a>
                </div>
                <a class="small text-body text-uppercase font-weight-medium" href="">Breakthroughs in clean tech: What's next for 2025...</a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-5">
            <h5 class="mb-4 text-white text-uppercase font-weight-bold">Categories</h5>
            <div class="m-n1">
                <a href="" class="btn btn-sm btn-secondary m-1">Finance</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Startups</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Innovation</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Economy</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Marketing</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Leadership</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Analytics</a>
                <a href="" class="btn btn-sm btn-secondary m-1">E-commerce</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Strategy</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Tech Trends</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Startups</a>
                <a href="" class="btn btn-sm btn-secondary m-1">SaaS</a>
                <a href="" class="btn btn-sm btn-secondary m-1">AI</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Blockchain</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Growth</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Funding</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Digital</a>
                <a href="" class="btn btn-sm btn-secondary m-1">UX</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Remote Work</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Networking</a>
                <a href="" class="btn btn-sm btn-secondary m-1">Branding</a>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-5">
            <h5 class="mb-4 text-white text-uppercase font-weight-bold">Flickr Photos</h5>
            <div class="row">
                <div class="col-4 mb-3">
                    <a href=""><img class="w-100" src="img/news-110x110-1.jpg" alt=""></a>
                </div>
                <div class="col-4 mb-3">
                    <a href=""><img class="w-100" src="img/news-110x110-2.jpg" alt=""></a>
                </div>
                <div class="col-4 mb-3">
                    <a href=""><img class="w-100" src="img/news-110x110-3.jpg" alt=""></a>
                </div>
                <div class="col-4 mb-3">
                    <a href=""><img class="w-100" src="img/news-110x110-4.jpg" alt=""></a>
                </div>
                <div class="col-4 mb-3">
                    <a href=""><img class="w-100" src="img/news-110x110-5.jpg" alt=""></a>
                </div>
                <div class="col-4 mb-3">
                    <a href=""><img class="w-100" src="img/news-110x110-1.jpg" alt=""></a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid py-4 px-sm-3 px-md-5" style="background: #111111;">
    <p class="m-0 text-center">&copy; <a href="#">NeoGrid Labs</a>. All Rights Reserved. 
</p>
</div>

    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary btn-square back-to-top"><i class="fa fa-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>