<!DOCTYPE html>
<html lang="en">
<head>
<title>Course</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Course Project">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/fontawesome-free-5.0.1/css/fontawesome-all.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<link rel="stylesheet" type="text/css" href="styles/main_styles.css">
<link rel="stylesheet" type="text/css" href="styles/responsive.css">
</head>
<body>

<div class="super_container">

	<!-- Header -->

	<header class="header d-flex flex-row">
		<div class="header_content d-flex flex-row align-items-center">
			<!-- Logo -->
			<div class="logo_container">
				<div class="logo">
					<img src="images/logo.png" alt="">
					<span>course</span>
				</div>
			</div>

			<!-- Main Navigation -->
			<nav class="main_nav_container">
				<div class="main_nav">
					<ul class="main_nav_list">
						<li class="main_nav_item"><a href="#">home</a></li>
						<li class="main_nav_item"><a href="#">about us</a></li>
						<li class="main_nav_item"><a href="courses.html">courses</a></li>
						<li class="main_nav_item"><a href="elements.html">elements</a></li>
						<li class="main_nav_item"><a href="news.html">news</a></li>
						<li class="main_nav_item"><a href="contact.html">contact</a></li>
					</ul>
				</div>
			</nav>
		</div>
		<div class="header_side d-flex flex-row justify-content-center align-items-center">
			<img src="images/phone-call.svg" alt="">
			<span>+43 4566 7788 2457</span>
		</div>

		<!-- Hamburger -->
		<div class="hamburger_container">
			<i class="fas fa-bars trans_200"></i>
		</div>

	</header>
	
	<!-- Menu -->
	<div class="menu_container menu_mm">

		<!-- Menu Close Button -->
		<div class="menu_close_container">
			<div class="menu_close"></div>
		</div>

		<!-- Menu Items -->
		<div class="menu_inner menu_mm">
			<div class="menu menu_mm">
				<ul class="menu_list menu_mm">
					<li class="menu_item menu_mm"><a href="#">Home</a></li>
					<li class="menu_item menu_mm"><a href="#">About us</a></li>
					<li class="menu_item menu_mm"><a href="courses.html">Courses</a></li>
					<li class="menu_item menu_mm"><a href="elements.html">Elements</a></li>
					<li class="menu_item menu_mm"><a href="news.html">News</a></li>
					<li class="menu_item menu_mm"><a href="contact.html">Contact</a></li>
				</ul>

				<!-- Menu Social -->
				
				<div class="menu_social_container menu_mm">
					<ul class="menu_social menu_mm">
						<li class="menu_social_item menu_mm"><a href="#"><i class="fab fa-pinterest"></i></a></li>
						<li class="menu_social_item menu_mm"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
						<li class="menu_social_item menu_mm"><a href="#"><i class="fab fa-instagram"></i></a></li>
						<li class="menu_social_item menu_mm"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
						<li class="menu_social_item menu_mm"><a href="#"><i class="fab fa-twitter"></i></a></li>
					</ul>
				</div>

				<div class="menu_copyright menu_mm">Colorlib All rights reserved</div>
			</div>

		</div>

	</div>
	
	<!-- Home -->

	<div class="home">

<!-- Hero Slider -->
<div class="hero_slider_container">
	<div class="hero_slider owl-carousel">
		
		<!-- Hero Slide -->
		<div class="hero_slide">
			<div class="hero_slide_background" style="background-image:url(images/slider_background.jpg)"></div>
			<div class="hero_slide_container d-flex flex-column align-items-center justify-content-center">
				<div class="hero_slide_content text-center">
					<h1 data-animation-in="fadeInUp" data-animation-out="animate-out fadeOut">Start Your <span>Learning Journey</span> Now!</h1>
				</div>
			</div>
		</div>
		
		<!-- Hero Slide -->
		<div class="hero_slide">
			<div class="hero_slide_background" style="background-image:url(images/slider_background.jpg)"></div>
			<div class="hero_slide_container d-flex flex-column align-items-center justify-content-center">
				<div class="hero_slide_content text-center">
					<h1 data-animation-in="fadeInUp" data-animation-out="animate-out fadeOut">Unlock Your <span>Potential</span> Today!</h1>
				</div>
			</div>
		</div>
		
		<!-- Hero Slide -->
		<div class="hero_slide">
			<div class="hero_slide_background" style="background-image:url(images/slider_background.jpg)"></div>
			<div class="hero_slide_container d-flex flex-column align-items-center justify-content-center">
				<div class="hero_slide_content text-center">
					<h1 data-animation-in="fadeInUp" data-animation-out="animate-out fadeOut">Empower Your <span>Future</span> with Knowledge!</h1>
				</div>
			</div>
		</div>

	</div>

	<div class="hero_slider_left hero_slider_nav trans_200"><span class="trans_200">prev</span></div>
	<div class="hero_slider_right hero_slider_nav trans_200"><span class="trans_200">next</span></div>
</div>


	</div>

	<div class="hero_boxes">
		<div class="hero_boxes_inner">
			<div class="container">
				<div class="row">

					<div class="col-lg-4 hero_box_col">
						<div class="hero_box d-flex flex-row align-items-center justify-content-start">
							<img src="images/earth-globe.svg" class="svg" alt="">
							<div class="hero_box_content">
								<h2 class="hero_box_title">Online Courses</h2>
								<a href="courses.html" class="hero_box_link">view more</a>
							</div>
						</div>
					</div>

					<div class="col-lg-4 hero_box_col">
						<div class="hero_box d-flex flex-row align-items-center justify-content-start">
							<img src="images/books.svg" class="svg" alt="">
							<div class="hero_box_content">
								<h2 class="hero_box_title">Our Library</h2>
								<a href="courses.html" class="hero_box_link">view more</a>
							</div>
						</div>
					</div>

					<div class="col-lg-4 hero_box_col">
						<div class="hero_box d-flex flex-row align-items-center justify-content-start">
							<img src="images/professor.svg" class="svg" alt="">
							<div class="hero_box_content">
								<h2 class="hero_box_title">Our Teachers</h2>
								<a href="teachers.html" class="hero_box_link">view more</a>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>
	</div>

	<!-- Popular -->
<div class="popular page_section">
	<div class="container">
		<div class="row">
			<div class="col">
				<div class="section_title text-center">
					<h1>Top Trending Courses</h1>
				</div>
			</div>
		</div>

		<div class="row course_boxes">
			
			<!-- Popular Course Item -->
			<div class="col-lg-4 course_box">
				<div class="card">
					<img class="card-img-top" src="images/course_1.jpg" alt="creativecoursehub.com">
					<div class="card-body text-center">
						<div class="card-title"><a href="courses.html">Mastering Graphic Design Basics</a></div>
						<div class="card-text">Learn layers, smart objects, and Adobe essentials...</div>
					</div>
					<div class="price_box d-flex flex-row align-items-center">
						<div class="course_author_image">
							<img src="images/author.jpg" alt="profile pic">
						</div>
						<div class="course_author_name">Jessica Lee, <span>Instructor</span></div>
						<div class="course_price d-flex flex-column align-items-center justify-content-center"><span>$34</span></div>
					</div>
				</div>
			</div>

			<!-- Popular Course Item -->
			<div class="col-lg-4 course_box">
				<div class="card">
					<img class="card-img-top" src="images/course_2.jpg" alt="creativecoursehub.com">
					<div class="card-body text-center">
						<div class="card-title"><a href="courses.html">HTML Fundamentals for Beginners</a></div>
						<div class="card-text">Get started with HTML5, structure, and basics...</div>
					</div>
					<div class="price_box d-flex flex-row align-items-center">
						<div class="course_author_image">
							<img src="images/author.jpg" alt="profile pic">
						</div>
						<div class="course_author_name">Jessica Lee, <span>Instructor</span></div>
						<div class="course_price d-flex flex-column align-items-center justify-content-center"><span>$34</span></div>
					</div>
				</div>
			</div>

			<!-- Popular Course Item -->
			<div class="col-lg-4 course_box">
				<div class="card">
					<img class="card-img-top" src="images/course_3.jpg" alt="creativecoursehub.com">
					<div class="card-body text-center">
						<div class="card-title"><a href="courses.html">Photoshop Techniques: Advanced</a></div>
						<div class="card-text">Explore advanced photo editing and effects...</div>
					</div>
					<div class="price_box d-flex flex-row align-items-center">
						<div class="course_author_image">
							<img src="images/author.jpg" alt="profile pic">
						</div>
						<div class="course_author_name">Jessica Lee, <span>Instructor</span></div>
						<div class="course_price d-flex flex-column align-items-center justify-content-center"><span>$34</span></div>
					</div>
				</div>
			</div>
		</div>
	</div>		
</div>


	<!-- Register -->
<div class="register">

	<div class="container-fluid">
		
		<div class="row row-eq-height">
			<div class="col-lg-6 nopadding">
				
				<!-- Register -->

				<div class="register_section d-flex flex-column align-items-center justify-content-center">
					<div class="register_content text-center">
						<h1 class="register_title">Sign up today and enjoy a <span>50%</span> limited-time offer</h1>
						<p class="register_text">Join now to advance your skills with expert-led courses designed for success. Don’t miss this exclusive opportunity to learn and grow professionally.</p>
						<div class="button button_1 register_button mx-auto trans_200"><a href="#">join now</a></div>
					</div>
				</div>

			</div>

			<div class="col-lg-6 nopadding">
				
				<!-- Search -->

				<div class="search_section d-flex flex-column align-items-center justify-content-center">
					<div class="search_background" style="background-image:url(images/search_background.jpg);"></div>
					<div class="search_content text-center">
						<h1 class="search_title">Find your ideal course</h1>
						<form id="search_form" class="search_form" action="post">
							<input id="search_form_name" class="input_field search_form_name" type="text" placeholder="Course Title" required="required" data-error="Course title is required.">
							<input id="search_form_category" class="input_field search_form_category" type="text" placeholder="Subject Area">
							<input id="search_form_degree" class="input_field search_form_degree" type="text" placeholder="Certification">
							<button id="search_submit_button" type="submit" class="search_submit_button trans_200" value="Submit">search courses</button>
						</form>
					</div> 
				</div>

			</div>
		</div>
	</div>
</div>


	<!-- Services -->
<div class="services page_section">
	
	<div class="container">
		<div class="row">
			<div class="col">
				<div class="section_title text-center">
					<h1>Our Education Solutions</h1>
				</div>
			</div>
		</div>

		<div class="row services_row">

			<div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
				<div class="icon_container d-flex flex-column justify-content-end">
					<img src="images/earth-globe.svg" alt="">
				</div>
				<h3>Interactive Online Learning</h3>
				<p>Experience flexible online classes with expert instructors and real-time engagement designed to fit your schedule.</p>
			</div>

			<div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
				<div class="icon_container d-flex flex-column justify-content-end">
					<img src="images/exam.svg" alt="">
				</div>
				<h3>On-Campus Workshops</h3>
				<p>Participate in hands-on courses and workshops held at our state-of-the-art facilities for immersive learning.</p>
			</div>

			<div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
				<div class="icon_container d-flex flex-column justify-content-end">
					<img src="images/books.svg" alt="">
				</div>
				<h3>Extensive Digital Library</h3>
				<p>Access a vast collection of resources, eBooks, and journals to support your academic and personal growth.</p>
			</div>

			<div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
				<div class="icon_container d-flex flex-column justify-content-end">
					<img src="images/professor.svg" alt="">
				</div>
				<h3>Expert Faculty Members</h3>
				<p>Learn from highly qualified professors who bring industry experience and passion to every course.</p>
			</div>

			<div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
				<div class="icon_container d-flex flex-column justify-content-end">
					<img src="images/blackboard.svg" alt="">
				</div>
				<h3>Comprehensive Degree Programs</h3>
				<p>Choose from a variety of accredited programs designed to prepare you for a successful career.</p>
			</div>

			<div class="col-lg-4 service_item text-left d-flex flex-column align-items-start justify-content-start">
				<div class="icon_container d-flex flex-column justify-content-end">
					<img src="images/mortarboard.svg" alt="">
				</div>
				<h3>Professional Certification</h3>
				<p>Earn recognized diplomas and certifications that enhance your qualifications and marketability.</p>
			</div>

		</div>
	</div>
</div>


	<!-- Testimonials -->
<div class="testimonials page_section">
	<!-- <div class="testimonials_background" style="background-image:url(images/testimonials_background.jpg)"></div> -->
	<div class="testimonials_background_container prlx_parent">
		<div class="testimonials_background prlx" style="background-image:url(images/testimonials_background.jpg)"></div>
	</div>
	<div class="container">

		<div class="row">
			<div class="col">
				<div class="section_title text-center">
					<h1>What Our Learners Are Saying</h1>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-lg-10 offset-lg-1">
				
				<div class="testimonials_slider_container">

					<!-- Testimonials Slider -->
					<div class="owl-carousel owl-theme testimonials_slider">
						
						<!-- Testimonials Item -->
						<div class="owl-item">
							<div class="testimonials_item text-center">
								<div class="quote">“</div>
								<p class="testimonials_text">This platform transformed my career with practical skills and expert guidance. The courses are flexible and engaging, perfect for busy schedules.</p>
								<div class="testimonial_user">
									<div class="testimonial_image mx-auto">
										<img src="images/testimonials_user.jpg" alt="">
									</div>
									<div class="testimonial_name">Emily Johnson</div>
									<div class="testimonial_title">Alumni</div>
								</div>
							</div>
						</div>

						<!-- Testimonials Item -->
						<div class="owl-item">
							<div class="testimonials_item text-center">
								<div class="quote">“</div>
								<p class="testimonials_text">The hands-on approach and expert instructors helped me master new skills quickly. Highly recommended for anyone seeking career growth.</p>
								<div class="testimonial_user">
									<div class="testimonial_image mx-auto">
										<img src="images/testimonials_user.jpg" alt="">
									</div>
									<div class="testimonial_name">David Lee</div>
									<div class="testimonial_title">Current Student</div>
								</div>
							</div>
						</div>

						<!-- Testimonials Item -->
						<div class="owl-item">
							<div class="testimonials_item text-center">
								<div class="quote">“</div>
								<p class="testimonials_text">The variety of courses and the supportive community made learning enjoyable and effective. I've gained valuable knowledge for my profession.</p>
								<div class="testimonial_user">
									<div class="testimonial_image mx-auto">
										<img src="images/testimonials_user.jpg" alt="">
									</div>
									<div class="testimonial_name">Sophia Martinez</div>
									<div class="testimonial_title">Professional Learner</div>
								</div>
							</div>
						</div>

					</div>

				</div>
			</div>
		</div>

	</div>
</div>


	<!-- Events -->

	<div class="events page_section">
		<div class="container">
			
			<div class="row">
				<div class="col">
					<div class="section_title text-center">
						<h1>Upcoming Events</h1>
					</div>
				</div>
			</div>
			
<div class="event_items">

	<!-- Event Item -->
	<div class="row event_item">
		<div class="col">
			<div class="row d-flex flex-row align-items-end">

				<div class="col-lg-2 order-lg-1 order-2">
					<div class="event_date d-flex flex-column align-items-center justify-content-center">
						<div class="event_day">15</div>
						<div class="event_month">March</div>
					</div>
				</div>

				<div class="col-lg-6 order-lg-2 order-3">
					<div class="event_content">
						<div class="event_name"><a class="trans_200" href="#">Virtual Tech Symposium 2025</a></div>
						<div class="event_location">Innovation Hub Online</div>
						<p>Join industry experts sharing insights on emerging technologies, coding trends, and digital innovation breakthroughs.</p>
					</div>
				</div>

				<div class="col-lg-4 order-lg-3 order-1">
					<div class="event_image">
						<img src="images/event_1.jpg" alt="">
					</div>
				</div>

			</div>	
		</div>
	</div>

	<!-- Event Item -->
	<div class="row event_item">
		<div class="col">
			<div class="row d-flex flex-row align-items-end">

				<div class="col-lg-2 order-lg-1 order-2">
					<div class="event_date d-flex flex-column align-items-center justify-content-center">
						<div class="event_day">22</div>
						<div class="event_month">April</div>
					</div>
				</div>

				<div class="col-lg-6 order-lg-2 order-3">
					<div class="event_content">
						<div class="event_name"><a class="trans_200" href="#">Open Source Contributors Meetup</a></div>
						<div class="event_location">Tech Campus Auditorium</div>
						<p>Network with open source enthusiasts, explore collaboration opportunities, and contribute to impactful projects.</p>
					</div>
				</div>

				<div class="col-lg-4 order-lg-3 order-1">
					<div class="event_image">
						<img src="images/event_2.jpg" alt="">
					</div>
				</div>

			</div>	
		</div>
	</div>

	<!-- Event Item -->
	<div class="row event_item">
		<div class="col">
			<div class="row d-flex flex-row align-items-end">

				<div class="col-lg-2 order-lg-1 order-2">
					<div class="event_date d-flex flex-column align-items-center justify-content-center">
						<div class="event_day">30</div>
						<div class="event_month">May</div>
					</div>
				</div>

				<div class="col-lg-6 order-lg-2 order-3">
					<div class="event_content">
						<div class="event_name"><a class="trans_200" href="#">Graduation & Coding Awards Ceremony</a></div>
						<div class="event_location">Main Hall, Innovation Center</div>
						<p>Celebrate the achievements of our students and recognize top performers in software development and design.</p>
					</div>
				</div>

				<div class="col-lg-4 order-lg-3 order-1">
					<div class="event_image">
						<img src="images/event_3.jpg" alt="">
					</div>
				</div>

			</div>	
		</div>
	</div>

</div>

				
		</div>
	</div>

	<!-- Footer -->

	<footer class="footer">
		<div class="container">
			
			<!-- Newsletter -->

			<div class="newsletter">
				<div class="row">
					<div class="col">
						<div class="section_title text-center">
							<h1>Subscribe to newsletter</h1>
						</div>
					</div>
				</div>

				<div class="row">
					<div class="col text-center">
						<div class="newsletter_form_container mx-auto">
							<form action="post">
								<div class="newsletter_form d-flex flex-md-row flex-column flex-xs-column align-items-center justify-content-center">
									<input id="newsletter_email" class="newsletter_email" type="email" placeholder="Email Address" required="required" data-error="Valid email is required.">
									<button id="newsletter_submit" type="submit" class="newsletter_submit_btn trans_300" value="Submit">Subscribe</button>
								</div>
							</form>
						</div>
					</div>
				</div>

			</div>

			<!-- Footer Content -->
<div class="footer_content">
	<div class="row">

		<!-- Footer Column - About -->
		<div class="col-lg-3 footer_col">

			<!-- Logo -->
			<div class="logo_container">
				<div class="logo">
					<img src="images/logo.png" alt="">
					<span>course</span>
				</div>
			</div>

			<p class="footer_about_text">Empowering learners worldwide with cutting-edge coding skills and expert-led courses for a successful tech career.</p>

		</div>

		<!-- Footer Column - Menu -->

		<div class="col-lg-3 footer_col">
			<div class="footer_column_title">Menu</div>
			<div class="footer_column_content">
				<ul>
					<li class="footer_list_item"><a href="#">Home</a></li>
					<li class="footer_list_item"><a href="#">Our Story</a></li>
					<li class="footer_list_item"><a href="courses.html">Programs</a></li>
					<li class="footer_list_item"><a href="news.html">Blog</a></li>
					<li class="footer_list_item"><a href="contact.html">Get in Touch</a></li>
				</ul>
			</div>
		</div>

		<!-- Footer Column - Usefull Links -->

		<div class="col-lg-3 footer_col">
			<div class="footer_column_title">Useful Links</div>
			<div class="footer_column_content">
				<ul>
					<li class="footer_list_item"><a href="#">Reviews</a></li>
					<li class="footer_list_item"><a href="#">Help Center</a></li>
					<li class="footer_list_item"><a href="#">Forum</a></li>
					<li class="footer_list_item"><a href="#">Gallery</a></li>
					<li class="footer_list_item"><a href="#">Tuition Fees</a></li>
				</ul>
			</div>
		</div>

		<!-- Footer Column - Contact -->

		<div class="col-lg-3 footer_col">
			<div class="footer_column_title">Contact</div>
			<div class="footer_column_content">
				<ul>
					<li class="footer_contact_item">
						<div class="footer_contact_icon">
							<img src="images/placeholder.svg" alt="">
						</div>
						123 Tech Avenue, Silicon Valley, CA 94043
					</li>
					<li class="footer_contact_item">
						<div class="footer_contact_icon">
							<img src="images/smartphone.svg" alt="">
						</div>
						+1 415 829 6732
					</li>
					<li class="footer_contact_item">
						<div class="footer_contact_icon">
							<img src="images/envelope.svg" alt="">
						</div>hello@techmerge.org
					</li>
				</ul>
			</div>
		</div>

	</div>
</div>

<!-- Footer Copyright -->

<div class="footer_bar d-flex flex-column flex-sm-row align-items-center">
	<div class="footer_copyright">
		<span>Copyright &copy;<script>document.write(new Date().getFullYear());</script> TechMerge Learning. All rights reserved.</span>
	</div>
	<div class="footer_social ml-sm-auto">
		<ul class="menu_social">
			<li class="menu_social_item"><a href="#"><i class="fab fa-pinterest"></i></a></li>
			<li class="menu_social_item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
			<li class="menu_social_item"><a href="#"><i class="fab fa-instagram"></i></a></li>
			<li class="menu_social_item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
			<li class="menu_social_item"><a href="#"><i class="fab fa-twitter"></i></a></li>
		</ul>
	</div>
</div>

</div>
</footer>


</div>

<script src="js/jquery-3.2.1.min.js"></script>
<script src="styles/bootstrap4/popper.js"></script>
<script src="styles/bootstrap4/bootstrap.min.js"></script>
<script src="plugins/greensock/TweenMax.min.js"></script>
<script src="plugins/greensock/TimelineMax.min.js"></script>
<script src="plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="plugins/greensock/animation.gsap.min.js"></script>
<script src="plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="plugins/scrollTo/jquery.scrollTo.min.js"></script>
<script src="plugins/easing/easing.js"></script>
<script src="js/custom.js"></script>

</body>
</html>