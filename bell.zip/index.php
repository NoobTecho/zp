<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Solvia — Crafted for Real Impact</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Facebook Opengraph integration: https://developers.facebook.com/docs/sharing/opengraph -->
  <meta property="og:title" content="">
  <meta property="og:image" content="">
  <meta property="og:url" content="">
  <meta property="og:site_name" content="">
  <meta property="og:description" content="">

  <!-- Twitter Cards integration: https://dev.twitter.com/cards/  -->
  <meta name="twitter:card" content="summary">
  <meta name="twitter:site" content="">
  <meta name="twitter:title" content="">
  <meta name="twitter:description" content="">
  <meta name="twitter:image" content="">

  <!-- Favicon -->
  <link href="img/favicon.ico" rel="icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Raleway:400,500,700|Roboto:400,900" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: Bell
    Theme URL: https://bootstrapmade.com/bell-free-bootstrap-4-template/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body>
  <!-- Page Content
    ================================================== -->
  <!-- Hero -->

<section class="hero">
  <div class="container text-center">
    <div class="row">
      <div class="col-md-12">
        <a class="hero-brand" href="index.html" title="Home">
          <img alt="Solvia" src="img/logo.png">
        </a>
      </div>
    </div>

    <div class="col-md-12">
      <h1>Design that speaks for itself</h1>
      <p class="tagline">
        Built to scale with your ideas. No fluff. Just a sharp, functional experience.
      </p>
      <a class="btn btn-full" href="#about">See how it works</a>
    </div>
  </div>
</section>
  <!-- /Hero -->

  <!-- Header -->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="index.html"><img src="img/logo-nav.png" alt="" title="" /></img></a>
        <!-- Uncomment below if you prefer to use a text image -->
        <!--<h1><a href="#hero">Bell</a></h1>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li><a href="#about">About Us</a></li>
          <li><a href="#features">Features</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
          <li><a href="#team">Team</a></li>
          <li class="menu-has-children"><a href="">Drop Down</a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
              <li><a href="#">Drop Down 5</a></li>
            </ul>
          </li>
          <li><a href="#contact">Contact Us</a></li>
        </ul>
      </nav>
      <!-- #nav-menu-container -->

      <nav class="nav social-nav pull-right d-none d-lg-inline">
        <a href="#"><i class="fa fa-twitter"></i></a> <a href="#"><i class="fa fa-facebook"></i></a> <a href="#"><i class="fa fa-linkedin"></i></a> <a href="#"><i class="fa fa-envelope"></i></a>
      </nav>
    </div>
  </header>
  <!-- #header -->

  <!-- About -->
<section class="about" id="about">
  <div class="container text-center">
    <h2>About Us</h2>

    <p>
      We’re a small team with bold ambition — building digital solutions that don’t just look great, but truly deliver results. From concept to launch, we focus on clarity, purpose, and user experience.
    </p>

    <div class="row stats-row">
      <div class="stats-col text-center col-md-3 col-sm-6">
        <div class="circle">
          <span class="stats-no" data-toggle="counter-up">232</span><br>
          Happy Clients
        </div>
      </div>

      <div class="stats-col text-center col-md-3 col-sm-6">
        <div class="circle">
          <span class="stats-no" data-toggle="counter-up">79</span><br>
          Projects Launched
        </div>
      </div>

      <div class="stats-col text-center col-md-3 col-sm-6">
        <div class="circle">
          <span class="stats-no" data-toggle="counter-up">1463</span><br>
          Hours Dedicated
        </div>
      </div>

      <div class="stats-col text-center col-md-3 col-sm-6">
        <div class="circle">
          <span class="stats-no" data-toggle="counter-up">15</span><br>
          Team Members
        </div>
      </div>
    </div>
  </div>
</section>

  <!-- /About -->
  <!-- Parallax -->

  <div class="block bg-primary block-pd-lg block-bg-overlay text-center" data-bg-img="img/parallax-bg.jpg" data-settings='{"stellar-background-ratio": 0.6}' data-toggle="parallax-bg">
    <h2>
        Welcome to a perfect theme
      </h2>

    <p>
      This is the most powerful theme with thousands of options that you have never seen before.
    </p>
    <img alt="Bell - A perfect theme" class="gadgets-img hidden-md-down" src="img/gadgets.png">
  </div>
  <!-- /Parallax -->
  <!-- Features -->
<section class="features" id="features">
  <div class="container">
    <h2 class="text-center">What We Bring to the Table</h2>

    <div class="row">
      <div class="feature-col col-lg-4 col-xs-12">
        <div class="card card-block text-center">
          <div class="feature-icon"><span class="fa fa-rocket"></span></div>
          <h3>Custom Design</h3>
          <p>Every project is crafted from scratch — no generic layouts, no copy-paste. Just clean, purpose-driven visuals.</p>
        </div>
      </div>

      <div class="feature-col col-lg-4 col-xs-12">
        <div class="card card-block text-center">
          <div class="feature-icon"><span class="fa fa-envelope"></span></div>
          <h3>Responsive Layout</h3>
          <p>Your product looks great everywhere. Mobile, tablet, desktop — we make sure of it.</p>
        </div>
      </div>

      <div class="feature-col col-lg-4 col-xs-12">
        <div class="card card-block text-center">
          <div class="feature-icon"><span class="fa fa-bell"></span></div>
          <h3>Fresh Ideas</h3>
          <p>We don’t follow trends — we create them. Expect ideas that stand out and make people remember.</p>
        </div>
      </div>
    </div>

    <div class="row">
      <div class="feature-col col-lg-4 col-xs-12">
        <div class="card card-block text-center">
          <div class="feature-icon"><span class="fa fa-database"></span></div>
          <h3>Clean Code</h3>
          <p>We build with clarity and future-proofing in mind. Easy to maintain, easy to scale.</p>
        </div>
      </div>

      <div class="feature-col col-lg-4 col-xs-12">
        <div class="card card-block text-center">
          <div class="feature-icon"><span class="fa fa-cutlery"></span></div>
          <h3>Built-in Essentials</h3>
          <p>We integrate only what matters: speed, SEO, and performance. No bloat — just function.</p>
        </div>
      </div>

      <div class="feature-col col-lg-4 col-xs-12">
        <div class="card card-block text-center">
          <div class="feature-icon"><span class="fa fa-dashboard"></span></div>
          <h3>Sharp Visuals</h3>
          <p>Everything we make is retina-ready — pixel-perfect, crisp, and future-facing.</p>
        </div>
      </div>
    </div>
  </div>
</section>

  <!-- /Features -->
  <!-- Call to Action -->

<section class="cta">
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-sm-12 text-lg-left text-center">
        <h2>Let’s Build Something Powerful Together</h2>
        <p>
          Whether you're launching a startup, upgrading a platform, or creating something bold — we’re ready to help bring your ideas to life.
        </p>
      </div>
      <div class="col-lg-3 col-sm-12 text-lg-right text-center">
        <a class="btn btn-ghost" href="#contact">Let’s Talk</a>
      </div>
    </div>
  </div>
</section>

  <!-- /Call to Action -->
  <!-- Portfolio -->
<section class="portfolio" id="portfolio">
  <div class="container text-center">
    <h2>Recent Work</h2>
    <p>Some of the projects we’ve brought to life — from sleek interfaces to fast, responsive platforms.</p>
  </div>

  <div class="portfolio-grid">
    <div class="row">
      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="E-commerce Dashboard" src="img/porf-1.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">E-commerce Dashboard</h3>
                <p class="card-text">A custom analytics interface for tracking product performance in real-time.</p>
              </div>
            </div></a>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="Creative Agency Site" src="img/porf-2.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">Creative Agency</h3>
                <p class="card-text">Designed a bold, responsive portfolio for a branding studio.</p>
              </div>
            </div></a>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="Portfolio Website" src="img/porf-3.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">Freelancer Portfolio</h3>
                <p class="card-text">Minimalist design with smooth scrolling and project showcase.</p>
              </div>
            </div></a>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="Restaurant Landing Page" src="img/porf-4.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">Food & Beverage</h3>
                <p class="card-text">Landing page for a new restaurant, built with speed and SEO in mind.</p>
              </div>
            </div></a>
        </div>
      </div>
    </div>

    <!-- row 2 (optional: kamu bisa hapus atau edit nama project) -->
    <div class="row">
      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="App Landing Page" src="img/porf-5.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">Mobile App Launch</h3>
                <p class="card-text">Clean, one-page design for a productivity app with CTA focus.</p>
              </div>
            </div></a>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="Business Landing" src="img/porf-6.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">SaaS Platform</h3>
                <p class="card-text">Front-end UI for a subscription-based analytics tool.</p>
              </div>
            </div></a>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="Personal Blog" src="img/porf-7.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">Tech Blog</h3>
                <p class="card-text">Fast-loading blog with Markdown support and custom comment system.</p>
              </div>
            </div></a>
        </div>
      </div>

      <div class="col-lg-3 col-sm-6 col-xs-12">
        <div class="card card-block">
          <a href="#"><img alt="Online Course Site" src="img/porf-8.jpg">
            <div class="portfolio-over">
              <div>
                <h3 class="card-title">Online Learning</h3>
                <p class="card-text">Educational platform with video courses, quizzes, and progress tracking.</p>
              </div>
            </div></a>
        </div>
      </div>
    </div>
  </div>
</section>

  <!-- /Portfolio -->
  <!-- Team -->
<section class="team" id="team">
  <div class="container">
    <h2 class="text-center">Meet the People Behind the Code</h2>

    <div class="row">
      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="Alex Rivera" class="team-img" src="img/team-1.jpg">
            <div class="card-title-wrap">
              <span class="card-title">Alex Rivera</span>
              <span class="card-text">Lead Developer</span>
            </div>
            <div class="team-over">
              <h4 class="hidden-md-down">Connect with Alex</h4>
              <nav class="social-nav">
                <a href="#"><i class="fa fa-github"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
                <a href="#"><i class="fa fa-envelope"></i></a>
              </nav>
              <p>Code ninja, passionate about automation and building tools that scale fast.</p>
            </div>
          </a>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="Maria Chen" class="team-img" src="img/team-2.jpg">
            <div class="card-title-wrap">
              <span class="card-title">Maria Chen</span>
              <span class="card-text">UI/UX Designer</span>
            </div>
            <div class="team-over">
              <h4 class="hidden-md-down">Connect with Maria</h4>
              <nav class="social-nav">
                <a href="#"><i class="fa fa-dribbble"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
                <a href="#"><i class="fa fa-envelope"></i></a>
              </nav>
              <p>Design thinker. Obsessive about pixels, smooth flows, and human-first interfaces.</p>
            </div>
          </a>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="Liam Brooks" class="team-img" src="img/team-3.jpg">
            <div class="card-title-wrap">
              <span class="card-title">Liam Brooks</span>
              <span class="card-text">Cloud Engineer</span>
            </div>
            <div class="team-over">
              <h4 class="hidden-md-down">Connect with Liam</h4>
              <nav class="social-nav">
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
                <a href="#"><i class="fa fa-envelope"></i></a>
              </nav>
              <p>Specialized in scalable infrastructure & cloud automation. Loves coffee & shell scripts.</p>
            </div>
          </a>
        </div>
      </div>

      <div class="col-sm-3 col-xs-6">
        <div class="card card-block">
          <a href="#"><img alt="Zoe Khan" class="team-img" src="img/team-4.jpg">
            <div class="card-title-wrap">
              <span class="card-title">Zoe Khan</span>
              <span class="card-text">Marketing Strategist</span>
            </div>
            <div class="team-over">
              <h4 class="hidden-md-down">Connect with Zoe</h4>
              <nav class="social-nav">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
                <a href="#"><i class="fa fa-envelope"></i></a>
              </nav>
              <p>Brand storyteller. Helps products find their voice and connect with real users.</p>
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>
</section>

  <!-- /Team -->
  <!-- @component: footer -->

  <section id="contact">
    <div class="container">
      <div class="row">
        <div class="col-md-12 text-center">
          <h2 class="section-title">Contact Us</h2>
        </div>
      </div>

      <div class="row justify-content-center">
        <div class="col-lg-3 col-md-4">
          <div class="info">
            <div>
              <i class="fa fa-map-marker"></i>
              <p>A108 Adam Street<br>New York, NY 535022</p>
            </div>

            <div>
              <i class="fa fa-envelope"></i>
              <p>info@example.com</p>
            </div>

            <div>
              <i class="fa fa-phone"></i>
              <p>+1 5589 55488 55s</p>
            </div>

          </div>
        </div>

        <div class="col-lg-5 col-md-8">
          <div class="form">
            <div id="sendmessage">Your message has been sent. Thank you!</div>
            <div id="errormessage"></div>
            <form action="" method="post" role="form" class="contactForm">
              <div class="form-group">
                <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                <div class="validation"></div>
              </div>
              <div class="form-group">
                <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                <div class="validation"></div>
              </div>
              <div class="text-center"><button type="submit">Send Message</button></div>
            </form>
          </div>
        </div>

      </div>
    </div>
  </section>
<footer class="site-footer">
  <div class="bottom">
    <div class="container">
      <div class="row">

        <div class="col-lg-6 col-xs-12 text-lg-left text-center">
          <p class="copyright-text">
            &copy; 2025 Crafted with 💻 by the Team
          </p>
          <div class="credits">
            Building tools for curious minds — no templates, just vision.
          </div>
        </div>

        <div class="col-lg-6 col-xs-12 text-lg-right text-center">
          <ul class="list-inline">
            <li class="list-inline-item">
              <a href="index.html">Home</a>
            </li>
            <li class="list-inline-item">
              <a href="#about">About</a>
            </li>
            <li class="list-inline-item">
              <a href="#features">Features</a>
            </li>
            <li class="list-inline-item">
              <a href="#portfolio">Works</a>
            </li>
            <li class="list-inline-item">
              <a href="#team">Crew</a>
            </li>
            <li class="list-inline-item">
              <a href="#contact">Get in Touch</a>
            </li>
          </ul>
        </div>

      </div>
    </div>
  </div>
</footer>

  <a class="scrolltop" href="#"><span class="fa fa-angle-up"></span></a>


  <!-- Required JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/jquery/jquery-migrate.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/tether/js/tether.min.js"></script>
  <script src="lib/stellar/stellar.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="lib/counterup/counterup.min.js"></script>
  <script src="lib/waypoints/waypoints.min.js"></script>
  <script src="lib/easing/easing.js"></script>
  <script src="lib/stickyjs/sticky.js"></script>
  <script src="lib/parallax/parallax.js"></script>
  <script src="lib/lockfixed/lockfixed.min.js"></script>

  <!-- Template Specisifc Custom Javascript File -->
  <script src="js/custom.js"></script>

  <script src="contactform/contactform.js"></script>

</body>
</html>
