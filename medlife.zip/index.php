<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title  -->
    <title>Medilife — Because Health Isn’t Optional</title>


    <!-- Favicon  -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Style CSS -->
    <link rel="stylesheet" href="style.css">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="medilife-load"></div>
    </div>

    <!-- ***** Header Area Start ***** -->
    <header class="header-area">
        <!-- Top Header Area -->
        <div class="top-header-area">
            <div class="container h-100">
                <div class="row h-100">
                    <div class="col-12 h-100">
                        <div class="h-100 d-md-flex justify-content-between align-items-center">
                            <p>Welcome to <span>Medifile</span> template</p>
                            <p>Opening Hours : Monday to Saturday - 8am to 10pm Contact : <span>+12-823-611-8721</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Header Area -->
        <div class="main-header-area" id="stickyHeader">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12 h-100">
                        <div class="main-menu h-100">
                            <nav class="navbar h-100 navbar-expand-lg">
                                <!-- Logo Area  -->
                                <a class="navbar-brand" href="index.html"><img src="img/core-img/logo.png" alt="Logo"></a>

                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#medilifeMenu" aria-controls="medilifeMenu" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>

                                <div class="collapse navbar-collapse" id="medilifeMenu">
                                    <!-- Menu Area -->
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item active">
                                            <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
                                            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                                <a class="dropdown-item" href="index.html">Home</a>
                                                <a class="dropdown-item" href="about-us.html">About Us</a>
                                                <a class="dropdown-item" href="services.html">Services</a>
                                                <a class="dropdown-item" href="blog.html">News</a>
                                                <a class="dropdown-item" href="single-blog.html">News Details</a>
                                                <a class="dropdown-item" href="contact.html">Contact</a>
                                                <a class="dropdown-item" href="elements.html">Elements</a>
                                                <a class="dropdown-item" href="index-icons.html">All Icons</a>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about-us.html">About Us</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="services.html">Services</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blog.html">News</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="contact.html">Contact</a>
                                        </li>
                                    </ul>
                                    <!-- Appointment Button -->
                                    <a href="#" class="btn medilife-appoint-btn ml-30">For <span>emergencies</span> Click here</a>
                                </div>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Hero Area Start ***** -->
<!-- ***** Hero Area Start ***** -->
<section class="hero-area">
    <div class="hero-slides owl-carousel">

        <!-- Slide 1 -->
        <div class="single-hero-slide bg-img bg-overlay-white" style="background-image: url(img/bg-img/hero1.jpg);">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="hero-slides-content">
                            <h2 data-animation="fadeInUp" data-delay="100ms">Your Health. Our Purpose.</h2>
                            <h6 data-animation="fadeInUp" data-delay="400ms">Compassionate care, real results — from check-ups to life-changing moments.</h6>
                            <a href="#" class="btn medilife-btn mt-50" data-animation="fadeInUp" data-delay="700ms">Meet Medilife <span>+</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 2 -->
        <div class="single-hero-slide bg-img bg-overlay-white" style="background-image: url(img/bg-img/breadcumb3.jpg);">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="hero-slides-content">
                            <h2 data-animation="fadeInUp" data-delay="100ms">Feel Better. Live Stronger.</h2>
                            <h6 data-animation="fadeInUp" data-delay="400ms">A new standard in medical support, tailored for real people and real life.</h6>
                            <a href="#" class="btn medilife-btn mt-50" data-animation="fadeInUp" data-delay="700ms">Start Your Journey <span>+</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Slide 3 -->
        <div class="single-hero-slide bg-img bg-overlay-white" style="background-image: url(img/bg-img/breadcumb1.jpg);">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-12">
                        <div class="hero-slides-content">
                            <h2 data-animation="fadeInUp" data-delay="100ms">Not Just Treatment. Transformation.</h2>
                            <h6 data-animation="fadeInUp" data-delay="400ms">Beyond medicine — we’re here to listen, guide, and heal with heart.</h6>
                            <a href="#" class="btn medilife-btn mt-50" data-animation="fadeInUp" data-delay="700ms">Explore Medilife <span>+</span></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</section>

    <!-- ***** Hero Area End ***** -->

    <!-- ***** Book An Appoinment Area Start ***** -->
<div class="medilife-book-an-appoinment-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="appointment-form-content">
                    <div class="row no-gutters align-items-center">
                        <div class="col-12 col-lg-9">
                            <div class="medilife-appointment-form">
                                <form action="#" method="post">
                                    <div class="row align-items-end">
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <select class="form-control" id="speciality">
                                                    <option>Select a Service</option>
                                                    <option>Cardiology</option>
                                                    <option>Dermatology</option>
                                                    <option>Neurology</option>
                                                    <option>Pediatrics</option>
                                                    <option>Radiology</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <select class="form-control" id="doctors">
                                                    <option>Choose a Doctor</option>
                                                    <option>Dr. Andrews</option>
                                                    <option>Dr. Carter</option>
                                                    <option>Dr. Reyes</option>
                                                    <option>Dr. Bennett</option>
                                                    <option>Dr. Lawson</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-2">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="date" id="date" placeholder="MM/DD/YYYY">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-2">
                                            <div class="form-group">
                                                <input type="text" class="form-control" name="time" id="time" placeholder="HH:MM">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <input type="text" class="form-control border-top-0 border-right-0 border-left-0" name="name" id="name" placeholder="Full Name">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <input type="text" class="form-control border-top-0 border-right-0 border-left-0" name="number" id="number" placeholder="Phone Number">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-4">
                                            <div class="form-group">
                                                <input type="email" class="form-control border-top-0 border-right-0 border-left-0" name="email" id="email" placeholder="Email Address">
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-7">
                                            <div class="form-group mb-0">
                                                <textarea name="message" class="form-control mb-0 border-top-0 border-right-0 border-left-0" id="message" cols="30" rows="10" placeholder="Any specific notes or requests?"></textarea>
                                            </div>
                                        </div>
                                        <div class="col-12 col-md-5 mb-0">
                                            <div class="form-group mb-0">
                                                <button type="submit" class="btn medilife-btn">Confirm Appointment <span>+</span></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <div class="col-12 col-lg-3">
                            <div class="medilife-contact-info">
                                <div class="single-contact-info mb-30">
                                    <img src="img/icons/alarm-clock.png" alt="">
                                    <p>Open: Mon–Sat 8AM–9PM<br>Closed: Sundays</p>
                                </div>
                                <div class="single-contact-info mb-30">
                                    <img src="img/icons/envelope.png" alt="">
                                    <p>+1 800 123 4567<br>support@medilife.com</p>
                                </div>
                                <div class="single-contact-info">
                                    <img src="img/icons/map-pin.png" alt="">
                                    <p>725 Grand Ave<br>Brooklyn, NY 11238</p>
                                </div>
                            </div>
                        </div>
                    </div> <!-- /.row -->
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- ***** Book An Appoinment Area End ***** -->
<!-- ***** About Section Custom ***** -->
<section class="medica-about-us-area section-padding-100-20">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4">
                <div class="medica-about-content">
                    <h2>Care isn’t just a word here</h2>
                    <p>Our focus stays on people, not procedures. From the first step through the door, we aim to make every visit feel personal and reassuring — not routine. When it comes to health, nothing should feel standard.</p>
                    <a href="#" class="btn medilife-btn mt-50">Explore our work <span>+</span></a>
                </div>
            </div>
            <div class="col-12 col-lg-8">
                <div class="row">
                    <!-- Custom Service -->
                    <div class="col-12 col-sm-6">
                        <div class="single-service-area d-flex">
                            <div class="service-icon">
                                <i class="icon-doctor"></i>
                            </div>
                            <div class="service-content">
                                <h5>Trusted Professionals</h5>
                                <p>Each member of our team brings both medical expertise and human empathy to the table. You're in capable, caring hands.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Custom Service -->
                    <div class="col-12 col-sm-6">
                        <div class="single-service-area d-flex">
                            <div class="service-icon">
                                <i class="icon-blood-donation-1"></i>
                            </div>
                            <div class="service-content">
                                <h5>Newborn Care</h5>
                                <p>We provide gentle, thorough care for the newest lives — with modern nursery support and trained pediatric staff.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Custom Service -->
                    <div class="col-12 col-sm-6">
                        <div class="single-service-area d-flex">
                            <div class="service-icon">
                                <i class="icon-flask-2"></i>
                            </div>
                            <div class="service-content">
                                <h5>In-House Lab</h5>
                                <p>Fast diagnostics matter. Our on-site labs help cut wait times and keep your treatment moving forward without delays.</p>
                            </div>
                        </div>
                    </div>
                    <!-- Custom Service -->
                    <div class="col-12 col-sm-6">
                        <div class="single-service-area d-flex">
                            <div class="service-icon">
                                <i class="icon-emergency-call-1"></i>
                            </div>
                            <div class="service-content">
                                <h5>Emergency Access</h5>
                                <p>24/7 support when it counts the most. Our ER team is trained to act fast and treat smarter — no time wasted.</p>
                            </div>
                        </div>
                    </div>
                </div> <!-- /row -->
            </div>
        </div>
    </div>
</section>

    <!-- ***** About Us Area End ***** -->
<!-- ***** Cool Facts Custom Section ***** -->
<section class="medilife-cool-facts-area section-padding-100-0">
    <div class="container">
        <div class="row">
            <!-- Fact Box -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-cool-fact-area text-center mb-100">
                    <i class="icon-blood-transfusion-2"></i>
                    <h2><span class="counter">5632</span></h2>
                    <h6>Donated Units</h6>
                    <p>Thousands of lives touched through consistent blood drives organized across the region.</p>
                </div>
            </div>
            <!-- Fact Box -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-cool-fact-area text-center mb-100">
                    <i class="icon-atoms"></i>
                    <h2><span class="counter">23</span>k</h2>
                    <h6>Patients Helped</h6>
                    <p>Real people. Real recoveries. Every case matters — and that’s our daily motivation.</p>
                </div>
            </div>
            <!-- Fact Box -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-cool-fact-area text-center mb-100">
                    <i class="icon-microscope"></i>
                    <h2><span class="counter">25</span></h2>
                    <h6>Medical Fields</h6>
                    <p>From cardiology to pediatrics — we cover a wide spectrum of care under one roof.</p>
                </div>
            </div>
            <!-- Fact Box -->
            <div class="col-12 col-sm-6 col-lg-3">
                <div class="single-cool-fact-area text-center mb-100">
                    <i class="icon-doctor-1"></i>
                    <h2><span class="counter">723</span></h2>
                    <h6>Qualified Experts</h6>
                    <p>Behind every diagnosis is a team of sharp minds with hearts in the right place.</p>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- ***** Cool Facts Area End ***** -->

    <!-- ***** Gallery Area Start ***** -->
    <div class="medilife-gallery-area owl-carousel">
        <!-- Single Gallery Item -->
        <div class="single-gallery-item">
            <img src="img/bg-img/g1.jpg" alt="">
            <div class="view-more-btn">
                <a href="img/bg-img/g1.jpg" class="btn gallery-img">See More +</a>
            </div>
        </div>
        <!-- Single Gallery Item -->
        <div class="single-gallery-item">
            <img src="img/bg-img/g2.jpg" alt="">
            <div class="view-more-btn">
                <a href="img/bg-img/g2.jpg" class="btn gallery-img">See More +</a>
            </div>
        </div>
        <!-- Single Gallery Item -->
        <div class="single-gallery-item">
            <img src="img/bg-img/g3.jpg" alt="">
            <div class="view-more-btn">
                <a href="img/bg-img/g3.jpg" class="btn gallery-img">See More +</a>
            </div>
        </div>

        <!-- Single Gallery Item -->
        <div class="single-gallery-item">
            <img src="img/bg-img/g4.jpg" alt="">
            <div class="view-more-btn">
                <a href="img/bg-img/g4.jpg" class="btn gallery-img">See More +</a>
            </div>
        </div>
    </div>
    <!-- ***** Gallery Area End ***** -->
<!-- ***** Features Area Start ***** -->
<div class="medilife-features-area section-padding-100">
    <div class="container">
        <div class="row align-items-center">
            <!-- Text Content -->
            <div class="col-12 col-lg-6">
                <div class="features-content">
                    <h2>Redefining Healthcare Inside a Next-Gen Medical Hub</h2>
                    <p>Imagine walking into a facility where innovation meets compassion. Every wall, every tool, and every treatment protocol is designed not just to cure — but to elevate the experience of healing. We combine cutting-edge diagnostics with personalized care, so each patient is treated like a priority, not a number.</p>
                    <p>This isn't just medicine. It's a smarter, faster, more human approach to wellness — where science and empathy work hand in hand.</p>
                    <a href="#" class="btn medilife-btn mt-50">View the services <span>+</span></a>
                </div>
            </div>
            <!-- Image Content -->
            <div class="col-12 col-lg-6">
                <div class="features-thumbnail">
                    <img src="img/bg-img/medical1.png" alt="Futuristic Medical Facility">
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- ***** Features Area End ***** -->
<!-- ***** Blog Area Start ***** -->
<div class="medilife-blog-area section-padding-100-0">
    <div class="container">
        <div class="row">
            <!-- Single Blog Area -->
            <div class="col-12 col-md-6 col-lg-4">
                <div class="single-blog-area mb-100">
                    <!-- Post Thumbnail -->
                    <div class="blog-post-thumbnail">
                        <img src="img/blog-img/1.jpg" alt="New Drug Launch">
                        <div class="post-date">
                            <a href="#">Mar 04, 2025</a>
                        </div>
                    </div>
                    <!-- Post Content -->
                    <div class="post-content">
                        <div class="post-author">
                            <a href="#"><img src="img/blog-img/p1.jpg" alt="Dr. Linh"></a>
                        </div>
                        <a href="#" class="headline">Breakthrough Drug to Hit Market This Month</a>
                        <p>A revolutionary treatment for chronic pain is now entering its final phase. Experts say this could change millions of lives worldwide.</p>
                        <a href="#" class="comments">14 Comments</a>
                    </div>
                </div>
            </div>

            <!-- Single Blog Area -->
            <div class="col-12 col-md-6 col-lg-4">
                <div class="single-blog-area mb-100">
                    <!-- Post Thumbnail -->
                    <div class="blog-post-thumbnail">
                        <img src="img/blog-img/2.jpg" alt="Free Dental Clinic">
                        <div class="post-date">
                            <a href="#">Mar 01, 2025</a>
                        </div>
                    </div>
                    <!-- Post Content -->
                    <div class="post-content">
                        <div class="post-author">
                            <a href="#"><img src="img/blog-img/p2.jpg" alt="Nurse Angela"></a>
                        </div>
                        <a href="#" class="headline">City Opens Free Dental Week for All Ages</a>
                        <p>From March 10th to 17th, local clinics will provide free dental exams and cleaning services — no insurance required.</p>
                        <a href="#" class="comments">9 Comments</a>
                    </div>
                </div>
            </div>

            <!-- Single Blog Area -->
            <div class="col-12 col-md-6 col-lg-4">
                <div class="single-blog-area mb-100">
                    <!-- Post Thumbnail -->
                    <div class="blog-post-thumbnail">
                        <img src="img/blog-img/3.jpg" alt="Patient Portal Update">
                        <div class="post-date">
                            <a href="#">Feb 26, 2025</a>
                        </div>
                    </div>
                    <!-- Post Content -->
                    <div class="post-content">
                        <div class="post-author">
                            <a href="#"><img src="img/blog-img/p3.jpg" alt="Tech Team"></a>
                        </div>
                        <a href="#" class="headline">New Patient Dashboard Goes Live</a>
                        <p>The latest update lets you book appointments, access records, and chat with doctors — all in one smart platform.</p>
                        <a href="#" class="comments">22 Comments</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- ***** Blog Area End ***** -->
<!-- ***** Emergency Area Start ***** -->
<div class="medilife-emergency-area section-padding-100-50">
    <div class="container">
        <div class="row">
            <!-- Emergency Intro -->
            <div class="col-12 col-lg-6">
                <div class="emergency-content">
                    <i class="icon-smartphone"></i>
                    <h2>24/7 Emergency Hotline</h2>
                    <h3>+1 (800) 999-9110</h3>
                    <p>Call us immediately in case of any critical medical situation. Our team is ready to respond round-the-clock across all locations.</p>
                </div>
            </div>

            <!-- Emergency Locations -->
            <div class="col-12 col-lg-6">
                <div class="row">
                    <!-- London -->
                    <div class="col-12 col-sm-6">
                        <div class="single-emergency-helpline mb-50">
                            <h5>London Clinic</h5>
                            <p>+44 20 7946 0958 <br> london@medilife.org <br> 42 Baker Street <br> London W1U 7BW</p>
                        </div>
                    </div>
                    <!-- New York -->
                    <div class="col-12 col-sm-6">
                        <div class="single-emergency-helpline mb-50">
                            <h5>New York Center</h5>
                            <p>+1 212 555 0110 <br> nyc@medilife.org <br> 120 W 44th St <br> New York, NY 10036</p>
                        </div>
                    </div>
                    <!-- Sydney -->
                    <div class="col-12 col-sm-6">
                        <div class="single-emergency-helpline mb-50">
                            <h5>Sydney Branch</h5>
                            <p>+61 2 9374 4000 <br> sydney@medilife.org <br> 7 Macquarie St <br> Sydney NSW 2000</p>
                        </div>
                    </div>
                    <!-- Tokyo -->
                    <div class="col-12 col-sm-6">
                        <div class="single-emergency-helpline mb-50">
                            <h5>Tokyo Division</h5>
                            <p>+81 3 1234 5678 <br> tokyo@medilife.org <br> 2 Chome-2-1 Marunouchi <br> Tokyo 100-0005</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- ***** Emergency Area End ***** -->

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area section-padding-100">
        <!-- Main Footer Area -->
   <div class="main-footer-area">
    <div class="container-fluid">
        <div class="row">

            <!-- About Section -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="footer-widget-area">
                    <div class="footer-logo">
                        <img src="img/core-img/logo.png" alt="Medilife Logo">
                    </div>
                    <p>Medilife combines world-class healthcare with modern technology and personal attention. Our mission is to provide accessible, affordable, and exceptional medical services for everyone.</p>
                    <div class="footer-social-info">
                        <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-pinterest" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>

            <!-- Latest News -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="footer-widget-area">
                    <div class="widget-title">
                        <h6>Latest News</h6>
                    </div>
                    <div class="widget-blog-post">
                        <div class="widget-single-blog-post d-flex">
                            <div class="widget-post-thumbnail">
                                <img src="img/blog-img/ln1.jpg" alt="">
                            </div>
                            <div class="widget-post-content">
                                <a href="#">AI-Powered Diagnostics</a>
                                <p>June 10, 2025</p>
                            </div>
                        </div>
                        <div class="widget-single-blog-post d-flex">
                            <div class="widget-post-thumbnail">
                                <img src="img/blog-img/ln2.jpg" alt="">
                            </div>
                            <div class="widget-post-content">
                                <a href="#">Breakthrough in Cancer Research</a>
                                <p>May 28, 2025</p>
                            </div>
                        </div>
                        <div class="widget-single-blog-post d-flex">
                            <div class="widget-post-thumbnail">
                                <img src="img/blog-img/ln3.jpg" alt="">
                            </div>
                            <div class="widget-post-content">
                                <a href="#">Mental Health Focus Week</a>
                                <p>May 15, 2025</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="footer-widget-area">
                    <div class="widget-title">
                        <h6>Contact Form</h6>
                    </div>
                    <div class="footer-contact-form">
                        <form action="#" method="post">
                            <input type="text" class="form-control border-top-0 border-right-0 border-left-0" name="footer-name" id="footer-name" placeholder="Your Name">
                            <input type="email" class="form-control border-top-0 border-right-0 border-left-0" name="footer-email" id="footer-email" placeholder="Your Email">
                            <textarea name="message" class="form-control border-top-0 border-right-0 border-left-0" id="footerMessage" placeholder="Your Message"></textarea>
                            <button type="submit" class="btn medilife-btn">Send Message <span>+</span></button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Newsletter -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="footer-widget-area">
                    <div class="widget-title">
                        <h6>Subscribe to Newsletter</h6>
                    </div>
                    <div class="footer-newsletter-area">
                        <form action="#">
                            <input type="email" class="form-control border-0 mb-0" name="newsletterEmail" id="newsletterEmail" placeholder="Enter your email">
                            <button type="submit">Subscribe</button>
                        </form>
                        <p>Stay informed about new medical services, health tips, and special offers from Medilife directly to your inbox every month.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- Bottom Footer Area -->
<div class="bottom-footer-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="bottom-footer-content d-flex flex-column flex-md-row justify-content-between align-items-center">
                    
                    <!-- Copyright Text -->
                    <div class="copywrite-text text-center text-md-left mb-2 mb-md-0">
                        <p>&copy; <script>document.write(new Date().getFullYear());</script> Medilife. All Rights Reserved.</p>
                    </div>

                    <!-- Optional Credit or Version -->
                    <div class="footer-meta text-center text-md-right">
                        <p>Powered by Medilife Template v2.0 | Crafted with <i class="fa fa-heart text-danger"></i> for modern healthcare</p>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

</body>

</html>