<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
<title>Imperial</title>

  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="keywords">
  <meta content="" name="description">

  <!-- Facebook Opengraph integration: https://developers.facebook.com/docs/sharing/opengraph -->
  <meta property="og:title" content="">
  <meta property="og:image" content="">
  <meta property="og:url" content="">
  <meta property="og:site_name" content="">
  <meta property="og:description" content="">

  <!-- Twitter Cards integration: https://dev.twitter.com/cards/  -->
  <meta name="twitter:card" content="summary">
  <meta name="twitter:site" content="">
  <meta name="twitter:title" content="">
  <meta name="twitter:description" content="">
  <meta name="twitter:image" content="">

  <!-- Place your favicon.ico and apple-touch-icon.png in the template root directory -->
  <link href="favicon.ico" rel="shortcut icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i|Raleway:300,400,500,700,800" rel="stylesheet">

  <!-- Bootstrap CSS File -->
  <link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Libraries CSS Files -->
  <link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="lib/animate-css/animate.min.css" rel="stylesheet">

  <!-- Main Stylesheet File -->
  <link href="css/style.css" rel="stylesheet">

  <!-- =======================================================
    Theme Name: Imperial
    Theme URL: https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/
    Author: BootstrapMade.com
    Author URL: https://bootstrapmade.com
  ======================================================= -->
</head>

<body>
  <div id="preloader"></div>

  <!--==========================
  Hero Section
  ============================-->
  <section id="hero">
    <div class="hero-container">
      <div class="wow fadeIn">
        <div class="hero-logo">
          <img class="" src="img/logo.png" alt="Imperial">
        </div>

        <h1>Welcome to Imperial studios</h1>
        <h2>We create <span class="rotating">beautiful graphics, functional websites, working mobile apps</span></h2>
        <div class="actions">
          <a href="#about" class="btn-get-started">Get Strated</a>
          <a href="#services" class="btn-services">Our Services</a>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Header Section
  ============================-->
  <header id="header">
    <div class="container">

      <div id="logo" class="pull-left">
        <a href="#hero"><img src="img/logo.png" alt="" title="" /></img></a>
        <!-- Uncomment below if you prefer to use a text image -->
        <!--<h1><a href="#hero">Header 1</a></h1>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="#hero">Home</a></li>
          <li><a href="#about">About Us</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#portfolio">Portfolio</a></li>
          <li><a href="#testimonials">Testimonials</a></li>
          <li><a href="#team">Team</a></li>
          <li class="menu-has-children"><a href="">Drop Down</a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="menu-has-children"><a href="#">Drop Down 2</a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
              <li><a href="#">Drop Down 5</a></li>
            </ul>
          </li>
          <li><a href="#contact">Contact Us</a></li>
        </ul>
      </nav>
      <!-- #nav-menu-container -->
    </div>
  </header>
  <!-- #header -->

  <!--==========================
  About Section
  ============================-->
  <section id="about">
  <div class="container wow fadeInUp">
    <div class="row">
      <div class="col-md-12 text-center">
        <h3 class="section-title">About Us</h3>
        <div class="section-title-divider"></div>
        <p class="section-description">
          We’re committed to delivering exceptional services and innovative ideas that drive success.
        </p>
      </div>
    </div>
  </div>
  <div class="container about-container wow fadeInUp">
    <div class="row">
      <div class="col-md-6 offset-md-6 about-content">
        <h2 class="about-title">Great Services Backed by Strong Ideas</h2>
        <p class="about-text">
          Our team works with dedication and creativity, ensuring each project is crafted with precision and care.
        </p>
        <p class="about-text">
          We believe in collaboration and transparency to achieve the best results tailored to your needs.
        </p>
        <p class="about-text">
          Customer satisfaction is our priority, and we continuously improve to deliver top-notch solutions.
        </p>
      </div>
    </div>
  </div>
</section>


  <!--==========================
  Services Section
  ============================-->
 <section id="services">
  <div class="container wow fadeInUp">
    <div class="row">
      <div class="col-md-12 text-center">
        <h3 class="section-title">Our Services</h3>
        <div class="section-title-divider"></div>
        <p class="section-description">
          We offer a range of tailored solutions designed to meet your unique business needs.
        </p>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4 service-item">
        <div class="service-icon"><i class="fa fa-desktop"></i></div>
        <h4 class="service-title"><a href="#">Web Development</a></h4>
        <p class="service-description">
          Crafting responsive and user-friendly websites that help your business stand out online.
        </p>
      </div>

      <div class="col-md-4 service-item">
        <div class="service-icon"><i class="fa fa-bar-chart"></i></div>
        <h4 class="service-title"><a href="#">Data Analytics</a></h4>
        <p class="service-description">
          Turning data into actionable insights to drive smarter decisions and growth.
        </p>
      </div>

      <div class="col-md-4 service-item">
        <div class="service-icon"><i class="fa fa-paper-plane"></i></div>
        <h4 class="service-title"><a href="#">Digital Marketing</a></h4>
        <p class="service-description">
          Expanding your reach with targeted campaigns that connect with your audience.
        </p>
      </div>

      <div class="col-md-4 service-item">
        <div class="service-icon"><i class="fa fa-photo"></i></div>
        <h4 class="service-title"><a href="#">Graphic Design</a></h4>
        <p class="service-description">
          Creating compelling visuals to communicate your brand’s message effectively.
        </p>
      </div>

      <div class="col-md-4 service-item">
        <div class="service-icon"><i class="fa fa-road"></i></div>
        <h4 class="service-title"><a href="#">Consulting</a></h4>
        <p class="service-description">
          Providing expert advice to help you navigate business challenges and opportunities.
        </p>
      </div>

      <div class="col-md-4 service-item">
        <div class="service-icon"><i class="fa fa-shopping-bag"></i></div>
        <h4 class="service-title"><a href="#">E-Commerce Solutions</a></h4>
        <p class="service-description">
          Building seamless online stores that boost your sales and customer engagement.
        </p>
      </div>
    </div>
  </div>
</section>

  <!--==========================
  Subscrbe Section
  ============================-->
  <section id="subscribe">
    <div class="container wow fadeInUp">
      <div class="row">
        <div class="col-md-8">
          <h3 class="subscribe-title">Subscribe For Updates</h3>
          <p class="subscribe-text">Join our 1000+ subscribers and get access to the latest tools, freebies, product announcements and much more!</p>
        </div>
        <div class="col-md-4 subscribe-btn-container">
          <a class="subscribe-btn" href="#">Subscribe Now</a>
        </div>
      </div>
    </div>
  </section>

  <!--==========================
  Porfolio Section
  ============================-->
  <section id="portfolio">
  <div class="container wow fadeInUp">
    <div class="row">
      <div class="col-md-12 text-center">
        <h3 class="section-title">Our Portfolio</h3>
        <div class="section-title-divider"></div>
        <p class="section-description">
          A showcase of our recent projects demonstrating creativity and quality.
        </p>
      </div>
    </div>

    <div class="row">
      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-1.jpg);" href="#">
          <div class="details">
            <h4>Modern Workspace</h4>
            <span>Office Design</span>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-2.jpg);" href="#">
          <div class="details">
            <h4>Brand Identity</h4>
            <span>Logo & Branding</span>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-3.jpg);" href="#">
          <div class="details">
            <h4>Mobile App</h4>
            <span>User Interface</span>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-4.jpg);" href="#">
          <div class="details">
            <h4>Creative Campaign</h4>
            <span>Marketing</span>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-5.jpg);" href="#">
          <div class="details">
            <h4>eCommerce Website</h4>
            <span>Web Development</span>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-6.jpg);" href="#">
          <div class="details">
            <h4>Event Branding</h4>
            <span>Design & Print</span>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-7.jpg);" href="#">
          <div class="details">
            <h4>Photography</h4>
            <span>Visual Storytelling</span>
          </div>
        </a>
      </div>

      <div class="col-md-3">
        <a class="portfolio-item" style="background-image: url(img/portfolio-8.jpg);" href="#">
          <div class="details">
            <h4>Product Design</h4>
            <span>Innovation</span>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>


  <!--==========================
  Testimonials Section
  ============================-->
  <section id="testimonials">
  <div class="container wow fadeInUp">
    <div class="row text-center">
      <div class="col-md-12">
        <h3 class="section-title">Testimonials</h3>
        <div class="section-title-divider"></div>
        <p class="section-description">
          What our clients say about working with us.
        </p>
      </div>
    </div>

    <div class="row align-items-center my-4">
      <div class="col-md-3 text-center">
        <div class="profile">
          <div class="pic">
            <img src="img/client-1.jpg" alt="Saul Goodman">
          </div>
          <h4>Saul Goodman</h4>
          <span>Lawless Inc</span>
        </div>
      </div>
      <div class="col-md-9">
        <div class="quote">
          <b><img src="img/quote_sign_left.png" alt="Quote Left"></b>
          Working with this team was a game changer. Their attention to detail and commitment made all the difference.
          <small><img src="img/quote_sign_right.png" alt="Quote Right"></small>
        </div>
      </div>
    </div>

    <div class="row align-items-center my-4 flex-row-reverse">
      <div class="col-md-3 text-center">
        <div class="profile">
          <div class="pic">
            <img src="img/client-2.jpg" alt="Sara Wilsson">
          </div>
          <h4>Sara Wilsson</h4>
          <span>Odeo Inc</span>
        </div>
      </div>
      <div class="col-md-9">
        <div class="quote">
          <b><img src="img/quote_sign_left.png" alt="Quote Left"></b>
          Their professionalism and creativity exceeded our expectations. Highly recommend for any project.
          <small><img src="img/quote_sign_right.png" alt="Quote Right"></small>
        </div>
      </div>
    </div>

  </div>
</section>

  <!--==========================
  Team Section
  ============================-->
  <section id="team">
  <div class="container wow fadeInUp">
    <div class="row text-center mb-4">
      <div class="col-md-12">
        <h3 class="section-title">Meet Our Team</h3>
        <div class="section-title-divider"></div>
        <p class="section-description">Dedicated professionals driving innovation and excellence.</p>
      </div>
    </div>

    <div class="row justify-content-center">

      <div class="col-md-3">
        <div class="member">
          <div class="pic">
            <img src="img/team-1.jpg" alt="Walter White">
          </div>
          <h4>Walter White</h4>
          <span>Chief Executive Officer</span>
          <p>Visionary leader with 20+ years in industry strategy and growth.</p>
          <div class="social">
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="member">
          <div class="pic">
            <img src="img/team-2.jpg" alt="Sarah Jhinson">
          </div>
          <h4>Sarah Jhinson</h4>
          <span>Product Manager</span>
          <p>Expert in project delivery and team leadership.</p>
          <div class="social">
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="member">
          <div class="pic">
            <img src="img/team-3.jpg" alt="William Anderson">
          </div>
          <h4>William Anderson</h4>
          <span>Chief Technology Officer</span>
          <p>Tech innovator passionate about scalable solutions.</p>
          <div class="social">
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
          </div>
        </div>
      </div>

      <div class="col-md-3">
        <div class="member">
          <div class="pic">
            <img src="img/team-4.jpg" alt="Amanda Jepson">
          </div>
          <h4>Amanda Jepson</h4>
          <span>Accountant</span>
          <p>Detail-oriented financial expert ensuring fiscal health.</p>
          <div class="social">
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>


  <!--==========================
  Contact Section
  ============================-->
  <section id="contact">
  <div class="container wow fadeInUp">
    <div class="row mb-4">
      <div class="col-md-12 text-center">
        <h3 class="section-title">Contact Us</h3>
        <div class="section-title-divider"></div>
        <p class="section-description">Feel free to get in touch with us for any inquiries or support.</p>
      </div>
    </div>

    <div class="row">
      <div class="col-md-4">
        <div class="info">
          <div class="mb-3">
            <i class="fa fa-map-marker"></i>
            <p>123 Main Street<br>Cityville, ST 12345</p>
          </div>
          <div class="mb-3">
            <i class="fa fa-envelope"></i>
            <p>contact@yourdomain.com</p>
          </div>
          <div>
            <i class="fa fa-phone"></i>
            <p>+1 (555) 123-4567</p>
          </div>
        </div>
      </div>

      <div class="col-md-8">
        <form action="#" method="post" class="contactForm">
          <div class="form-group mb-3">
            <input type="text" name="name" class="form-control" placeholder="Your Name" required minlength="4" />
          </div>
          <div class="form-group mb-3">
            <input type="email" name="email" class="form-control" placeholder="Your Email" required />
          </div>
          <div class="form-group mb-3">
            <input type="text" name="subject" class="form-control" placeholder="Subject" required minlength="8" />
          </div>
          <div class="form-group mb-3">
            <textarea name="message" rows="5" class="form-control" placeholder="Message" required></textarea>
          </div>
          <div class="text-center">
            <button type="submit" class="btn btn-primary px-4">Send Message</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</section>


  <!--==========================
  Footer
============================-->
  <footer id="footer">
  <div class="container text-center">
    <div class="copyright">
      &copy; <script>document.write(new Date().getFullYear());</script> All Rights Reserved
    </div>
  </div>
</footer>

  <!-- #footer -->

  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- Required JavaScript Libraries -->
  <script src="lib/jquery/jquery.min.js"></script>
  <script src="lib/bootstrap/js/bootstrap.min.js"></script>
  <script src="lib/superfish/hoverIntent.js"></script>
  <script src="lib/superfish/superfish.min.js"></script>
  <script src="lib/morphext/morphext.min.js"></script>
  <script src="lib/wow/wow.min.js"></script>
  <script src="lib/stickyjs/sticky.js"></script>
  <script src="lib/easing/easing.js"></script>

  <!-- Template Specisifc Custom Javascript File -->
  <script src="js/custom.js"></script>

  <script src="contactform/contactform.js"></script>


</body>

</html>
