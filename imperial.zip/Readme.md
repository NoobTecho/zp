# Imperial - Free One Page Bootstrap Template

*Thanks for downloading!*

[BootstrapMade](https://bootstrapmade.com/imperial-free-onepage-bootstrap-theme/) is the author of this template.

Get more [free templates](https://themewagon.com/theme_tag/free/) from [ThemeWagon](https://themewagon.com/)
