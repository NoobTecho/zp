<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
<title>Caviar – Fine Dining & Culinary Experience</title>


    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link href="style.css" rel="stylesheet">

    <!-- Responsive CSS -->
    <link href="css/responsive/responsive.css" rel="stylesheet">

</head>

<body>
    <!-- Preloader -->
    <div id="preloader">
        <div class="caviar-load"></div>
        <div class="preload-icons">
            <img class="preload-1" src="img/core-img/preload-1.png" alt="">
            <img class="preload-2" src="img/core-img/preload-2.png" alt="">
            <img class="preload-3" src="img/core-img/preload-3.png" alt="">
        </div>
    </div>

    <!-- ***** Search Form Area ***** -->
    <div class="caviar-search-form d-flex align-items-center">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="search-close-btn" id="closeBtn">
                        <i class="pe-7s-close-circle" aria-hidden="true"></i>
                    </div>
                    <form action="#" method="get">
                        <input type="search" name="caviarSearch" id="search" placeholder="Search Your Favourite Dish ...">
                        <input type="submit" class="d-none" value="submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
<header class="header_area" id="header">
    <div class="container h-100">
        <div class="row h-100">
            <div class="col-12 h-100">
                <nav class="h-100 navbar navbar-expand-lg align-items-center">
                    <a class="navbar-brand" href="index.html">Caviar</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#caviarNav" aria-controls="caviarNav" aria-expanded="false" aria-label="Toggle navigation"><span class="fa fa-bars"></span></button>
                    <div class="collapse navbar-collapse" id="caviarNav">
                        <ul class="navbar-nav ml-auto" id="caviarMenu">
                            <li class="nav-item active">
                                <a class="nav-link" href="#home">Home</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pages</a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="index.html">Home</a>
                                    <a class="dropdown-item" href="menu.html">Menu</a>
                                    <a class="dropdown-item" href="regular-page.html">Story</a>
                                    <a class="dropdown-item" href="contact.html">Contact</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#about">About</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#menu">Menu</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#awards">Awards</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#testimonial">Reviews</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#reservation">Book Table</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.html">Contact</a>
                            </li>
                        </ul>
                        <div class="caviar-search-btn">
                            <a id="search-btn" href="#"><i class="fa fa-search" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</header>

    <!-- ***** Header Area End ***** -->
<!-- ****** Welcome Area Start ****** -->
<section class="caviar-hero-area" id="home">
    <!-- Welcome Social Info -->
    <div class="welcome-social-info">
        <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
        <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
    </div>
    <!-- Welcome Slides -->
    <div class="caviar-hero-slides owl-carousel">
        <!-- Slide 1 -->
        <div class="single-hero-slides bg-img" style="background-image: url(img/bg-img/hero-1.jpg);">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-11 col-md-6 col-lg-4">
                        <div class="hero-content">
                            <h2>Fine Dining Redefined</h2>
                            <p>Experience an exquisite blend of taste, atmosphere, and service in every dish we serve. Welcome to Caviar.</p>
                            <a href="#" class="btn caviar-btn"><span></span> Make a Reservation</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hero-slides-nav bg-img" style="background-image: url(img/bg-img/hero-2.jpg);"></div>
        </div>
        <!-- Slide 2 -->
        <div class="single-hero-slides bg-img" style="background-image: url(img/bg-img/hero-2.jpg);">
            <div class="container h-100">
                <div class="row h-100 align-items-center">
                    <div class="col-11 col-md-6 col-lg-4">
                        <div class="hero-content">
                            <h2>Elevated Culinary Moments</h2>
                            <p>From farm to table, our passion for exceptional food meets your appetite for unforgettable experiences.</p>
                            <a href="#" class="btn caviar-btn"><span></span> Reserve Your Table</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="hero-slides-nav bg-img" style="background-image: url(img/bg-img/hero-1.jpg);"></div>
        </div>
    </div>
</section>

    <!-- ****** Welcome Area End ****** -->
<!-- ****** About Us Area Start ****** -->
<section class="caviar-about-us-area section-padding-150" id="about">
    <div class="container">
        <!-- About Us Single Area -->
        <div class="row align-items-center">
            <div class="col-12 col-md-6">
                <div class="about-us-thumbnail wow fadeInUp" data-wow-delay="0.5s">
                    <img src="img/bg-img/about-1.jpg" alt="Caviar Interior">
                </div>
            </div>
            <div class="col-12 col-md-6 col-lg-5 ml-md-auto">
                <div class="section-heading">
                    <h2>About Us</h2>
                </div>
                <div class="about-us-content">
                    <span>fine dining experience</span>
                    <p>At Caviar, we combine culinary artistry with warm hospitality to craft unforgettable dining experiences. Our philosophy is simple: source the best, prepare with passion, and serve with soul. Every plate is a story, every visit a memory.</p>
                </div>
            </div>
        </div>
        <!-- About Us Single Area -->
        <div class="about-us-second-part">
            <div class="row align-items-center pt-200">
                <div class="col-12 col-md-6 col-lg-5">
                    <div class="about-us-content">
                        <span>our head chef</span>
                        <p>Chef Luca Moretti brings decades of global culinary expertise to Caviar. With a flair for innovation and a deep respect for tradition, he crafts menus that balance bold flavors with elegant presentation. His kitchen is where precision meets creativity.</p>
                    </div>
                </div>
                <div class="col-12 col-md-6 ml-md-auto">
                    <div class="about-us-thumbnail wow fadeInUp" data-wow-delay="0.5s">
                        <img src="img/bg-img/about-2.jpg" alt="Chef Luca Moretti">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- ****** About Us Area End ****** -->
<!-- ****** Dish Menu Area Start ****** -->
<section class="caviar-dish-menu" id="menu">
    <div class="container">
        <div class="row">
            <div class="col-12 menu-heading">
                <div class="section-heading text-center">
                    <h2>Our Specialties</h2>
                </div>
                <!-- btn -->
                <a href="menu.html" class="btn caviar-btn"><span></span> View Full Menu</a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 col-sm-6 col-md-4">
                <div class="caviar-single-dish wow fadeInUp" data-wow-delay="0.5s">
                    <img src="img/menu-img/dish-1.png" alt="Grilled Salmon with Herb Butter">
                    <div class="dish-info">
                        <h6 class="dish-name">Grilled Salmon with Herb Butter</h6>
                        <p class="dish-price">$28</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-4">
                <div class="caviar-single-dish wow fadeInUp" data-wow-delay="1s">
                    <img src="img/menu-img/dish-2.png" alt="Truffle Mushroom Risotto">
                    <div class="dish-info">
                        <h6 class="dish-name">Truffle Mushroom Risotto</h6>
                        <p class="dish-price">$32</p>
                    </div>
                </div>
            </div>
            <div class="col-12 col-sm-6 col-md-4">
                <div class="caviar-single-dish wow fadeInUp" data-wow-delay="1.5s">
                    <img src="img/menu-img/dish-3.png" alt="Wagyu Beef Tenderloin">
                    <div class="dish-info">
                        <h6 class="dish-name">Wagyu Beef Tenderloin</h6>
                        <p class="dish-price">$58</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- ****** Dish Menu Area End ****** -->

    <!-- ****** Awards Area Start ****** -->
    <section class="caviar-awards-area" id="awards">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-12 col-md-2">
                    <div class="section-heading">
                        <h2>Awards</h2>
                    </div>
                </div>
                <div class="col-12 col-md-9 ml-md-auto">
                    <div class="caviar-awards d-sm-flex justify-content-between">
                        <img src="img/awards-img/a-1.png" alt="">
                        <img src="img/awards-img/a-2.png" alt="">
                        <img src="img/awards-img/a-3.png" alt="">
                        <img src="img/awards-img/a-4.png" alt="">
                        <img src="img/awards-img/a-5.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ****** Awards Area End ****** -->
<!-- ****** Testimonials Area Start ****** -->
<section class="caviar-testimonials-area" id="testimonial">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="testimonials-content">
                    <div class="section-heading text-center">
                        <h2>What Our Guests Say</h2>
                    </div>
                    <div class="caviar-testimonials-slides owl-carousel">
                        <!-- Single Testimonial Area -->
                        <div class="single-testimonial">
                            <div class="testimonial-thumb-name d-flex align-items-center">
                                <img src="img/testimonial-img/3.jpg" alt="Robert Jonson">
                                <div class="tes-name">
                                    <h5>Robert Jonson</h5>
                                    <p>Food Critic</p>
                                </div>
                            </div>
                            <p>"One of the finest dining experiences I've had in a long time. The flavors were exquisite, and the ambiance made the evening truly memorable."</p>
                        </div>
                        <!-- Single Testimonial Area -->
                        <div class="single-testimonial">
                            <div class="testimonial-thumb-name d-flex align-items-center">
                                <img src="img/testimonial-img/2.jpg" alt="Clara Hudson">
                                <div class="tes-name">
                                    <h5>Clara Hudson</h5>
                                    <p>Travel Blogger</p>
                                </div>
                            </div>
                            <p>"I travel the world for unique culinary experiences, and this place absolutely blew me away. Every bite was a masterpiece."</p>
                        </div>
                        <!-- Single Testimonial Area -->
                        <div class="single-testimonial">
                            <div class="testimonial-thumb-name d-flex align-items-center">
                                <img src="img/testimonial-img/1.jpg" alt="Jane Black">
                                <div class="tes-name">
                                    <h5>Jane Black</h5>
                                    <p>Regular Guest</p>
                                </div>
                            </div>
                            <p>"From the service to the desserts, everything was on point. I highly recommend this restaurant to anyone looking for a classy night out."</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

    <!-- ****** Testimonials Area End ****** -->
<!-- ****** Reservation Area Start ****** -->
<section class="caviar-reservation-area d-md-flex align-items-center" id="reservation">
    <div class="reservation-form-area d-flex justify-content-end">
        <div class="reservation-form">
            <div class="section-heading">
                <h2>Book a Table</h2>
                <p>Please fill in the form below to reserve your table. We’ll get back to you shortly.</p>
            </div>
            <form action="#" method="POST">
                <div class="row">
                    <div class="col-12 col-lg-6">
                        <label for="res-date">Date</label>
                        <input type="date" id="res-date" name="date" class="form-control" required>
                    </div>
                    <div class="col-12 col-lg-6">
                        <label for="res-time">Time</label>
                        <input type="time" id="res-time" name="time" class="form-control" required>
                    </div>
                    <div class="col-12 col-lg-6">
                        <label for="res-persons">Number of Persons</label>
                        <input type="number" id="res-persons" name="persons" class="form-control" min="1" placeholder="e.g. 2" required>
                    </div>
                    <div class="col-12 col-lg-6">
                        <label for="res-name">Your Name</label>
                        <input type="text" id="res-name" name="name" class="form-control" placeholder="Full Name" required>
                    </div>
                    <div class="col-12">
                        <label for="res-message">Additional Notes</label>
                        <textarea name="message" class="form-control" id="res-message" cols="30" rows="5" placeholder="Any specific requests?" required></textarea>
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn caviar-btn"><span></span> Reserve Now</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <div class="reservation-side-thumb wow fadeInRightBig" data-wow-delay="0.5s">
        <img src="img/bg-img/hero-3.jpg" alt="Reservation Background">
    </div>
</section>

    <!-- ****** Reservation Area End ****** -->
<!-- ****** Footer Area Start ****** -->
<footer class="caviar-footer-area">
    <div class="container">
        <div class="row justify-content-between align-items-center text-center text-md-left">
            <div class="col-md-6 mb-3 mb-md-0">
                <a href="#" class="navbar-brand">Caviar</a>
                <p class="mt-2 mb-0">
                    &copy; <script>document.write(new Date().getFullYear());</script> Caviar Restaurant. All rights reserved.
                </p>
                <p class="small text-muted mb-0">
                    Designed with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="#" target="_blank">Caviar</a>
                </p>
            </div>
            <div class="col-md-6 text-md-right">
                <div class="footer-social">
                    <a href="#"><i class="fa fa-facebook mr-2"></i></a>
                    <a href="#"><i class="fa fa-twitter mr-2"></i></a>
                    <a href="#"><i class="fa fa-instagram mr-2"></i></a>
                    <a href="#"><i class="fa fa-youtube-play"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>

    <!-- ****** Footer Area End ****** -->

    <!-- Jquery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap-4 js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/others/plugins.js"></script>
    <!-- Active JS -->
    <script src="js/active.js"></script>
</body>