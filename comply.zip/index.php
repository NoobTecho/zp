<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
<title>Comply - Smart Landing Page for Your Product</title>

        <meta name="description" content="Download free Bootstrap 4 product landing page template Comply." />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--Bootstrap 4-->
        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
        <!--icons-->
        <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css" />
    </head>
    <body>
        <!--header-->
        <nav class="navbar navbar-expand-md navbar-dark fixed-top sticky-navigation">
            <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                <span class="ion-grid icon-sm"></span>
            </button>
            <a class="navbar-brand hero-heading" href="#">COMPLY</a>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item mr-3">
                        <a class="nav-link page-scroll" href="#main">Product <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item mr-3">
                        <a class="nav-link page-scroll" href="#features">Features</a>
                    </li>
                    <li class="nav-item mr-3">
                        <a class="nav-link page-scroll" href="#pricing">Pricing</a>
                    </li>
                    <li class="nav-item mr-3">
                        <a class="nav-link page-scroll" href="#team">Team</a>
                    </li>
                    <li class="nav-item mr-3">
                        <a class="nav-link page-scroll" href="#blog">Blog</a>
                    </li>
                    <li class="nav-item mr-3">
                        <a class="nav-link page-scroll" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
        </nav>
<section class="bg-texture hero" id="main">
    <div class="container">
        <div class="row d-md-flex brand">
            <div class="col-md-6 hidden-sm-down wow fadeIn">
                <img class="img-fluid mx-auto d-block" src="img/product.png" alt="Comply Product Preview"/>
            </div>
            <div class="col-md-6 col-sm-12 text-white wow fadeIn">
                <h2 class="pt-4">Level Up with <b class="text-primary-light">Comply VR</b></h2>
                <p class="mt-5">
                    Step into immersive worlds with Comply. Powered by a decade of refinement and real-world feedback, V5 offers unmatched performance and stability.
                </p>
                <p class="mt-5">
                    <a href="#pricing" class="btn btn-primary mr-2 mb-2 page-scroll">Buy Now</a>
                    <a href="#download" class="btn btn-white mb-2 page-scroll">Download iOS App</a>
                </p>
            </div>
        </div>
    </div>
</section>

<!--features-->
<section class="bg-light" id="features">
    <div class="container">
        <div class="row mb-3">
            <div class="col-md-6 col-sm-8 mx-auto text-center wow fadeIn">
                <h2 class="text-primary">Powerful Features</h2>
                <p class="lead mt-4">
                    Packed with smart tech to deliver next-level virtual experiences.
                </p>
            </div>
        </div>
        <div class="row mt-5 text-center">
            <div class="col-md-4 wow fadeIn">
                <div class="card">
                    <div class="card-body">
                        <div class="icon-box">
                            <em class="ion-ios-game-controller-b-outline icon-md"></em>
                        </div>
                        <h6>Unlimited Gaming</h6>
                        <p>
                            Dive into non-stop immersive games without lags or limits.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 wow fadeIn">
                <div class="card">
                    <div class="card-body">
                        <div class="icon-box">
                            <em class="ion-android-wifi icon-md"></em>
                        </div>
                        <h6>Built-in WiFi</h6>
                        <p>
                            Seamless internet connectivity right out of the box.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 wow fadeIn">
                <div class="card">
                    <div class="card-body">
                        <div class="icon-box">
                            <em class="ion-ios-settings icon-md"></em>
                        </div>
                        <h6>Precision Controls</h6>
                        <p>
                            Customize every movement with ultra-sensitive response tech.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 wow fadeIn">
                <div class="card">
                    <div class="card-body">
                        <div class="icon-box">
                            <em class="ion-ios-cloud-upload-outline icon-md"></em>
                        </div>
                        <h6>Cloud Integration</h6>
                        <p>
                            Store and sync your VR sessions securely across all devices.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 wow fadeIn">
                <div class="card">
                    <div class="card-body">
                        <div class="icon-box">
                            <em class="ion-ios-locked-outline icon-md"></em>
                        </div>
                        <h6>Secure System</h6>
                        <p>
                            Military-grade encryption to protect your data and identity.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-4 wow fadeIn">
                <div class="card">
                    <div class="card-body">
                        <div class="icon-box">
                            <em class="ion-android-color-palette icon-md"></em>
                        </div>
                        <h6>Custom Themes</h6>
                        <p>
                            Match your vibe with endless color customization.
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="bg-white p-0">
    <div class="container-fluid">
        <div class="row d-md-flex mt-5">
            <div class="col-sm-6 p-0 wow fadeInLeft">
                <img class="img-fluid" src="img/product2.jpg" alt="Gallery">
            </div>
            <div class="col-sm-6 pl-5 pr-5 pt-5 pb-4 wow fadeInRight">
                <h3><a href="#">Discover What's New in v5.0</a></h3>
                <p class="lead pt-4">Explore cutting-edge updates that redefine your virtual experience. Faster, smarter, and more immersive than ever.</p>
                <ul class="pt-4 pb-3 list-default">
                    <li>Enhanced graphics performance for seamless visuals.</li>
                    <li>Smarter user interface with intuitive controls.</li>
                    <li>Expanded content library integration.</li>
                    <li>Real-time cloud sync across devices.</li>
                    <li>Improved battery efficiency and thermal control.</li>
                    <li>New multiplayer gaming framework.</li>
                    <li>One-click social sharing integration.</li>
                </ul>
                <a href="#purchase" class="btn btn-primary mr-2 page-scroll">Start Your Upgrade</a>
            </div>
        </div>
    </div>
</section>

<!--pricing-->
<section class="bg-light" id="pricing">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 col-sm-8 offset-sm-2 text-center">
                <h2 class="text-primary">Simple Pricing</h2>
                <p class="lead pt-3">
                    No hidden fees. Just pick your plan and start building.
                </p>
            </div>
        </div>
        <div class="row d-md-flex mt-4 text-center">
            <!-- Basic Plan -->
            <div class="col-sm-4 mt-4 wow fadeIn">
                <div class="card border-light shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title pt-4 text-orange">Starter</h5>
                        <h3 class="card-title text-primary pt-4">FREE</h3>
                        <p class="card-text text-muted pb-3 border-bottom">Forever plan</p>
                        <ul class="list-unstyled pricing-list">
                            <li>Quick setup</li>
                            <li>100MB storage</li>
                            <li>1GB bandwidth</li>
                            <li>Community support</li>
                        </ul>
                        <a href="#" class="btn btn-outline-primary btn-radius">Start Free</a>
                    </div>
                </div>
            </div>

            <!-- Standard Plan -->
            <div class="col-sm-4 mt-0 wow fadeIn">
                <div class="card pt-4 pb-4 border-primary shadow-lg">
                    <div class="card-body">
                        <h5 class="card-title pt-4 text-orange">Pro <span class="badge bg-primary small-xs">Most Popular</span></h5>
                        <h3 class="card-title text-primary pt-4"><sup>$</sup>9.99</h3>
                        <p class="card-text text-muted pb-3 border-bottom">Per month</p>
                        <ul class="list-unstyled pricing-list">
                            <li>Everything in Free</li>
                            <li>5GB storage</li>
                            <li>Unlimited bandwidth</li>
                            <li>Email + Chat support</li>
                        </ul>
                        <a href="#" class="btn btn-primary btn-radius">Go Pro</a>
                    </div>
                </div>
            </div>

            <!-- Advanced Plan -->
            <div class="col-sm-4 mt-4 wow fadeIn">
                <div class="card border-dark shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title pt-4 text-orange">Enterprise</h5>
                        <h3 class="card-title text-primary pt-4"><sup>$</sup>19.99</h3>
                        <p class="card-text text-muted pb-3 border-bottom">Per month</p>
                        <ul class="list-unstyled pricing-list">
                            <li>Unlimited storage</li>
                            <li>Unlimited bandwidth</li>
                            <li>Dedicated 24/7 support</li>
                            <li>Early access to new features</li>
                        </ul>
                        <a href="#" class="btn btn-dark btn-radius">Get Enterprise</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--download-->
<section class="bg-orange pt-0" id="download">
    <div class="container">
        <div class="row d-md-flex text-center wow fadeIn">
            <div class="col-md-6 offset-md-3 col-sm-10 offset-sm-1 col-xs-12">
                <h5 class="text-primary">Get the Comply App</h5>
                <p class="mt-4">
                    Take Comply with you. Experience VR anytime, anywhere—on your phone or tablet.
                </p>
                <p class="mt-5">
                    <a href="#" class="mr-2"><img src="img/google-play.png" class="store-img" alt="Download on Google Play"/></a>
                    <a href="#"><img src="img/apple_store.png" class="store-img" alt="Download on the App Store"/></a>
                </p>
            </div>
        </div>
    </div>
</section>


        <!--team-->
        <section class="bg-white" id="team">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-sm-8 mx-auto text-center">
                        <h2 class="text-primary">Our Team</h2>
                        <p class="lead pt-3">
                            Meet our awesome team.
                        </p>
                    </div>
                </div>
                <div class="row d-md-flex mt-5 text-center">
                    <div class="team col-sm-3 mt-2 wow fadeInLeft">
                        <img src="img/team-1.jpg" alt="Male" class="img-team img-fluid rounded-circle"/>
                        <h5>John Deo</h5>
                        <p>CEO, Comply</p>
                    </div>
                    <div class="team col-sm-3 mt-2 wow fadeIn">
                        <img src="img/team-4.jpg" alt="Male" class="img-team img-fluid rounded-circle"/>
                        <h5>Kathrine Kaif</h5>
                        <p>Marketing Head</p>
                    </div>
                    <div class="team col-sm-3 mt-2 wow fadeIn">
                        <img src="img/team-2.jpg" alt="Male" class="img-team img-fluid rounded-circle"/>
                        <h5>Brandon Lee</h5>
                        <p>Lead Developer</p>
                    </div>
                    <div class="team col-sm-3 mt-2 wow fadeInRight">
                        <img src="img/team-3.jpg" alt="Male" class="img-team img-fluid rounded-circle"/>
                        <h5>Inza Fererri</h5>
                        <p>Customer Care</p>
                    </div>
                </div>
            </div>
        </section>
<!--blog-->
<section class="bg-light" id="blog">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 col-sm-8 offset-sm-2 col-xs-12 text-center">
                <h2 class="text-primary">Latest from the Blog</h2>
                <p class="lead pt-3">
                    Fresh updates, behind-the-scenes, and product insights from Comply.
                </p>
            </div>
        </div>
        <div class="row d-md-flex mt-5">
            <div class="col-sm-4 mt-2 wow fadeIn">
                <div class="card">
                    <img class="card-img-top" src="img/blog-1.jpg" alt="Comply 5.0 Update">
                    <div class="card-body">
                        <p class="card-text text-muted small-xl">
                            <em class="ion-ios-calendar-outline"></em> 22h ago &nbsp;&nbsp;
                            <em class="ion-ios-person-outline"></em> Katherine Kaif &nbsp;&nbsp;
                            <em class="ion-ios-time-outline"></em> 5min read
                        </p>
                        <h5 class="card-title"><a href="#">Comply 5.0 is Live – Here’s What’s New</a></h5>
                        <p class="card-text">We’ve upgraded performance, added new features, and streamlined the experience for all users. Dive into what’s changed.</p>
                    </div>
                    <div class="card-body text-right">
                        <a href="#" class="card-link"><strong>Read more</strong></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 mt-2 wow fadeIn">
                <div class="card">
                    <img class="card-img-top" src="img/blog-2.jpg" alt="Team Celebration">
                    <div class="card-body">
                        <p class="card-text text-muted small-xl">
                            <em class="ion-ios-calendar-outline"></em> 1 week ago &nbsp;&nbsp;
                            <em class="ion-ios-person-outline"></em> John Deo &nbsp;&nbsp;
                            <em class="ion-ios-time-outline"></em> 2min read
                        </p>
                        <h5 class="card-title"><a href="#">A Slice of Victory: How We Celebrated</a></h5>
                        <p class="card-text">From late nights to product launch — we celebrated with cake, laughs, and a toast to the next chapter. A little peek into our team culture.</p>
                    </div>
                    <div class="card-body text-right">
                        <a href="#" class="card-link"><strong>Read more</strong></a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 mt-2 wow fadeIn">
                <div class="card">
                    <img class="card-img-top" src="img/blog-3.jpg" alt="VR Community">
                    <div class="card-body">
                        <p class="card-text text-muted small-xl">
                            <em class="ion-ios-calendar-outline"></em> 1 month ago &nbsp;&nbsp;
                            <em class="ion-ios-person-outline"></em> Kathrine Kaif &nbsp;&nbsp;
                            <em class="ion-ios-time-outline"></em> 10min read
                        </p>
                        <h5 class="card-title"><a href="#">Bridging People with Virtual Reality</a></h5>
                        <p class="card-text">We believe VR isn’t just tech—it’s a human connection. See how Comply is building a more inclusive digital world for everyone.</p>
                    </div>
                    <div class="card-body text-right">
                        <a href="#" class="card-link"><strong>Read more</strong></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

        <!--contact-->
        <section class="bg-texture-collage p-0" id="contact">
            <div class="container">
                <div class="row d-md-flex text-white text-center wow fadeIn">
                    <div class="col-sm-4 p-5">
                        <p><em class="ion-ios-telephone-outline icon-md"></em></p>
                        <p class="lead">+1 5456 87595</p>
                    </div>
                    <div class="col-sm-4 p-5">
                        <p><em class="ion-ios-email-outline icon-md"></em></p>
                        <p class="lead">info@comply.com</p>
                    </div>
                    <div class="col-sm-4 p-5">
                        <p><em class="ion-ios-location-outline icon-md"></em></p>
                        <p class="lead">Austin, Texas</p>
                    </div>
                </div>
            </div>
        </section>
<!--footer-->
<section class="bg-footer" id="connect">
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3 col-sm-8 offset-sm-2 text-center wow fadeIn">
                <h1 class="mb-3">COMPLY</h1>
                <div class="social-icons mb-4">
                    <a href="https://twitter.com/" target="_blank"><em class="ion-social-twitter icon-sm mr-3"></em></a>
                    <a href="https://github.com/" target="_blank"><em class="ion-social-github icon-sm mr-3"></em></a>
                    <a href="https://www.linkedin.com/" target="_blank"><em class="ion-social-linkedin icon-sm mr-3"></em></a>
                    <a href="https://plus.google.com/" target="_blank"><em class="ion-social-googleplus icon-sm mr-3"></em></a>
                </div>
                <p class="text-muted small">
                    &copy; <script>document.write(new Date().getFullYear());</script> Comply. Built with ♥ by 
                    <a href="https://wireddots.com" class="text-white">Wired Dots</a> & 
                    <a href="https://twitter.com/attacomsian" class="text-white">@attacomsian</a>
                </p>
            </div>
        </div>
    </div>
</section>


        <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta.2/js/bootstrap.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
