<!DOCTYPE html>
<html>
	<head>
		<title>Armando — Creative Portfolio & Visual Design Studio</title>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
		<meta name="format-detection" content="telephone=no">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<!-- Fonts-->
		<link rel="stylesheet" type="text/css" href="assets/fonts/fontawesome/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="assets/fonts/pe-icon/pe-icon.css">
		<!-- Vendors-->
		<link rel="stylesheet" type="text/css" href="assets/vendors/bootstrap/grid.css">
		<link rel="stylesheet" type="text/css" href="assets/vendors/magnific-popup/magnific-popup.min.css">
		<link rel="stylesheet" type="text/css" href="assets/vendors/swiper/swiper.css">
		<!-- App & fonts-->
		<link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700">
		<link rel="stylesheet" type="text/css" href="assets/css/main.css"><!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<![endif]-->
	</head>
	
	<body>
		<div class="page-wrap">
			
			<!-- header -->
			<header class="header header--fixed">
				<div class="container">
					<div class="header__inner">
						<div class="header__logo"><a href="index.html"><img src="assets/img/logo.png" alt=""/></a></div>
						<div class="header__menu">
							
							<!-- onepage-nav -->
							<nav class="onepage-nav">
								
								<!-- onepage-menu -->
								<ul class="onepage-menu">
									<li class="current-menu-item"><a href="#id-1">Home</a>
									</li>
									<li><a href="#id-2">About</a>
									</li>
									<li><a href="#id-3">Portfolio</a>
									</li>
									<li><a href="#id-4">Blog</a>
									</li>
									<li><a href="#id-5">Contact</a>
									</li>
								</ul><!-- onepage-menu -->
								
								<div class="navbar-toggle"><span></span><span></span><span></span></div>
							</nav><!-- End / onepage-nav -->
							
						</div>
					</div>
				</div>
			</header><!-- End / header -->
			
			<!-- Content-->
			<div class="md-content">
				
				<!-- hero -->
<div class="hero" id="id-1" style="background-image: url('assets/img/bg/1.jpg');">
  <div class="hero__wrapper">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 ">
          <h1 class="hero__title">We are
            <!-- typing__module -->
            <div class="typing__module" data-options='{"typeSpeed":60}'>
              <div class="typed-strings">
                <span>Vision-Driven</span>
                <span>Design-Led</span>
                <span>Solution-Focused</span>
              </div><span class="typed"></span>
            </div><!-- End / typing__module -->
          </h1>
          <p class="hero__text">We craft experiences that blend aesthetics and function. From design to deployment, our focus is building work that matters.</p>
        </div>
      </div>
      <span id="back-to-down"><i class="pe-7s-angle-down"></i></span>
    </div>
  </div>
</div><!-- End / hero -->

				
				<!-- Section -->
				<section class="md-section bg-gray" id="id-2">
					<div class="container">
						<div class="row">
							<div class="col-lg-5 ">
								
								<!-- slide-image -->
								<div class="slide-image">
									
									<!-- swiper__module swiper-container -->
									<div class="swiper__module swiper-container slide-image__front" data-options='{"slidesPerView":1,"spaceBetween":0}'>
										<div class="swiper-wrapper">
											<div class="slide-item" style="background-image: url('assets/img/about/1.jpg');"></div>
											<div class="slide-item" style="background-image: url('assets/img/about/2.jpg');"></div>
											<div class="slide-item" style="background-image: url('assets/img/about/3.jpg');"></div>
										</div>
										<div class="swiper-pagination-custom"></div>
									</div><!-- End / swiper__module swiper-container -->
									
									
									<!-- swiper-thumbnails__module swiper-container -->
									<div class="swiper-thumbnails__module swiper-container slide-image__black" data-options='{"slidesPerView":1,"spaceBetween":0,"delay":10000}'>
										<div class="swiper-wrapper">
											<div class="slide-item" style="background-image: url('assets/img/about/1b.jpg');"></div>
											<div class="slide-item" style="background-image: url('assets/img/about/2b.jpg');"></div>
											<div class="slide-item" style="background-image: url('assets/img/about/3b.jpg');"></div>
										</div>
									</div><!-- End / swiper-thumbnails__module swiper-container -->
									
								</div><!-- End / slide-image -->
								
							</div>
<div class="col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-0 col-lg-offset-1 ">

  <!-- title -->
  <div class="title">
    <h2 class="title__title">Hello from Armando</h2>
  </div><!-- End / title -->

  <p class="fz-16">Welcome to my digital corner — where ideas turn into visuals and pixels into experiences. I'm a creative thinker who loves blending design with storytelling.</p>
  <p class="fz-16">With a background in visual media and a passion for clean design, I focus on creating work that resonates. Whether it’s branding, web design, or photography, my goal is simple: make it real, make it impactful. Let’s build something meaningful, together.</p>
  
</div>

						</div>
						
<!-- swiper__module swiper-container -->
<div class="swiper__module swiper-container mt-50" data-options='{"slidesPerView":3,"spaceBetween":30,"autoplay":2000,"breakpoints":{"640":{"slidesPerView":1},"991":{"slidesPerView":2}}}'>
  <div class="swiper-wrapper">

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-share"></i></div>
      <h3 class="service__title">Content Strategy</h3>
      <p class="service__text">We help brands plan, write, and deliver meaningful content that connects and converts.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-graph"></i></div>
      <h3 class="service__title">SEO Optimization</h3>
      <p class="service__text">Increase visibility with keyword research, clean architecture, and content that ranks.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-piggy"></i></div>
      <h3 class="service__title">Investment Planning</h3>
      <p class="service__text">Tailored investment strategies designed for long-term growth and risk control.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-shield"></i></div>
      <h3 class="service__title">Risk Assessment</h3>
      <p class="service__text">We analyze your business environment to identify and minimize potential threats.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-bulb"></i></div>
      <h3 class="service__title">Marketing Strategy</h3>
      <p class="service__text">From idea to execution — smart marketing campaigns that actually deliver.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-lock"></i></div>
      <h3 class="service__title">Cybersecurity</h3>
      <p class="service__text">We implement essential protections to keep your data, users, and assets safe.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-smile"></i></div>
      <h3 class="service__title">UX Design</h3>
      <p class="service__text">Create intuitive, user-centered experiences that drive engagement and loyalty.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-monitor"></i></div>
      <h3 class="service__title">Web Development</h3>
      <p class="service__text">Fast, scalable websites and platforms built with performance and usability in mind.</p>
    </div>

    <!-- service -->
    <div class="service mb-0">
      <div class="service__icon"><i class="pe-7s-magic-wand"></i></div>
      <h3 class="service__title">Brand Identity</h3>
      <p class="service__text">Logo, voice, visuals — we help shape the personality of your brand from scratch.</p>
    </div>

  </div>
</div>
<!-- End / swiper__module swiper-container -->

						
					</div>
				</section>
				<!-- End / Section -->
				
				
				<!-- Section -->
				<section class="md-section" id="id-3">
					<div class="container">
						<div class="row">
							<div class="col-lg-8 ">
								
								<!-- title -->
								<div class="title">
									<h2 class="title__title">portfolio</h2>
								</div><!-- End / title -->
								
							</div>
						</div>
						<div class="grid-css grid-css--grid" data-col-lg="3" data-col-md="2" data-col-sm="2" data-col-xs="1" data-gap="30">
							<div class="filter">
								<ul class="filter__list">
									<li><a href="#" data-filter="*">All</a></li>
									<li><a href="#" data-filter=".cat1">Web design</a></li>
									<li><a href="#" data-filter=".cat2">Applications</a></li>
									<li><a href="#" data-filter=".cat3">Development</a></li>
								</ul>
							</div>
							<div class="grid__inner">
								<div class="grid-sizer"></div>
								<div class="grid-item normal cat1 cat4">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="https://www.youtube.com/watch?v=XNqn4gEakQA"><a class="portfolio__bg popup-video" href="https://www.youtube.com/watch?v=XNqn4gEakQA" style="background-image: url('assets/img/portfolio/1.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/1.jpg"/>
													<div class="portfolio__icon"><i class="fa fa-play"></i></div></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item normal cat4 cat2">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/2.jpg"><a class="portfolio__bg" href="assets/img/portfolio/2.jpg" style="background-image: url('assets/img/portfolio/2.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/2.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item normal cat2 cat1">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/3.jpg"><a class="portfolio__bg" href="assets/img/portfolio/3.jpg" style="background-image: url('assets/img/portfolio/3.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/3.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item normal cat3 cat4 cat2">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/4.jpg"><a class="portfolio__bg" href="assets/img/portfolio/4.jpg" style="background-image: url('assets/img/portfolio/4.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/4.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item normal cat4 cat3">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/5.jpg"><a class="portfolio__bg" href="assets/img/portfolio/5.jpg" style="background-image: url('assets/img/portfolio/5.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/5.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item normal cat1 cat4 cat3">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/6.jpg"><a class="portfolio__bg" href="assets/img/portfolio/6.jpg" style="background-image: url('assets/img/portfolio/6.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/6.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item normal cat2 cat3">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/7.jpg"><a class="portfolio__bg" href="assets/img/portfolio/7.jpg" style="background-image: url('assets/img/portfolio/7.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/7.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item normal cat3 cat1">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/8.jpg"><a class="portfolio__bg" href="assets/img/portfolio/8.jpg" style="background-image: url('assets/img/portfolio/8.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/8.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
								<div class="grid-item cat3 cat1">
									<div class="grid-item__inner">
										<div class="grid-item__content-wrapper">
											
											<!-- portfolio -->
											<div class="portfolio" href="assets/img/portfolio/9.jpg"><a class="portfolio__bg" href="assets/img/portfolio/9.jpg" style="background-image: url('assets/img/portfolio/9.jpg');" data-effect="mfp-zoom-in"><img src="assets/img/portfolio/9.jpg"/></a>
											</div><!-- End / portfolio -->
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<!-- End / Section -->
				
				
				<!-- Section -->
				<section class="md-section bg-gray" id="id-4">
					<div class="container">
<div class="row">
  <div class="col-xs-12">
    <!-- title -->
    <div class="title">
      <h2 class="title__title">Latest Insights</h2>
    </div><!-- End / title -->
  </div>
</div>

<div class="row">
  <div class="col-lg-4">
    <div>
      <div class="post__media">
        <a href="#"><img src="assets/img/blog/1.jpg" alt=""/></a>
      </div>
      <div class="post__body">
        <h2 class="post__title"><a href="#">Building a Fast Site with Vue.js</a></h2>
        <div class="post__meta"><span class="author"><a href="#">Jordan Lee</a></span><span class="date">May 24, 2025</span></div>
        <p class="post__text">Learn how to leverage Vue.js for high-performance front-end development without sacrificing maintainability.</p>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div>
      <div class="post__media">
        <a href="#"><img src="assets/img/blog/2.jpg" alt=""/></a>
      </div>
      <div class="post__body">
        <h2 class="post__title"><a href="#">Designing UX for Augmented Reality</a></h2>
        <div class="post__meta"><span class="author"><a href="#">Michelle Tan</a></span><span class="date">May 18, 2025</span></div>
        <p class="post__text">Creating immersive and intuitive interfaces in AR requires rethinking how users perceive digital layers in physical space.</p>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div>
      <div class="post__media">
        <a href="#"><img src="assets/img/blog/3.jpg" alt=""/></a>
      </div>
      <div class="post__body">
        <h2 class="post__title"><a href="#">Homepage Design That Converts</a></h2>
        <div class="post__meta"><span class="author"><a href="#">Reza Malik</a></span><span class="date">May 10, 2025</span></div>
        <p class="post__text">A strong homepage isn’t just pretty — it needs to guide, convert, and communicate your brand in seconds.</p>
      </div>
    </div>
  </div>
</div>

					</div>
				</section>
				<!-- End / Section -->
				
				<!-- Section -->
<section class="md-section" id="id-5">
  <div class="container">
    <div class="row">
      <div class="col-lg-4">

        <!-- title -->
        <div class="title">
          <h2 class="title__title">Get in touch</h2>
        </div>

        <div class="mb-40">
          <!-- contact -->
          <div class="contact">
            <h3 class="contact__title">Address</h3>
            <div>84 Kensington Road, Bristol, United Kingdom</div>
          </div>

          <div class="contact">
            <h3 class="contact__title">Email</h3>
            <div><a href="mailto:support@awe7.dev">support@awe7.dev</a></div>
          </div>

          <div class="contact">
            <h3 class="contact__title">Phone</h3>
            <div>+44 20 7946 0275</div>
          </div>
        </div>
      </div>

      <div class="col-lg-7 col-xs-offset-0 col-sm-offset-0 col-md-offset-0 col-lg-offset-1 ">

        <!-- title -->
        <div class="title">
          <h2 class="title__title">Or drop a message</h2>
        </div>

        <div class="form-wrapper">
          <div class="form-item form-item--half">
            <label class="form__label">Email <span>*</span></label>
            <input class="form-control" type="text" name="email" placeholder="example@mail.com" />
          </div>

          <div class="form-item form-item--half">
            <label class="form__label">Name <span>*</span></label>
            <input class="form-control" type="text" name="name" placeholder="Your name" />
          </div>

          <div class="form-item">
            <label class="form__label">Message <span>*</span></label>
            <textarea class="form-control" placeholder="Write something here..."></textarea>
          </div>

          <div class="form-item">
            <a class="md-btn btn-custom" href="#">Send Message</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

				<!-- End / Section -->
				
			</div>
			<!-- End / Content-->
			
			<!-- footer -->
			<div class="footer">
				<div id="back-to-top"><i class="pe-7s-angle-up"></i></div>
				<div class="container">
					<div class="footer__wrapper">
						<div class="footer__social">
										
										<!-- social-icon -->
										<a class="social-icon" href="#"><i class="social-icon__icon fa fa-facebook"></i>
										</a><!-- End / social-icon -->
										
										
										<!-- social-icon -->
										<a class="social-icon" href="#"><i class="social-icon__icon fa fa-twitter"></i>
										</a><!-- End / social-icon -->
										
										
										<!-- social-icon -->
										<a class="social-icon" href="#"><i class="social-icon__icon fa fa-linkedin"></i>
										</a><!-- End / social-icon -->
										
										
										<!-- social-icon -->
										<a class="social-icon" href="#"><i class="social-icon__icon fa fa-behance"></i>
										</a><!-- End / social-icon -->
										
										
										<!-- social-icon -->
										<a class="social-icon" href="#"><i class="social-icon__icon fa fa-vimeo"></i>
										</a><!-- End / social-icon -->
										
						</div>
						<p class="footer__copy">2018 &copy; Copyright Awe7. All rights Reserved.</p>
					</div>
				</div>
			</div><!-- End / footer -->
			
		</div>
		<!-- Vendors-->
		<script type="text/javascript" src="assets/vendors/jquery/jquery.min.js"></script>
		<script type="text/javascript" src="assets/vendors/imagesloaded/imagesloaded.pkgd.js"></script>
		<script type="text/javascript" src="assets/vendors/isotope-layout/isotope.pkgd.js"></script>
		<script type="text/javascript" src="assets/vendors/jquery-one-page/jquery.nav.min.js"></script>
		<script type="text/javascript" src="assets/vendors/jquery.easing/jquery.easing.min.js"></script>
		<script type="text/javascript" src="assets/vendors/jquery.matchHeight/jquery.matchHeight.min.js"></script>
		<script type="text/javascript" src="assets/vendors/magnific-popup/jquery.magnific-popup.min.js"></script>
		<script type="text/javascript" src="assets/vendors/masonry-layout/masonry.pkgd.js"></script>
		<script type="text/javascript" src="assets/vendors/swiper/swiper.jquery.js"></script>
		<script type="text/javascript" src="assets/vendors/menu/menu.js"></script>
		<script type="text/javascript" src="assets/vendors/typed/typed.min.js"></script>
		<!-- App-->
		<script type="text/javascript" src="assets/js/main.js"></script>
	</body>
</html>