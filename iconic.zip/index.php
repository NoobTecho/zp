<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>iconic   </title>
      <!-- Favicon -->
      
      <!-- Bootstrap CSS -->
      <link href="assets/css/bootstrap.min.css" rel="stylesheet">
      <!-- Animate CSS -->
      <link href="assets/vendors/animate/animate.css" rel="stylesheet">
      <!-- Icon CSS-->
      <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css">
      <!-- Owlcarousel CSS-->
      <link rel="stylesheet" type="text/css" href="assets/vendors/owl_carousel/owl.carousel.css" media="all">
      <!--Template Styles CSS-->
      <link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
   </head>
   <body>
      <div class="bg-grediunt">
         <div class="bg-banner-img clip-ellipse">
            <div class="ovrllay">
           
               <!-- Header_Area -->
               <nav class="navbar navbar-default header_aera affix-top">
                  <div class="container m-s">
                     <!-- Brand and toggle get grouped for better mobile display -->
                     <div class="col-md-4 p0">
                        <div class="navbar-header">
                           <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#min_navbar">
                           <span class="sr-only">Toggle navigation</span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           <span class="icon-bar"></span>
                           </button>
                           <a class="navbar-brand logo-biss" href="index.html"> <img src="assets/images/logo_img.png"></a>
                        </div>
                     </div>
                     <!-- Collect the nav links, forms, and other content for toggling -->
                     <div class="col-md-8 p0">
                        <div class="collapse navbar-collapse" id="min_navbar">
                          <ul class="nav navbar-nav navbar-right">
                        <li class="dropdown submenu">
                           <a href="index.html" class="">Home</a>
                        </li>
                         <li class="dropdown submenu">
                           <a href="about.html" class="">About</a>
                        </li>
                        <li class="dropdown submenu">
                           <a href="services.html" class=""> Services</a>
                        </li>
                        <li class="dropdown submenu">
                           <a href="blog.html" class="">Blog</a>
                        </li>
                        <li class="dropdown submenu">
                           <a href="elements.html" class="">Elements</a>
                        </li>
                        <li class="dropdown submenu">
                           <a href="contact.html" class="">Contact</a>
                        </li>
                      
                     </ul>
                        </div>
                        <!-- /.navbar-collapse -->
                     </div>
                  </div>
                  <!-- /.container -->
               </nav>
               <!-- End Header_Area -->
               <!-- #banner start -->
               <section id="banner" class=" mb-90">
                  <div class="container ">
                     <div class="row">
                        <!-- #banner-text start -->            
                        <div id="banner-text" class="col-md-12 text-c text-center ">
                           <h5 class="wow fadeInUp main-h" data-wow-delay="0.2s" >End-to-End Customer Journey Analytics</h5>
                           <p class="banner-text wow fadeInUp main-h3" data-wow-delay="0.8s">No hours sank into aggregating and cleaning data. No complex SQL queries required. Just the answers <br> teams need to make smarter decisions, fast. Now, that's data-driven.</p>
                           <div class="top-banner wow fadeInRight">
                              <a id="#services"  href="contact.html" class="btn btn-default  wow fadeInUp  js-scroll-trigger" data-wow-delay="1s" href="#">GeT STARTED FOR FREE</a>
                           </div>
                        </div>
                        <!-- /#banner-text End -->
                     </div>
                  </div>
               </section>
            </div>
            </div>
      
         <!-- /#banner end -->
        
         <!--#Our Partners Area -->
         <div class="our_partners_area py-70 pt_banner_30">
            <div class="container">
              
               <!--#Our Partners assets/images start -->
               <div class="partners wow fadeInUp">
                  <div class="item"><img src="assets/images/client_logo/client_logo-1.png" alt=""></div>
                  <div class="item"><img src="assets/images/client_logo/client_logo-2.png" alt=""></div>
                  <div class="item"><img src="assets/images/client_logo/client_logo-3.png" alt=""></div>
                  <div class="item"><img src="assets/images/client_logo/client_logo-4.png" alt=""></div>
                  <div class="item"><img src="assets/images/client_logo/client_logo-5.png" alt=""></div>
               </div>
               <!--#End Our Partners assets/images -->
              
            </div>
         </div>
      </div>
      <!--#End Our Partners Area -->
      <!-- #About Us Area start -->
      <div  id="about"  class=" back-right-text-c">
         <div class="container">
            <div class="row text-center mb-60 ">
               <div class="title wow fadeInUp">
                  <h1>Analytics for Product, Marketing, Sales and Support teams</h1  >
               </div>
            </div><div class="row about_row py-40">
  <!-- Service Item -->
  <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
    <div class="service-1">
      <div class="servise-top wow fadeInUp">
        <img src="assets/images/icone-1.png" alt="Unify Icon">
      </div>
      <h2 class="unify">Unify</h2>
      <p class="bottom-s">
        A well-designed layout keeps users focused and engaged, minimizing distractions and creating a seamless experience.
      </p>
      <div class="button-div">
        <a href="#" class="button-s">Learn more</a>
      </div>
    </div>
  </div>

  <!-- Service Item -->
  <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
    <div class="service-1">
      <div class="servise-top wow fadeInUp">
        <img src="assets/images/icone-2.png" alt="Analyze Icon">
      </div>
      <h2 class="unify">Analyze</h2>
      <p class="bottom-s">
        Understanding data is key to making informed decisions that drive business success and growth.
      </p>
      <div class="button-div">
        <a href="#" class="button-s">Learn more</a>
      </div>
    </div>
  </div>

  <!-- Service Item -->
  <div class="who_we_area col-md-4 col-sm-6 col-4pad wow fadeInUp">
    <div class="service-1">
      <div class="servise-top wow fadeInUp">
        <img src="assets/images/icone-3.png" alt="Engage Icon">
      </div>
      <h2 class="unify">Engage</h2>
      <p class="bottom-s">
        Building strong connections with your audience fosters loyalty and meaningful interactions.
      </p>
      <div class="button-div">
        <a href="#" class="button-s">Learn more</a>
      </div>
    </div>
  </div>
</div>

         </div>
         <section class="">
         <div class="container-fluid ">
            <div class="row text-left about_row   ">
               <div class="col-md-6 p-0 clip-polygon  ">
                  
                  <div class="video-img">
                     <a href="#nogo" class="hero__play"><img  src="assets/images/img-g.png"></a>
                  </div>
               </div>
               <div class="col-md-6 wow fadeInUp">
                  <div class="title-left wow fadeInUp">
                     <h1 class="text-left wow fadeInUp " data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">Optimize Every Touchpoint in the Customer Experience</h1  >
                  </div>
                  <p class="about_h wow fadeInUp " data-wow-delay="1s" style="visibility: visible; animation-name: fadeInRight;">Analytics to answer any business question.</p>
                  <p class="about_bottom_h wow fadeInUp " data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">Full-funnel attribution, onboarding optimization, feature usage trends, subscription growth, cohort analysis and more. Know exactly what users are doing across touchpoints to increase acquisition, drive engagement and improve retention.</p>
                  <div class="top-banner wow fadeInRight text-left" style="visibility: visible; animation-name: fadeInRight;">
                     <a id="#services" href="#services" class="btn btn-default  wow fadeInUp  js-scroll-trigger" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">Learn more</a>
                  </div>
               </div>
            </div>
         </div>
         </section>
      </div>
      <div class="container-fluid ">
         <div class="row text-left about_row mr-0 wow fadeInUp">
            <div class="col-md-6 pl-40 wow fadeInUp">
               <div class="title-left wow fadeInUp">
                  <h1 class="text-left">Optimize Every Touchpoint in the Customer Experience</h1  >
               </div>
               <p class="about_h">Analytics to answer any business question.</p>
               <p class="about_bottom_h">Full-funnel attribution, onboarding optimization, feature usage trends, subscription growth, cohort analysis and more. Know exactly what users are doing across touchpoints to increase acquisition, drive engagement and improve retention.</p>
               <div class="top-banner wow fadeInRight text-left" style="visibility: visible; animation-name: fadeInRight;">
                  <a id="#services" href="#services" class="btn btn-default  wow fadeInUp  js-scroll-trigger" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">Learn more</a>
               </div>
            </div>
            <div class="col-md-6 pr-0 clip-right">
               <p class="py-200">  </p>
            </div>
         </div>
      </div>
      <!-- End About Us Area -->
      <!-- #tabel  Area start --><div id="about" class="back-right-text-c">
  <div class="container wow fadeInUp">
    <div class="row text-center mb-60">
      <div class="title wow fadeInUp">
        <h1>Discover flexible plans designed for every business size</h1>
        <p class="about_bottom_h mt-50">
          Choose the plan that fits your needs. Our services ensure reliable performance and support so you can focus on growing your business.
        </p>
      </div>
    </div>
  </div>

  <div class="container">
    <div class="row wow fadeInUp">
      
      <div class="col-md-4 col-sm-6 p-0">
        <div class="pricingTable mt-50">
          <div class="pricingTable-header">
            <span class="price-value">
              <span class="currency">$</span>59
              <span class="month"> /mo</span>
            </span>
            <h3 class="heading">Business</h3>
          </div>
          <div class="pricing-content">
            <h2 class="tabel-color">Beginner</h2>
            <ul>
              <li>1 GB of storage</li>
              <li>Unlimited traffic</li>
              <li>Forum access</li>
              <li>Support at $25/hour</li>
            </ul>
            <a href="#" class="btn btn-default">Choose Plan</a>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-sm-6 p-0 wow fadeInUp">
        <div class="pricingTable pricing-three pt-100">
          <div class="pricingTable-header">
            <span class="price-value">
              <span class="currency">$</span>96
              <span class="month"> /mo</span>
            </span>
            <h3 class="heading">Business</h3>
          </div>
          <div class="pricing-content">
            <h2 class="tabel-color">Advanced</h2>
            <ul>
              <li>5 GB of storage</li>
              <li>Unlimited traffic</li>
              <li>Priority forum access</li>
              <li>Support at $20/hour</li>
            </ul>
            <a href="#" class="btn btn-default">Choose Plan</a>
          </div>
        </div>
      </div>

      <div class="col-md-4 col-sm-6 p-0 wow fadeInUp">
        <div class="pricingTable mt-50">
          <div class="pricingTable-header">
            <span class="price-value">
              <span class="currency">$</span>108
              <span class="month"> /mo</span>
            </span>
            <h3 class="heading">Business</h3>
          </div>
          <div class="pricing-content">
            <h2 class="tabel-color">Professional</h2>
            <ul>
              <li>10 GB of storage</li>
              <li>Unlimited traffic</li>
              <li>Dedicated forum access</li>
              <li>Priority support at $15/hour</li>
            </ul>
            <a href="#" class="btn btn-default">Choose Plan</a>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>

      <!-- End tabel Us Area -->
      <!--#Our Testimonial Area start-->
    <section id="testimonials" class="testimonial_area row">
  <div class="container">
    <div class="title wow fadeInUp">
      <h2 class="text-center mb-5">What Our Clients Say</h2>
    </div>
    <div class="testimonial_carousel owl-carousel">
      
      <div class="item">
        <div class="media">
          <div class="media-left">
            <a href="#">
              <img class="media-object rounded-circle" src="assets/images/testimonial-3.jpg" alt="Client Photo">
            </a>
          </div>
        </div>
        <p class="text-center px-4">
          "Working with this team has been a game-changer. Their professionalism and dedication to quality are unmatched."
        </p>
        <div class="media-body text-center">
          <h4 class="body-slider media-heading">Sophia Roberts</h4>
          <div class="img-s">
            <img src="assets/images/logos-s.png" alt="Client Company Logo">
          </div>
        </div>
      </div>

      <div class="item">
        <div class="media">
          <div class="media-left">
            <a href="#">
              <img class="media-object rounded-circle" src="assets/images/testimonial-2.jpg" alt="Client Photo">
            </a>
          </div>
        </div>
        <p class="text-center px-4">
          "Their creative solutions helped elevate our brand to new heights. Highly recommend their services!"
        </p>
        <div class="media-body text-center">
          <h4 class="body-slider media-heading">James Anderson</h4>
          <div class="img-s">
            <img src="assets/images/logos-s.png" alt="Client Company Logo">
          </div>
        </div>
      </div>

      <div class="item">
        <div class="media">
          <div class="media-left">
            <a href="#">
              <img class="media-object rounded-circle" src="assets/images/testimonial-1.jpg" alt="Client Photo">
            </a>
          </div>
        </div>
        <p class="text-center px-4">
          "Exceptional service and great attention to detail. They truly care about client success."
        </p>
        <div class="media-body text-center">
          <h4 class="body-slider media-heading">Emily Clark</h4>
          <div class="img-s">
            <img src="assets/images/logos-s.png" alt="Client Company Logo">
          </div>
        </div>
      </div>
      
    </div>
  </div>
</section>

      <!--#End Our testimonial Area -->
    <div class="our_partners_area bg-grediunt">
         <div class="book_now_aera ">
            <div class="container">
               <div class="row book_now">
                  <div class="col-md-5 booking_text">
                     <h4>Full insight into the customer journey.<br>
                        No SQL required.
                     </h4>
                     <p>Get started for free to see who your customers are, what they do and what keeps them coming back.</p>
                  </div>
                  <div class="col-md-7 p0 book_bottun">
                     <div class="col-md-7">
                       
                     </div>
                     <div class="col-md-5">
                        <div class="top-banner wow fadeInRight text-left" style="visibility: visible; animation-name: fadeInRight;">
                           <a id="#services" href="contact.html" class="btn btn-primary  wow fadeInUp  js-scroll-trigger" data-wow-delay="1s" style="visibility: visible; animation-delay: 1s; animation-name: fadeInUp;">CONTACT SALES</a>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!--#start Our footer Area -->
     <div class="our_footer_area">
  <div class="book_now_aera">
    <div class="container wow fadeInUp">
      <div class="row book_now">

        <div class="col-md-4">
          <a class="logo-biss" href="index.html">
            <img src="assets/images/logo_img.png" alt="Company Logo">
          </a>
          <p class="footer-h">
            Delivering innovative solutions that empower your business to grow and succeed in the digital world.
          </p>
          <div class="bigpixi-footer-social">
            <a href="#" target="_blank"><i class="fa fa-facebook-square fa-3x social"></i></a>
            <a href="#" target="_blank"><i class="fa fa-twitter-square fa-3x social"></i></a>
            <a href="#" target="_blank"><i class="fa fa-instagram fa-3x social"></i></a>
          </div>
        </div>

        <div class="col-md-1"></div>

        <div class="col-md-3">
          <h2 class="footer-top">Solutions</h2>
          <ul class="footer-menu">
            <li><a href="#">SaaS</a></li>
            <li><a href="#">Mobile</a></li>
            <li><a href="#">Commerce</a></li>
            <li><a href="#">Gaming</a></li>
            <li><a href="#">Finance</a></li>
            <li><a href="#">Media</a></li>
          </ul>
        </div>

        <div class="col-md-4">
          <ul class="location">
            <li class="footer-left-h"><i class="fa fa-map-marker"></i>505 Thornall St #301, Edison, NJ 08837, USA</li>
            <li class="footer-left-h"><i class="fa fa-phone"></i>Call Us<br>+1-982-858-7452<br>+1-982-858-7453</li>
            <li class="footer-left-h"><i class="fa fa-envelope-o"></i>Email<br><a href="mailto:enquiry@yourdomain.com">enquiry@iconic.com</a></li>
          </ul>
        </div>

        <div class="col-md-12 text-center mt-4">
          <p class="color-gray">
            &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved | Designed by Iconic
          </p>
        </div>

      </div>
    </div>
  </div>
</div>

      <!--#End Our footer Area -->
      <!-- The following is only needed when the video is in the html
         otherwise the who .hero__overlay html can be removed -->
      <div class="hero__overlay">
         <div class="hero__modal">
            <a class="hero__close" href="#">Close</a>
            <iframe allowscriptaccess="always" id="hero-video" class="hero__player" src="https://www.youtube.com/embed/1NSA8ycGfKg?enablejsapi=1&html5=1" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
         </div>
         <!-- /.hero__modal -->    
      </div>
      <!-- /.hero__overlay -->
      <!-- jQuery JS -->
      <script src="assets/js/jquery-1.12.0.min.js"></script>
      <!-- Bootstrap JS -->
      <script src="assets/js/bootstrap.min.js"></script>
       <script src="assets/vendors/popup/lightbox.min.js"></script>
      <!-- Animate JS -->
      <script src="assets/vendors/animate/wow.min.js"></script>
      <!-- Owlcarousel JS -->
      <script src="assets/vendors/owl_carousel/owl.carousel.min.js"></script>
      <!-- Stellar JS -->
    
      <!-- Theme JS -->
      <script src="assets/js/theme.min.js"></script>
   </body>
</html>