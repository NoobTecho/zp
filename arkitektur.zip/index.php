<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
<title>Modern Architecture & Design Solutions</title>

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;500;600&family=Teko:wght@400;500;600&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-border position-relative text-primary" style="width: 6rem; height: 6rem;" role="status"></div>
        <img class="position-absolute top-50 start-50 translate-middle" src="img/icons/icon-1.png" alt="Icon">
    </div>
    <!-- Spinner End -->

<!-- Topbar Start -->
<div class="container-fluid bg-dark p-0 wow fadeIn" data-wow-delay="0.1s">
    <div class="row gx-0 d-none d-lg-flex">
        <div class="col-lg-7 px-5 text-start">
            <div class="h-100 d-inline-flex align-items-center py-3 me-3">
                <a class="text-body px-2" href="tel:+442036789871"><i class="fa fa-phone-alt text-primary me-2"></i>+44 203 678 9871</a>
                <a class="text-body px-2" href="mailto:hello@urbanformstudio.com"><i class="fa fa-envelope-open text-primary me-2"></i>hello@urbanformstudio.com</a>
            </div>
        </div>
        <div class="col-lg-5 px-5 text-end">
            <div class="h-100 d-inline-flex align-items-center py-3 me-2">
                <a class="text-body px-2" href="">Legal</a>
                <a class="text-body px-2" href="">Data Policy</a>
            </div>
            <div class="h-100 d-inline-flex align-items-center">
                <a class="btn btn-sm-square btn-outline-body me-1" href=""><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-sm-square btn-outline-body me-1" href=""><i class="fab fa-twitter"></i></a>
                <a class="btn btn-sm-square btn-outline-body me-1" href=""><i class="fab fa-linkedin-in"></i></a>
                <a class="btn btn-sm-square btn-outline-body me-0" href=""><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </div>
</div>

    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg bg-white navbar-light sticky-top py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
        <a href="index.html" class="navbar-brand ms-4 ms-lg-0">
            <h1 class="text-primary m-0"><img class="me-3" src="img/icons/icon-1.png" alt="Icon">Arkitektur</h1>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav ms-auto p-4 p-lg-0">
                <a href="index.html" class="nav-item nav-link active">Home</a>
                <a href="about.html" class="nav-item nav-link">About</a>
                <a href="service.html" class="nav-item nav-link">Services</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                    <div class="dropdown-menu border-0 m-0">
                        <a href="feature.html" class="dropdown-item">Our Features</a>
                        <a href="project.html" class="dropdown-item">Our Projects</a>
                        <a href="team.html" class="dropdown-item">Team Members</a>
                        <a href="appointment.html" class="dropdown-item">Appointment</a>
                        <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                        <a href="404.html" class="dropdown-item">404 Page</a>
                    </div>
                </div>
                <a href="contact.html" class="nav-item nav-link">Contact</a>
            </div>
            <a href="" class="btn btn-primary py-2 px-4 d-none d-lg-block">Appointment</a>
        </div>
    </nav>
    <!-- Navbar End -->

<!-- Carousel Start -->
<div class="container-fluid p-0 pb-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="owl-carousel header-carousel position-relative">
        <div class="owl-carousel-item position-relative" data-dot="<img src='img/carousel-1.jpg'>">
            <img class="img-fluid" src="img/carousel-1.jpg" alt="">
            <div class="owl-carousel-inner">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-10 col-lg-8">
                            <h1 class="display-1 text-white animated slideInDown">Innovative Architecture for Modern Living</h1>
                            <p class="fs-5 fw-medium text-white mb-4 pb-3">We create spaces that blend elegance, function, and sustainability through thoughtful design and advanced planning.</p>
                            <a href="" class="btn btn-primary py-3 px-5 animated slideInLeft">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="owl-carousel-item position-relative" data-dot="<img src='img/carousel-2.jpg'>">
            <img class="img-fluid" src="img/carousel-2.jpg" alt="">
            <div class="owl-carousel-inner">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-10 col-lg-8">
                            <h1 class="display-1 text-white animated slideInDown">Shaping Tomorrow’s Urban Landscapes</h1>
                            <p class="fs-5 fw-medium text-white mb-4 pb-3">From concept to completion, we transform visionary ideas into striking architectural landmarks worldwide.</p>
                            <a href="" class="btn btn-primary py-3 px-5 animated slideInLeft">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="owl-carousel-item position-relative" data-dot="<img src='img/carousel-3.jpg'>">
            <img class="img-fluid" src="img/carousel-3.jpg" alt="">
            <div class="owl-carousel-inner">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-10 col-lg-8">
                            <h1 class="display-1 text-white animated slideInDown">Timeless Design with a Contemporary Edge</h1>
                            <p class="fs-5 fw-medium text-white mb-4 pb-3">We specialize in bespoke architecture that reflects individuality, purpose, and enduring style across every project.</p>
                            <a href="" class="btn btn-primary py-3 px-5 animated slideInLeft">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Carousel End -->

<!-- Facts Start -->
<div class="container-xxl py-5">
    <div class="container pt-5">
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="fact-item text-center bg-light h-100 p-5 pt-0">
                    <div class="fact-icon">
                        <img src="img/icons/icon-2.png" alt="Icon">
                    </div>
                    <h3 class="mb-3">Design Approach</h3>
                    <p class="mb-0">We prioritize user-centric, sustainable architecture that balances innovation with timeless aesthetics.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="fact-item text-center bg-light h-100 p-5 pt-0">
                    <div class="fact-icon">
                        <img src="img/icons/icon-3.png" alt="Icon">
                    </div>
                    <h3 class="mb-3">Innovative Solutions</h3>
                    <p class="mb-0">Our team crafts adaptive design strategies tailored to dynamic environments and evolving client needs.</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="fact-item text-center bg-light h-100 p-5 pt-0">
                    <div class="fact-icon">
                        <img src="img/icons/icon-4.png" alt="Icon">
                    </div>
                    <h3 class="mb-3">Project Management</h3>
                    <p class="mb-0">We ensure seamless execution through structured planning, transparent communication, and expert oversight.</p>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Facts End -->

<!-- About Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                <div class="about-img">
                    <img class="img-fluid" src="img/about-1.jpg" alt="">
                    <img class="img-fluid" src="img/about-2.jpg" alt="">
                </div>
            </div>
            <div class="col-lg-6 wow fadeIn" data-wow-delay="0.5s">
                <h4 class="section-title">About Us</h4>
                <h1 class="display-5 mb-4">A Creative Architecture Agency For Your Dream Home</h1>
                <p>We specialize in contemporary architecture that blends modern aesthetics with functional living. Every design reflects a deep commitment to excellence and originality.</p>
                <p class="mb-4">Our team brings together innovative ideas and proven experience to craft spaces that inspire. From residential to commercial, we build with purpose and precision.</p>
                <div class="d-flex align-items-center mb-5">
                    <div class="d-flex flex-shrink-0 align-items-center justify-content-center border border-5 border-primary" style="width: 120px; height: 120px;">
                        <h1 class="display-1 mb-n2" data-toggle="counter-up">25</h1>
                    </div>
                    <div class="ps-4">
                        <h3>Years</h3>
                        <h3>Working</h3>
                        <h3 class="mb-0">Experience</h3>
                    </div>
                </div>
                <a class="btn btn-primary py-3 px-5" href="">Read More</a>
            </div>
        </div>
    </div>
</div>

    <!-- About End -->

<!-- Service Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
            <h4 class="section-title">Our Services</h4>
            <h1 class="display-5 mb-4">We Focused On Modern Architecture And Interior Design</h1>
        </div>
        <div class="row g-4">
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item d-flex position-relative text-center h-100">
                    <img class="bg-img" src="img/service-1.jpg" alt="">
                    <div class="service-text p-5">
                        <img class="mb-4" src="img/icons/icon-5.png" alt="Icon">
                        <h3 class="mb-3">Architecture</h3>
                        <p class="mb-4">We design inspiring structures that blend creativity with structural precision to deliver timeless aesthetics.</p>
                        <a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item d-flex position-relative text-center h-100">
                    <img class="bg-img" src="img/service-2.jpg" alt="">
                    <div class="service-text p-5">
                        <img class="mb-4" src="img/icons/icon-6.png" alt="Icon">
                        <h3 class="mb-3">3D Animation</h3>
                        <p class="mb-4">Bring your architectural vision to life with immersive 3D walkthroughs and realistic visualizations.</p>
                        <a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item d-flex position-relative text-center h-100">
                    <img class="bg-img" src="img/service-3.jpg" alt="">
                    <div class="service-text p-5">
                        <img class="mb-4" src="img/icons/icon-7.png" alt="Icon">
                        <h3 class="mb-3">House Planning</h3>
                        <p class="mb-4">Customized floor plans designed for functional living and elegant architectural harmony.</p>
                        <a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="service-item d-flex position-relative text-center h-100">
                    <img class="bg-img" src="img/service-4.jpg" alt="">
                    <div class="service-text p-5">
                        <img class="mb-4" src="img/icons/icon-8.png" alt="Icon">
                        <h3 class="mb-3">Interior Design</h3>
                        <p class="mb-4">We craft interiors that reflect your personality with a modern edge and seamless functionality.</p>
                        <a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="service-item d-flex position-relative text-center h-100">
                    <img class="bg-img" src="img/service-5.jpg" alt="">
                    <div class="service-text p-5">
                        <img class="mb-4" src="img/icons/icon-9.png" alt="Icon">
                        <h3 class="mb-3">Renovation</h3>
                        <p class="mb-4">Transform outdated spaces into contemporary masterpieces with our expert renovation services.</p>
                        <a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="service-item d-flex position-relative text-center h-100">
                    <img class="bg-img" src="img/service-6.jpg" alt="">
                    <div class="service-text p-5">
                        <img class="mb-4" src="img/icons/icon-10.png" alt="Icon">
                        <h3 class="mb-3">Construction</h3>
                        <p class="mb-4">From foundation to finish, we build with precision, passion, and a commitment to architectural integrity.</p>
                        <a class="btn" href=""><i class="fa fa-plus text-primary me-3"></i>Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Service End -->

<!-- Feature Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                <h4 class="section-title">Why Choose Us!</h4>
                <h1 class="display-5 mb-4">Why You Should Trust Us — Discover What Sets Us Apart</h1>
                <p class="mb-4">With a passion for architectural excellence and a commitment to quality, we bring your vision to life through innovative design, thoughtful planning, and seamless execution. Our client-centric approach ensures every project reflects your unique needs and aspirations.</p>
                <div class="row g-4">
                    <div class="col-12">
                        <div class="d-flex align-items-start">
                            <img class="flex-shrink-0" src="img/icons/icon-2.png" alt="Icon">
                            <div class="ms-4">
                                <h3>Design Approach</h3>
                                <p class="mb-0">We prioritize creativity and functionality, delivering spaces that are not only beautiful but also purposeful and intuitive.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="d-flex align-items-start">
                            <img class="flex-shrink-0" src="img/icons/icon-3.png" alt="Icon">
                            <div class="ms-4">
                                <h3>Innovative Solutions</h3>
                                <p class="mb-0">By embracing the latest design technologies and techniques, we provide cutting-edge solutions tailored to modern lifestyles.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="d-flex align-items-start">
                            <img class="flex-shrink-0" src="img/icons/icon-4.png" alt="Icon">
                            <div class="ms-4">
                                <h3>Project Management</h3>
                                <p class="mb-0">From concept to completion, our experienced team ensures your project is delivered on time, within budget, and to the highest standards.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="feature-img">
                    <img class="img-fluid" src="img/about-2.jpg" alt="Team Collaboration">
                    <img class="img-fluid" src="img/about-1.jpg" alt="Design Presentation">
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Feature End -->


    <!-- Project Start -->
    <div class="container-xxl project py-5">
        <div class="container">
            <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
                <h4 class="section-title">Our Projects</h4>
                <h1 class="display-5 mb-4">Visit Our Latest Projects And Our Innovative Works</h1>
            </div>
            <div class="row g-4 wow fadeInUp" data-wow-delay="0.3s">
                <div class="col-lg-4">
                    <div class="nav nav-pills d-flex justify-content-between w-100 h-100 me-4">
                        <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-4 active" data-bs-toggle="pill" data-bs-target="#tab-pane-1" type="button">
                            <h3 class="m-0">01. Modern Complex</h3>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-4" data-bs-toggle="pill" data-bs-target="#tab-pane-2" type="button">
                            <h3 class="m-0">02. Royal Hotel</h3>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-4" data-bs-toggle="pill" data-bs-target="#tab-pane-3" type="button">
                            <h3 class="m-0">03. Mexwel Buiding</h3>
                        </button>
                        <button class="nav-link w-100 d-flex align-items-center text-start p-4 mb-0" data-bs-toggle="pill" data-bs-target="#tab-pane-4" type="button">
                            <h3 class="m-0">04. Shopping Complex</h3>
                        </button>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="tab-content w-100">
                        <div class="tab-pane fade show active" id="tab-pane-1">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute img-fluid w-100 h-100" src="img/project-1.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
<div class="col-md-6">
    <h1 class="mb-3">25 Years of Excellence in the Architecture Industry</h1>
    <p class="mb-4">
        With over two decades of experience, we’ve built a reputation for delivering timeless designs, innovative solutions, and meticulously managed projects. From concept to completion, our work reflects dedication, creativity, and precision.
    </p>
    <p><i class="fa fa-check text-primary me-3"></i>Client-Focused Design Approach</p>
    <p><i class="fa fa-check text-primary me-3"></i>Cutting-Edge and Innovative Solutions</p>
    <p><i class="fa fa-check text-primary me-3"></i>Comprehensive Project Management</p>
    <a href="#" class="btn btn-primary py-3 px-5 mt-3">Learn More</a>
</div>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-2">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute img-fluid w-100 h-100" src="img/project-2.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                            <div class="col-md-6">
    <h1 class="mb-3">25 Years of Experience in the Architecture Industry</h1>
    <p class="mb-4">
        For over two decades, we’ve been transforming visions into reality with innovative design, attention to detail, and a commitment to excellence. From planning to execution, our team ensures each project reflects quality and creativity.
    </p>
    <p><i class="fa fa-check text-primary me-3"></i>Strategic Design Approach</p>
    <p><i class="fa fa-check text-primary me-3"></i>Innovative, Tailored Solutions</p>
    <p><i class="fa fa-check text-primary me-3"></i>Seamless Project Management</p>
    <a href="#" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
</div>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-3">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute img-fluid w-100 h-100" src="img/project-3.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
<div class="col-md-6">
    <h1 class="mb-3">25 Years of Experience in the Architecture Industry</h1>
    <p class="mb-4">
        With over 25 years of industry expertise, we specialize in turning ideas into impactful architectural solutions. Our approach blends creativity with precision to deliver results that exceed expectations.
    </p>
    <p><i class="fa fa-check text-primary me-3"></i>Strategic Design Approach</p>
    <p><i class="fa fa-check text-primary me-3"></i>Innovative and Custom Solutions</p>
    <p><i class="fa fa-check text-primary me-3"></i>Comprehensive Project Management</p>
    <a href="#" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
</div>

                            </div>
                        </div>
                        <div class="tab-pane fade" id="tab-pane-4">
                            <div class="row g-4">
                                <div class="col-md-6" style="min-height: 350px;">
                                    <div class="position-relative h-100">
                                        <img class="position-absolute img-fluid w-100 h-100" src="img/project-4.jpg"
                                            style="object-fit: cover;" alt="">
                                    </div>
                                </div>
                             <div class="col-md-6">
    <h1 class="mb-3">25 Years of Experience in the Architecture Industry</h1>
    <p class="mb-4">
        With a legacy of over two decades, we bring expertise, innovation, and passion to every project. Our team is dedicated to transforming spaces through thoughtful design, cutting-edge solutions, and seamless execution.
    </p>
    <p><i class="fa fa-check text-primary me-3"></i>Strategic Design Approach</p>
    <p><i class="fa fa-check text-primary me-3"></i>Innovative Architectural Solutions</p>
    <p><i class="fa fa-check text-primary me-3"></i>Efficient Project Management</p>
    <a href="#" class="btn btn-primary py-3 px-5 mt-3">Read More</a>
</div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Project End -->

<!-- Team Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
            <h4 class="section-title">Meet Our Team</h4>
            <h1 class="display-5 mb-4">Creative Minds Behind Your Dream Home</h1>
        </div>
        <div class="row g-0 team-items">
            <!-- Team Member -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="team-item position-relative">
                    <div class="position-relative">
                        <img class="img-fluid" src="img/team-1.jpg" alt="Architect John Doe">
                        <div class="team-social text-center">
                            <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <div class="bg-light text-center p-4">
                        <h3 class="mt-2">John Doe</h3>
                        <span class="text-primary">Chief Architect</span>
                    </div>
                </div>
            </div>

            <!-- Team Member -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="team-item position-relative">
                    <div class="position-relative">
                        <img class="img-fluid" src="img/team-2.jpg" alt="Architect Jane Smith">
                        <div class="team-social text-center">
                            <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <div class="bg-light text-center p-4">
                        <h3 class="mt-2">Jane Smith</h3>
                        <span class="text-primary">Interior Designer</span>
                    </div>
                </div>
            </div>

            <!-- Team Member -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="team-item position-relative">
                    <div class="position-relative">
                        <img class="img-fluid" src="img/team-3.jpg" alt="Architect Michael Lee">
                        <div class="team-social text-center">
                            <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <div class="bg-light text-center p-4">
                        <h3 class="mt-2">Michael Lee</h3>
                        <span class="text-primary">3D Visualization Expert</span>
                    </div>
                </div>
            </div>

            <!-- Team Member -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                <div class="team-item position-relative">
                    <div class="position-relative">
                        <img class="img-fluid" src="img/team-4.jpg" alt="Architect Emily Davis">
                        <div class="team-social text-center">
                            <a class="btn btn-square" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <div class="bg-light text-center p-4">
                        <h3 class="mt-2">Emily Davis</h3>
                        <span class="text-primary">Project Coordinator</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Team End -->

    <!-- Team End -->


    <!-- Appointment Start -->
<!-- Appointment Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-5">
            <!-- Contact Info -->
<div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
    <h4 class="section-title">Appointment</h4>
    <h1 class="display-5 mb-4">Book Your SaaS Demo Session</h1>
    <p class="mb-4">Discover how our platform can scale your business. Schedule a tailored demo with our product specialists today.</p>
    <div class="row g-4">
        <div class="col-12">
            <div class="d-flex">
                <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-light" style="width: 65px; height: 65px;">
                    <i class="fa fa-2x fa-phone-alt text-primary"></i>
                </div>
                <div class="ms-4">
                    <p class="mb-2">Call Us</p>
                    <h3 class="mb-0">+44 207 654 3210</h3>
                </div>
            </div>
        </div>
        <div class="col-12">
            <div class="d-flex">
                <div class="d-flex flex-shrink-0 align-items-center justify-content-center bg-light" style="width: 65px; height: 65px;">
                    <i class="fa fa-2x fa-envelope-open text-primary"></i>
                </div>
                <div class="ms-4">
                    <p class="mb-2">Email Us</p>
                    <h3 class="mb-0">hello@devlaunchers.net</h3>
                </div>
            </div>
        </div>
    </div>
</div>


            <!-- Appointment Form -->
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                <form>
                    <div class="row g-3">
                        <div class="col-12 col-sm-6">
                            <input type="text" class="form-control" placeholder="Your Name" required style="height: 55px;">
                        </div>
                        <div class="col-12 col-sm-6">
                            <input type="email" class="form-control" placeholder="Your Email" required style="height: 55px;">
                        </div>
                        <div class="col-12 col-sm-6">
                            <input type="tel" class="form-control" placeholder="Your Mobile" required style="height: 55px;">
                        </div>
                        <div class="col-12 col-sm-6">
                            <select class="form-select" required style="height: 55px;">
                                <option selected disabled>Choose Service</option>
                                <option value="1">Architectural Design</option>
                                <option value="2">Interior Planning</option>
                                <option value="3">Project Supervision</option>
                            </select>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="date" id="date" data-target-input="nearest">
                                <input type="text"
                                    class="form-control datetimepicker-input"
                                    placeholder="Select Date"
                                    data-target="#date" data-toggle="datetimepicker"
                                    required style="height: 55px;">
                            </div>
                        </div>
                        <div class="col-12 col-sm-6">
                            <div class="time" id="time" data-target-input="nearest">
                                <input type="text"
                                    class="form-control datetimepicker-input"
                                    placeholder="Select Time"
                                    data-target="#time" data-toggle="datetimepicker"
                                    required style="height: 55px;">
                            </div>
                        </div>
                        <div class="col-12">
                            <textarea class="form-control" rows="5" placeholder="Your Message" required></textarea>
                        </div>
                        <div class="col-12">
                            <button class="btn btn-primary w-100 py-3" type="submit">Book Appointment</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<!-- Appointment End -->

    <!-- Appointment End -->

<!-- Testimonial Start -->
<div class="container-xxl py-5">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 600px;">
            <h4 class="section-title">Testimonial</h4>
            <h1 class="display-5 mb-4">Trusted by Thousands of Happy Clients</h1>
        </div>
        <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
            <!-- Testimonial 1 -->
            <div class="testimonial-item text-center" data-dot="<img class='img-fluid' src='img/testimonial-1.jpg' alt='Client 1'>">
                <p class="fs-5 fst-italic">"Their expertise brought our dream home to life. The design process was smooth, and the results were even better than expected."</p>
                <h3>Jane Doe</h3>
                <span class="text-primary">Interior Designer</span>
            </div>
            <!-- Testimonial 2 -->
            <div class="testimonial-item text-center" data-dot="<img class='img-fluid' src='img/testimonial-2.jpg' alt='Client 2'>">
                <p class="fs-5 fst-italic">"Exceptional service from start to finish. The team was professional, communicative, and incredibly creative."</p>
                <h3>Michael Lee</h3>
                <span class="text-primary">Real Estate Developer</span>
            </div>
            <!-- Testimonial 3 -->
            <div class="testimonial-item text-center" data-dot="<img class='img-fluid' src='img/testimonial-3.jpg' alt='Client 3'>">
                <p class="fs-5 fst-italic">"I highly recommend them! They truly listened to what I wanted and delivered something even more beautiful."</p>
                <h3>Sophia Turner</h3>
                <span class="text-primary">Homeowner</span>
            </div>
        </div>
    </div>
</div>
<!-- Testimonial End -->

    <!-- Testimonial End -->

<!-- Footer Start -->
<div class="container-fluid bg-dark text-body footer mt-5 pt-5 px-0 wow fadeIn" data-wow-delay="0.1s">
<div class="container py-5">
    <div class="row g-5">
        <!-- Contact Info -->
        <div class="col-lg-3 col-md-6">
            <h3 class="text-light mb-4">Contact Us</h3>
            <p class="mb-2"><i class="fa fa-map-marker-alt text-primary me-3"></i>480 Elm Avenue, San Francisco, CA</p>
            <p class="mb-2"><i class="fa fa-phone-alt text-primary me-3"></i>+1 (628) 349-7812</p>
            <p class="mb-2"><i class="fa fa-envelope text-primary me-3"></i>hello@modarchspace.com</p>
            <div class="d-flex pt-2">
                <a class="btn btn-square btn-outline-body me-1" href="#"><i class="fab fa-twitter"></i></a>
                <a class="btn btn-square btn-outline-body me-1" href="#"><i class="fab fa-facebook-f"></i></a>
                <a class="btn btn-square btn-outline-body me-1" href="#"><i class="fab fa-youtube"></i></a>
                <a class="btn btn-square btn-outline-body me-0" href="#"><i class="fab fa-linkedin-in"></i></a>
            </div>
        </div>

        <!-- Services -->
        <div class="col-lg-3 col-md-6">
            <h3 class="text-light mb-4">Our Services</h3>
            <a class="btn btn-link" href="#">Contemporary Architecture</a>
            <a class="btn btn-link" href="#">Exterior Modeling</a>
            <a class="btn btn-link" href="#">Residential Planning</a>
            <a class="btn btn-link" href="#">Interior Styling</a>
            <a class="btn btn-link" href="#">Project Management</a>
        </div>

        <!-- Quick Links -->
        <div class="col-lg-3 col-md-6">
            <h3 class="text-light mb-4">Quick Links</h3>
            <a class="btn btn-link" href="#">Our Studio</a>
            <a class="btn btn-link" href="#">Get in Touch</a>
            <a class="btn btn-link" href="#">Latest Projects</a>
            <a class="btn btn-link" href="#">Terms of Service</a>
            <a class="btn btn-link" href="#">Client Support</a>
        </div>

        <!-- Newsletter -->
        <div class="col-lg-3 col-md-6">
            <h3 class="text-light mb-4">Newsletter</h3>
            <p>Subscribe for updates, design trends, and industry insights.</p>
            <div class="position-relative mx-auto" style="max-width: 400px;">
                <input class="form-control bg-transparent w-100 py-3 ps-4 pe-5" type="email" placeholder="Your email" aria-label="Email for newsletter">
                <button type="submit" class="btn btn-primary py-2 position-absolute top-0 end-0 mt-2 me-2">Sign Up</button>
            </div>
        </div>
    </div>
</div>

    <!-- Copyright -->
<div class="container-fluid border-top border-secondary pt-4">
    <div class="container">
        <div class="row">
            <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                &copy; <a class="text-primary fw-semibold" href="#">UrbanForm Studio</a>, All Rights Reserved.
            </div>

        </div>
    </div>
</div>

</div>
<!-- Footer End -->

    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="lib/tempusdominus/js/moment.min.js"></script>
    <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>