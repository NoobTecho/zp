<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Vira | Smart. Sleek. Digital Lifestyle.</title>

        <link rel="shortcut icon" type="image/x-icon" href="assets/images/logo.png"/>

        <link href="assets/css/bootstrap.min.css" rel="stylesheet">
        <link href="assets/css/bootstrap-theme.min.css" rel="stylesheet">

        <link href="assets/css/owl.carousel.css" rel="stylesheet">
        <link href="assets/css/owl.theme.default.min.css" rel="stylesheet">

        <link href="assets/css/magnific-popup.css" rel="stylesheet">

        <link href="assets/css/style.css" rel="stylesheet">


        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div id="menu-item" class="menu-item hide-menu">
            <div class="container">
                <ul>
                    <a href="index.html"><li>home</li></a>
                    <a href="#about"><li>about</li></a>
                    <a href="#expertise"><li>expertise</li></a>
                    <a href="#workstation"><li>workstation</li></a>
                    <a href="#team"><li>team</li></a>
                    <a href="#contact"><li>contact</li></a>
                    <a href="elements.html"><li>Elements</li></a>
                </ul>
            </div>
        </div>
        <div class="main">
            <header class="bg-img header">
                <nav class="navbar navbar-default navbar-vira">
                    <div class="container">
                        <div class="navigation-bar">
                            <div class="row">
                                <div class="col-xs-6">
                                    <div class="logo">
                                        <a href="index.html"><span class="fa fa-viacoin"></span></a>
                                    </div>
                                </div>
                                <div class="col-xs-6 text-right">
                                    <div class="menu m">
                                        <a href="#"><span class="ion-navicon _ion-android-menu"></span></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
                <div class="container">
                    <div class="row">
                        <div class="intro-box">
                            <div class="intro">
                                <h1>We are vira agency</h1>
                                <p>Creative digital agency based in US</p>
                                <a class="btn vira-btn" href="#">Explore us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <section id="about" class="about section">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-8 col-sm-offset-2">
                            <h2 class="title">About agency</h2>
                            <p>
                                Complimenten, bewonderend gefluit en lonkende blikken zijn enkele risico’s die The Garment Club met zich meebrengt. Onze enige missie is dat jij de best geklede man van de omgeving bent. Laat gratis een op eden box samenstellen door je personal shopper en betaal. 
                            </p>
                            <img src="assets/images/signature.png">
                            <span>Vira Studio-ceo</span>
                        </div>
                    </div>
                </div>
            </section>
            <section class="purpose section">
                <div class="container">
                    <h2 class="title">What we do</h2>
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="vira-card">
                                <div class="vira-card-header">
                                    <div class="card-icon">
                                        <span class="fa fa-diamond" aria-hidden="true"></span>
                                    </div>
                                </div>
                                <div class="vira-card-content">
                                    <h3>Digital Design</h3>
                                    <p>
                                        Complimenten, bewonderend gefluit en lonkende blikken zijn enkele risico’s die The Garment Club met zichlaim meebrengt. Onze enige missiede
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="vira-card">
                                <div class="vira-card-header">
                                    <div class="card-icon">
                                        <span class="fa fa-cogs" aria-hidden="true"></span>
                                    </div>
                                </div>
                                <div class="vira-card-content">
                                    <h3>Web Development</h3>
                                    <p>
                                        Complimenten, bewonderend gefluit en lonkende blikken zijn enkele risico’s die The Garment Club met zichlaim meebrengt. Onze enige missiede
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="vira-card">
                                <div class="vira-card-header">
                                    <div class="card-icon">
                                        <span class="fa fa-bicycle" aria-hidden="true"></span>
                                    </div>
                                </div>
                                <div class="vira-card-content">
                                    <h3>Digital Marketing</h3>
                                    <p>
                                        Complimenten, bewonderend gefluit en lonkende blikken zijn enkele risico’s die The Garment Club met zichlaim meebrengt. Onze enige missiede
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section id="expertise" class="expert">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-sm-6 bg-img">
                            <div></div>
                        </div>
                        <div class="col-sm-5 section">
                            <h2 class="title">Responsive design expert</h2>
                            <div id="expert-slider" class="owl-carousel">
                                <div class="item">
                                    <p>
                                        Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall proposition. Organically grow the holistic world view of disruptiveinnovationvia workplace diversity and empowerment.
                                    </p>
                                </div>
                                <div class="item">
                                    <p>
                                        Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <section class="vira-quote section bg-img">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <img class="quote" src="assets/images/quote.png">
                           <p>
                               A user interface is like a joke. If you have to explain it, it’s not that good.
                           </p>
                           <p class="author">Martin leBlance, Iconfinder</p>
                           <img src="assets/images/mouse.png">
                        </div>
                    </div>
                </div>
            </section>
<section id="workstation" class="work section">
	<div class="container">
		<h2 class="title">Our Workstations</h2>
		<div id="workstation-slider" class="owl-carousel">
			<div class="item">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/4.jpg" alt="Workstation 1">
					</div>
					<div class="vira-card-content">
						<h3>Creative Geeks</h3>
						<p>
							Where innovation meets execution. This setup powers our design, code, and content workflows daily.
						</p>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/5.jpg" alt="Workstation 2">
					</div>
					<div class="vira-card-content">
						<h3>Creative Freaks</h3>
						<p>
							Organized chaos in the best way — built for rapid prototyping, brainstorming, and caffeine-powered breakthroughs.
						</p>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/6.jpg" alt="Workstation 3">
					</div>
					<div class="vira-card-content">
						<h3>Creative Nerds</h3>
						<p>
							Where clean code is born. Optimized for performance, automation, and late-night debugging marathons.
						</p>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/4.jpg" alt="Workstation 4">
					</div>
					<div class="vira-card-content">
						<h3>Creative Geeks</h3>
						<p>
							The heart of our UI/UX experiments. Whiteboards, tablets, and ideas everywhere.
						</p>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/5.jpg" alt="Workstation 5">
					</div>
					<div class="vira-card-content">
						<h3>Creative Freaks</h3>
						<p>
							Music, mood lights, and motion graphics — this is where creativity flows non-stop.
						</p>
					</div>
				</div>
			</div>
			<div class="item">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/6.jpg" alt="Workstation 6">
					</div>
					<div class="vira-card-content">
						<h3>Creative Nerds</h3>
						<p>
							Our devs’ playground. Clean terminal windows, fast machines, and big ideas live here.
						</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

            <section class="watch bg-img">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <span>Watch showreel</span>
                            <a class="popup-youtube btn" href="https://www.youtube.com/watch?v=4KRHIbsl8BE"><span class="fa fa-play"></span></a>
                            <span>with us</span>
                        </div>
                    </div>
                </div>
            </section>
<section id="team" class="team section">
	<div class="container">
		<h2 class="title">Meet Our Team</h2>
		<div class="row">
			<div class="col-sm-4">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/8.jpg" alt="Alex Carter">
					</div>
					<div class="vira-card-content">
						<h3>Alex Carter</h3>
						<p>
							Lead Designer with a passion for minimal aesthetics and seamless user experience. Shapes pixels into purpose.
						</p>
						<div class="social-icons">
							<ul>
								<a href="#"><li><span class="ion-social-facebook"></span></li></a>
								<a href="#"><li><span class="ion-social-twitter"></span></li></a>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/9.jpg" alt="Jordan Lee">
					</div>
					<div class="vira-card-content">
						<h3>Jordan Lee</h3>
						<p>
							Back-End Engineer with a knack for turning complexity into clarity. Obsessed with clean code and scalable systems.
						</p>
						<div class="social-icons">
							<ul>
								<a href="#"><li><span class="ion-social-facebook"></span></li></a>
								<a href="#"><li><span class="ion-social-twitter"></span></li></a>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="vira-card">
					<div class="vira-card-header">
						<img class="img-responsive" src="assets/images/10.jpg" alt="Sasha Kim">
					</div>
					<div class="vira-card-content">
						<h3>Sasha Kim</h3>
						<p>
							Marketing strategist and storyteller. Builds brand experiences that connect emotionally and perform exceptionally.
						</p>
						<div class="social-icons">
							<ul>
								<a href="#"><li><span class="ion-social-facebook"></span></li></a>
								<a href="#"><li><span class="ion-social-twitter"></span></li></a>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

            <section class="subscribe section bg-img">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12">
                            <p>Subscribe to our newsletter to get update</p>
                            <form class="form-inline">
                                <div class="form-group">
                                    <input type="email" class="form-control" id="user-email" placeholder="Write your email here....">
                                </div>
                                <button type="submit" class="btn vira-btn">Send me</button>
                            </form>
                        </div>
                    </div>
                </div>
            </section><section id="contact" class="contact section">
	<div class="container">
		<h2 class="title">Drop us a line</h2>
		<div class="row">
			<div class="col-sm-4">
				<div class="vira-card">
					<div class="vira-card-header">
						<span class="fa fa-map-o" aria-hidden="true"></span>
					</div>
					<div class="vira-card-content">
						<h3>Address</h3>
						<p>
							Jl. Teknologi No. 42, Jakarta, Indonesia
						</p>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="vira-card">
					<div class="vira-card-header">
						<span class="fa fa-phone" aria-hidden="true"></span>
					</div>
					<div class="vira-card-content">
						<h3>Phone</h3>
						<p>
							+62 812 3456 7890
						</p>
					</div>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="vira-card">
					<div class="vira-card-header">
						<span class="fa fa-paper-plane" aria-hidden="true"></span>
					</div>
					<div class="vira-card-content">
						<h3>Email</h3>
						<p>
							contact@vira.tech
						</p>
					</div>
				</div>
			</div>
			<div class="col-sm-12">
				<div class="social-icons">
					<ul>
						<a href="#"><li><span class="ion-social-facebook"></span></li></a>
						<a href="#"><li><span class="ion-social-twitter"></span></li></a>
						<a href="#"><li><span class="ion-social-instagram"></span></li></a>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>

 <footer class="footer">
	<div class="container">
		<div class="row">
			<div class="col-sm-12">
				<p>Built with <span class="fa fa-heart"></span> by <a href="#">AXS Studio</a></p>
			</div>
		</div>
	</div>
</footer>
        </div>

        <script src="assets/js/jquery-3.1.1.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="https://use.fontawesome.com/55b73bf748.js"></script>
        <script src="assets/js/jquery.magnific-popup.js"></script>
        <script src="assets/js/script.js"></script>
    </body>
</html>