<?php
 // You have to download the Premium version to get working Contact form alongwith full documentation of the  template
?>