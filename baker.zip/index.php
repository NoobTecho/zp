<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
<title>NeoGrid Labs - Insights on Startups, Tech & Growth</title>

    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet"> 

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Spinner Start -->
    <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
        <div class="spinner-grow text-primary" role="status"></div>
    </div>
    <!-- Spinner End -->


    <!-- Topbar Start -->
    <div class="container-fluid top-bar bg-dark text-light px-0 wow fadeIn" data-wow-delay="0.1s">
        <div class="row gx-0 align-items-center d-none d-lg-flex">
            <div class="col-lg-6 px-5 text-start">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a class="small text-light" href="#">Home</a></li>
                    <li class="breadcrumb-item"><a class="small text-light" href="#">Career</a></li>
                    <li class="breadcrumb-item"><a class="small text-light" href="#">Terms</a></li>
                    <li class="breadcrumb-item"><a class="small text-light" href="#">Privacy</a></li>
                </ol>
            </div>
            <div class="col-lg-6 px-5 text-end">
                <small>Follow us:</small>
                <div class="h-100 d-inline-flex align-items-center">
                    <a class="btn-lg-square text-primary border-end rounded-0" href=""><i class="fab fa-facebook-f"></i></a>
                    <a class="btn-lg-square text-primary border-end rounded-0" href=""><i class="fab fa-twitter"></i></a>
                    <a class="btn-lg-square text-primary border-end rounded-0" href=""><i class="fab fa-linkedin-in"></i></a>
                    <a class="btn-lg-square text-primary pe-0" href=""><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </div>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
        <a href="index.html" class="navbar-brand ms-4 ms-lg-0">
            <h1 class="text-primary m-0">Baker</h1>
        </a>
        <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            <div class="navbar-nav mx-auto p-4 p-lg-0">
                <a href="index.html" class="nav-item nav-link active">Home</a>
                <a href="about.html" class="nav-item nav-link">About</a>
                <a href="service.html" class="nav-item nav-link">Services</a>
                <a href="product.html" class="nav-item nav-link">Products</a>
                <div class="nav-item dropdown">
                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                    <div class="dropdown-menu m-0">
                        <a href="team.html" class="dropdown-item">Our Team</a>
                        <a href="testimonial.html" class="dropdown-item">Testimonial</a>
                        <a href="404.html" class="dropdown-item">404 Page</a>
                    </div>
                </div>
                <a href="contact.html" class="nav-item nav-link">Contact</a>
            </div>
            <div class=" d-none d-lg-flex">
                <div class="flex-shrink-0 btn-lg-square border border-light rounded-circle">
                    <i class="fa fa-phone text-primary"></i>
                </div>
<div class="ps-3">
    <small class="text-primary d-block">Call Us</small>
    <a href="tel:+5360271984" class="text-light fs-5 text-decoration-none">+536 027 1984</a>
</div>

            </div>
        </div>
    </nav>
    <!-- Navbar End -->

<!-- Carousel Start -->
<div class="container-fluid p-0 pb-5 wow fadeIn" data-wow-delay="0.1s">
    <div class="owl-carousel header-carousel position-relative">
        <div class="owl-carousel-item position-relative">
            <img class="img-fluid" src="img/carousel-1.jpg" alt="">
            <div class="owl-carousel-inner">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-lg-8">
                            <p class="text-primary text-uppercase fw-bold mb-2">// Artisan Breads & Delights</p>
                            <h1 class="display-1 text-light mb-4 animated slideInDown">Crafting Freshness Daily</h1>
                            <p class="text-light fs-5 mb-4 pb-3">Discover handcrafted pastries and oven-fresh breads made with love and the finest ingredients.</p>
                            <a href="" class="btn btn-primary rounded-pill py-3 px-5">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="owl-carousel-item position-relative">
            <img class="img-fluid" src="img/carousel-2.jpg" alt="">
            <div class="owl-carousel-inner">
                <div class="container">
                    <div class="row justify-content-start">
                        <div class="col-lg-8">
                            <p class="text-primary text-uppercase fw-bold mb-2">// Artisan Breads & Delights</p>
                            <h1 class="display-1 text-light mb-4 animated slideInDown">Crafting Freshness Daily</h1>
                            <p class="text-light fs-5 mb-4 pb-3">Experience the warmth of a neighborhood bakery with a modern twist on classic recipes.</p>
                            <a href="" class="btn btn-primary rounded-pill py-3 px-5">Read More</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Carousel End -->


    <!-- Facts Start -->
    <div class="container-xxl py-6">
        <div class="container">
            <div class="row g-4">
                <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.1s">
                    <div class="fact-item bg-light rounded text-center h-100 p-5">
                        <i class="fa fa-certificate fa-4x text-primary mb-4"></i>
                        <p class="mb-2">Years Experience</p>
                        <h1 class="display-5 mb-0" data-toggle="counter-up">50</h1>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.3s">
                    <div class="fact-item bg-light rounded text-center h-100 p-5">
                        <i class="fa fa-users fa-4x text-primary mb-4"></i>
                        <p class="mb-2">Skilled Professionals</p>
                        <h1 class="display-5 mb-0" data-toggle="counter-up">175</h1>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.5s">
                    <div class="fact-item bg-light rounded text-center h-100 p-5">
                        <i class="fa fa-bread-slice fa-4x text-primary mb-4"></i>
                        <p class="mb-2">Total Products</p>
                        <h1 class="display-5 mb-0" data-toggle="counter-up">135</h1>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 wow fadeIn" data-wow-delay="0.7s">
                    <div class="fact-item bg-light rounded text-center h-100 p-5">
                        <i class="fa fa-cart-plus fa-4x text-primary mb-4"></i>
                        <p class="mb-2">Order Everyday</p>
                        <h1 class="display-5 mb-0" data-toggle="counter-up">9357</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Facts End -->

<!-- About Start -->
<div class="container-xxl py-6">
    <div class="container">
        <div class="row g-5">
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="row img-twice position-relative h-100">
                    <div class="col-6">
                        <img class="img-fluid rounded" src="img/about-1.jpg" alt="">
                    </div>
                    <div class="col-6 align-self-end">
                        <img class="img-fluid rounded" src="img/about-2.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="h-100">
                    <p class="text-primary text-uppercase mb-2">// About Us</p>
                    <h1 class="display-6 mb-4">Baking with Love, Passion, and Purpose</h1>
                    <p>Every loaf, pastry, and cake we create is handcrafted with care using the finest ingredients. Our mission is simple: to bring the warmth of fresh-baked goods into every home and heart.</p>
                    <p>Whether you're stopping by for your morning croissant or ordering a custom cake for a special occasion, we strive to make every bite unforgettable.</p>
                    <div class="row g-2 mb-4">
                        <div class="col-sm-6">
                            <i class="fa fa-check text-primary me-2"></i> Quality Products
                        </div>
                        <div class="col-sm-6">
                            <i class="fa fa-check text-primary me-2"></i> Custom Orders
                        </div>
                        <div class="col-sm-6">
                            <i class="fa fa-check text-primary me-2"></i> Easy Online Ordering
                        </div>
                        <div class="col-sm-6">
                            <i class="fa fa-check text-primary me-2"></i> Fast Home Delivery
                        </div>
                    </div>
                    <a class="btn btn-primary rounded-pill py-3 px-5" href="">Read More</a>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- About End -->

<!-- Product Start -->
<div class="container-xxl bg-light my-6 py-6 pt-0">
    <div class="container">
        <!-- Call to Action Banner -->
        <div class="bg-primary text-light rounded-bottom p-5 my-6 mt-0 wow fadeInUp" data-wow-delay="0.1s">
            <div class="row g-4 align-items-center">
                <div class="col-lg-6">
                    <h1 class="display-4 text-light mb-0">The Best Bakery In Your City</h1>
                </div>
                <div class="col-lg-6 text-lg-end">
                    <div class="d-inline-flex align-items-center text-start">
                        <i class="fa fa-phone-alt fa-4x flex-shrink-0"></i>
                        <div class="ms-4">
                            <p class="fs-5 fw-bold mb-0">Call Us</p>
                            <p class="fs-1 fw-bold mb-0">+012 345 6789</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Section Title -->
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="text-primary text-uppercase mb-2">// Bakery Products</p>
            <h1 class="display-6 mb-4">Explore Our Delicious Range of Bakery Treats</h1>
        </div>

        <!-- Product Cards -->
        <div class="row g-4">
            <!-- Cake -->
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="product-item d-flex flex-column bg-white rounded overflow-hidden h-100">
                    <div class="text-center p-4">
                        <div class="d-inline-block border border-primary rounded-pill px-3 mb-3">$11 - $99</div>
                        <h3 class="mb-3">Cakes</h3>
                        <span>From classic chocolate to elegant wedding tiers, our cakes are baked to impress and delight.</span>
                    </div>
                    <div class="position-relative mt-auto">
                        <img class="img-fluid" src="img/product-1.jpg" alt="Cake">
                        <div class="product-overlay">
                            <a class="btn btn-lg-square btn-outline-light rounded-circle" href="#"><i class="fa fa-eye text-primary"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Bread -->
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="product-item d-flex flex-column bg-white rounded overflow-hidden h-100">
                    <div class="text-center p-4">
                        <div class="d-inline-block border border-primary rounded-pill pt-1 px-3 mb-3">$11 - $99</div>
                        <h3 class="mb-3">Breads</h3>
                        <span>Freshly baked every day — crusty on the outside, soft on the inside. Perfect for any meal.</span>
                    </div>
                    <div class="position-relative mt-auto">
                        <img class="img-fluid" src="img/product-2.jpg" alt="Bread">
                        <div class="product-overlay">
                            <a class="btn btn-lg-square btn-outline-light rounded-circle" href="#"><i class="fa fa-eye text-primary"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Cookies -->
            <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="product-item d-flex flex-column bg-white rounded overflow-hidden h-100">
                    <div class="text-center p-4">
                        <div class="d-inline-block border border-primary rounded-pill pt-1 px-3 mb-3">$11 - $99</div>
                        <h3 class="mb-3">Cookies</h3>
                        <span>Crunchy, chewy, and irresistibly sweet — our cookies are made with love in every bite.</span>
                    </div>
                    <div class="position-relative mt-auto">
                        <img class="img-fluid" src="img/product-3.jpg" alt="Cookies">
                        <div class="product-overlay">
                            <a class="btn btn-lg-square btn-outline-light rounded-circle" href="#"><i class="fa fa-eye text-primary"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Product End -->

<!-- Service Start -->
<div class="container-xxl py-6">
    <div class="container">
        <div class="row g-5">
            <!-- Text Content -->
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                <p class="text-primary text-uppercase mb-2">// Our Services</p>
                <h1 class="display-6 mb-4">What Do We Offer For You?</h1>
                <p class="mb-5">
                    Whether you're celebrating a special moment or just craving something sweet, we’re here to serve. Our bakery offers a wide range of high-quality, handcrafted treats — made fresh daily and delivered with care.
                </p>
                <div class="row gy-5 gx-4">
                    <!-- Service 1 -->
                    <div class="col-sm-6 wow fadeIn" data-wow-delay="0.1s">
                        <div class="d-flex align-items-center mb-3">
                            <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-3">
                                <i class="fa fa-bread-slice text-white"></i>
                            </div>
                            <h5 class="mb-0">Quality Products</h5>
                        </div>
                        <span>We use only the finest ingredients to ensure every bite is rich in flavor and freshness.</span>
                    </div>
                    <!-- Service 2 -->
                    <div class="col-sm-6 wow fadeIn" data-wow-delay="0.2s">
                        <div class="d-flex align-items-center mb-3">
                            <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-3">
                                <i class="fa fa-birthday-cake text-white"></i>
                            </div>
                            <h5 class="mb-0">Custom Products</h5>
                        </div>
                        <span>From birthday cakes to personalized cookies, we bring your sweetest ideas to life.</span>
                    </div>
                    <!-- Service 3 -->
                    <div class="col-sm-6 wow fadeIn" data-wow-delay="0.3s">
                        <div class="d-flex align-items-center mb-3">
                            <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-3">
                                <i class="fa fa-cart-plus text-white"></i>
                            </div>
                            <h5 class="mb-0">Online Order</h5>
                        </div>
                        <span>Order your favorite bakery items anytime, anywhere — quick and easy from our website.</span>
                    </div>
                    <!-- Service 4 -->
                    <div class="col-sm-6 wow fadeIn" data-wow-delay="0.4s">
                        <div class="d-flex align-items-center mb-3">
                            <div class="flex-shrink-0 btn-square bg-primary rounded-circle me-3">
                                <i class="fa fa-truck text-white"></i>
                            </div>
                            <h5 class="mb-0">Home Delivery</h5>
                        </div>
                        <span>Enjoy our fresh-baked goodness delivered straight to your door — warm and ready to eat.</span>
                    </div>
                </div>
            </div>

            <!-- Image Content -->
            <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="row img-twice position-relative h-100">
                    <div class="col-6">
                        <img class="img-fluid rounded" src="img/service-1.jpg" alt="Bakery team at work">
                    </div>
                    <div class="col-6 align-self-end">
                        <img class="img-fluid rounded" src="img/service-2.jpg" alt="Freshly baked goods">
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Service End -->

<!-- Team Start -->
<div class="container-xxl py-6">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="text-primary text-uppercase mb-2">// Our Team</p>
            <h1 class="display-6 mb-4">We're Super Professional At Our Skills</h1>
        </div>
        <div class="row g-4">
            <!-- Team Member 1 -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                <div class="team-item text-center rounded overflow-hidden">
                    <img class="img-fluid" src="img/team-1.jpg" alt="Emma - Master Baker">
                    <div class="team-text">
                        <div class="team-title">
                            <h5>Emma Carter</h5>
                            <span>Master Baker</span>
                        </div>
                        <div class="team-social">
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Team Member 2 -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                <div class="team-item text-center rounded overflow-hidden">
                    <img class="img-fluid" src="img/team-2.jpg" alt="Liam - Pastry Chef">
                    <div class="team-text">
                        <div class="team-title">
                            <h5>Liam Johnson</h5>
                            <span>Pastry Chef</span>
                        </div>
                        <div class="team-social">
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Team Member 3 -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                <div class="team-item text-center rounded overflow-hidden">
                    <img class="img-fluid" src="img/team-3.jpg" alt="Sophia - Cake Designer">
                    <div class="team-text">
                        <div class="team-title">
                            <h5>Sophia Lee</h5>
                            <span>Cake Designer</span>
                        </div>
                        <div class="team-social">
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Team Member 4 -->
            <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                <div class="team-item text-center rounded overflow-hidden">
                    <img class="img-fluid" src="img/team-4.jpg" alt="Noah - Delivery Manager">
                    <div class="team-text">
                        <div class="team-title">
                            <h5>Noah Bennett</h5>
                            <span>Delivery Manager</span>
                        </div>
                        <div class="team-social">
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-square btn-light rounded-circle" href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Team End -->

<!-- Testimonial Start -->
<div class="container-xxl bg-light my-6 py-6 pb-0">
    <div class="container">
        <div class="text-center mx-auto mb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 500px;">
            <p class="text-primary text-uppercase mb-2">// Client's Review</p>
            <h1 class="display-6 mb-4">More Than 20,000+ Customers Trusted Us</h1>
        </div>
        <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.1s">
            <!-- Testimonial 1 -->
            <div class="testimonial-item bg-white rounded p-4">
                <div class="d-flex align-items-center mb-4">
                    <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-1.jpg" alt="Sarah - Interior Designer">
                    <div class="ms-4">
                        <h5 class="mb-1">Sarah Mitchell</h5>
                        <span>Interior Designer</span>
                    </div>
                </div>
                <p class="mb-0">The quality and freshness of the pastries are unmatched. I order regularly for events, and they never disappoint. Always beautifully presented and delivered on time!</p>
            </div>
            <!-- Testimonial 2 -->
            <div class="testimonial-item bg-white rounded p-4">
                <div class="d-flex align-items-center mb-4">
                    <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-2.jpg" alt="David - Corporate Manager">
                    <div class="ms-4">
                        <h5 class="mb-1">David Kim</h5>
                        <span>Corporate Manager</span>
                    </div>
                </div>
                <p class="mb-0">We used their custom cakes for our corporate anniversary—flawless execution and delicious results. The team is professional and easy to work with.</p>
            </div>
            <!-- Testimonial 3 -->
            <div class="testimonial-item bg-white rounded p-4">
                <div class="d-flex align-items-center mb-4">
                    <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-3.jpg" alt="Linda - Blogger">
                    <div class="ms-4">
                        <h5 class="mb-1">Linda Parker</h5>
                        <span>Food Blogger</span>
                    </div>
                </div>
                <p class="mb-0">As a food blogger, I try a lot of bakeries—but this place stands out. Their creativity, flavors, and customer service are top-notch. Highly recommended!</p>
            </div>
            <!-- Testimonial 4 -->
            <div class="testimonial-item bg-white rounded p-4">
                <div class="d-flex align-items-center mb-4">
                    <img class="flex-shrink-0 rounded-circle border p-1" src="img/testimonial-4.jpg" alt="Tom - Event Planner">
                    <div class="ms-4">
                        <h5 class="mb-1">Tom Reynolds</h5>
                        <span>Event Planner</span>
                    </div>
                </div>
                <p class="mb-0">Their team is incredibly reliable and skilled. Whether it's a wedding, birthday, or corporate event, I trust them to deliver high-quality baked goods every time.</p>
            </div>
        </div>

        <!-- Newsletter Section -->
        <div class="bg-primary text-light rounded-top p-5 my-6 mb-0 wow fadeInUp" data-wow-delay="0.1s">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="display-4 text-light mb-0">Subscribe to Our Newsletter</h1>
                </div>
                <div class="col-md-6 text-md-end">
                    <div class="position-relative">
                        <input class="form-control bg-transparent border-light w-100 py-3 ps-4 pe-5" type="email" placeholder="Your email">
                        <button type="button" class="btn btn-dark py-2 px-3 position-absolute top-0 end-0 mt-2 me-2">Sign Up</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- Testimonial End -->


    <!-- Footer Start -->
    <div class="container-fluid bg-dark text-light footer my-6 mb-0 py-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
            <div class="row g-5">
<div class="col-lg-3 col-md-6">
    <h4 class="text-light mb-4">Contact Us</h4>
    <p class="mb-2">
        <i class="fa fa-map-marker-alt me-3"></i> 
        456 Bakery Lane, Brooklyn, NY 11201, USA
    </p>
    <p class="mb-2">
        <i class="fa fa-phone-alt me-3"></i> 
        +1 (555) 123-4567
    </p>
    <p class="mb-2">
        <i class="fa fa-envelope me-3"></i> 
        hello@caobakery.com
    </p>
    <div class="d-flex pt-2">
        <a class="btn btn-square btn-outline-light rounded-circle me-1" href="#" title="Twitter">
            <i class="fab fa-twitter"></i>
        </a>
        <a class="btn btn-square btn-outline-light rounded-circle me-1" href="#" title="Facebook">
            <i class="fab fa-facebook-f"></i>
        </a>
        <a class="btn btn-square btn-outline-light rounded-circle me-1" href="#" title="YouTube">
            <i class="fab fa-youtube"></i>
        </a>
        <a class="btn btn-square btn-outline-light rounded-circle me-0" href="#" title="LinkedIn">
            <i class="fab fa-linkedin-in"></i>
        </a>
    </div>
</div>

                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Quick Links</h4>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                    <a class="btn btn-link" href="">Our Services</a>
                    <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">Support</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Quick Links</h4>
                    <a class="btn btn-link" href="">About Us</a>
                    <a class="btn btn-link" href="">Contact Us</a>
                    <a class="btn btn-link" href="">Our Services</a>
                    <a class="btn btn-link" href="">Terms & Condition</a>
                    <a class="btn btn-link" href="">Support</a>
                </div>
                <div class="col-lg-3 col-md-6">
                    <h4 class="text-light mb-4">Photo Gallery</h4>
                    <div class="row g-2">
                        <div class="col-4">
                            <img class="img-fluid bg-light rounded p-1" src="img/product-1.jpg" alt="Image">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light rounded p-1" src="img/product-2.jpg" alt="Image">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light rounded p-1" src="img/product-3.jpg" alt="Image">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light rounded p-1" src="img/product-2.jpg" alt="Image">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light rounded p-1" src="img/product-3.jpg" alt="Image">
                        </div>
                        <div class="col-4">
                            <img class="img-fluid bg-light rounded p-1" src="img/product-1.jpg" alt="Image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Copyright Start -->
    <div class="container-fluid copyright text-light py-4 wow fadeIn" data-wow-delay="0.1s">
        <div class="container">
            <div class="row">
<div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
    &copy; <a href="#">CaoBakery</a>, All Rights Reserved.
</div>

            </div>
        </div>
    </div>
    <!-- Copyright End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-lg btn-primary btn-lg-square rounded-circle back-to-top"><i class="bi bi-arrow-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="lib/wow/wow.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/waypoints/waypoints.min.js"></script>
    <script src="lib/counterup/counterup.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>
</body>

</html>